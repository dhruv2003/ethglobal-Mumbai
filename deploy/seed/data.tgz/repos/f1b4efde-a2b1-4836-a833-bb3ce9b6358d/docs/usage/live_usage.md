# Live Usage (`optics live`)

`optics live` opens a full-screen, interactive terminal session for building tests
keyword-by-keyword against a live target (device or browser). It looks and behaves like Claude Code or
lazygit: the screen is taken over and redrawn in place, with a persistent input box
and status bar pinned at the bottom. Every successful action is recorded so you can
save the session as a reusable module.

## Launch

```bash
optics live                  # uses the config.yaml in the current directory
optics live <project_folder> # uses the config.yaml in that project folder
```

`optics live` is **driver-agnostic and config-driven**: the same flow works for
Android/iOS (Appium), web (Selenium, Playwright), TV, etc. The driver comes entirely
from the project's `config.yaml`, so a session "just works" for whatever you configure.

A `config.yaml` is **required** — there are no built-in defaults. It must declare:

- **exactly one** enabled entry under `driver_sources` (`appium`, `selenium`,
  `playwright`, …), and
- at least one enabled entry under `elements_sources`.

If no usable config is found, or the config has no enabled driver / more than one
enabled driver / no enabled element source, `optics live` exits with a clear message.
A malformed `config.yaml` reports the actual parse/validation error (not "no config").

Don't have a project yet? `optics quickstart` scaffolds a complete one (config
included), and `optics configure <folder>` generates a `config.yaml` for an existing
folder.

See `optics_framework/samples/` for ready-made configs: `contact` (Appium/Android),
`gmail_web` (Selenium), `playwright` (Playwright), `mobile_web` (Appium, Chrome on
Android). Named elements from the project are
loaded lazily the first time they are needed.

The session is opened automatically on launch (a `launch_app` action appears as the
first history entry). Each driver interprets `launch_app` using its own config: Appium
launches the configured `appPackage`/`appActivity`, while Selenium/Playwright navigate
to the configured URL.

## Layout

- **History pane** (top, scrollable): one entry per executed action showing the call
  as typed, pass/fail status (`✓` / `✗` / `⋯` while running), execution time, and the
  winning locator strategy (`[XPath]`, `[Text]`, `[OCR]`, `[Image]`). New entries are
  appended and the view auto-scrolls to the newest.
- **Input box** (pinned): where you type keyword calls and slash commands.
- **Status bar** (pinned, bottom): the active **target** — labelled by driver, e.g.
  `appium:emulator-5554`, `selenium:chrome`, `playwright:chromium` — the always-on
  recording indicator (`rec ●`), and a hint of available commands.

## Running keywords

Type a keyword call and press Enter, for example:

```
launch_app
press_element ${login_btn} index=0
enter_text ${username} "hello world"
sleep 5
```

- Keyword names come live from the framework's `KeywordRegistry`, so autocomplete
  always matches what the runner supports.
- `${name}` references resolve against the project's named elements, with the same
  fallback behaviour as the batch runner (each locator is tried in order).
- `key=value` tokens are passed as keyword arguments.
- A failing keyword is shown as `✗` with a short error (and error code) and is **not**
  recorded; the prompt returns ready for the next command. The UI never crashes.

## Autocomplete & hints

- **Keyword completion** — start typing the first token and press Tab.
- **Element completion** — type `${` to get element names, each shown with its first
  locator.
- **Ghost-text parameter hints** — once a keyword is recognised, its parameter
  signature is shown dimmed after the cursor: required params in `<>`, optional in `[]`.
- **Keyword browser** — press `Ctrl-K` for a navigable list of every keyword
  (Up/Down to move, Enter to drop it into the input box, Esc to close).

## Slash commands

| Command          | Description |
|------------------|-------------|
| `/save <test_case> <module_name>` | Save the recorded actions as `<module_name>` in `modules/modules.csv` and add a `(<test_case>, <module_name>)` row to `test_cases/test_cases.csv`. Elements are merged into your project's existing elements CSV when one is tracked anywhere (the templates keep it at `test_data/elements.csv`) — only names not already present are appended, so no second `elements/elements.csv` appears; with no elements file, `elements/elements.csv` is created with the elements that natural-language runs named. All three files use fixed names and are **appended** to when they already exist, so you can build a suite one module at a time. A successful save **clears the recording buffer**, so the next actions become the next module. If `<module_name>` or `<test_case>` already exists, the save is refused with a prompt — re-run the identical `/save` to append, or pick a different name. Session screenshots/artifacts are also snapshotted to `execution_output/<module_name>/`. |
| `/device [id]`   | **Appium sessions only.** List the **Android** (`adb`) and **iOS** (`idevice_id`) devices attached to *this* machine, each labelled by platform; with no argument, pick one to switch the active device's `udid`. The chosen device must match the session's configured platform. For Selenium/Playwright it reports that switching doesn't apply (the target is the configured browser). See the note below for remote Appium hubs. |
| `/elements`      | Open a read-only popup of named elements and their locators (Up/Down scrolls, Esc closes). |
| `/screenshot`    | Capture the current device screen to a file and note the path in the history. |
| `/help`          | Show the command reference (Up/Down scrolls, Esc closes). |
| `/quit`, `/exit` | End the session, run the normal driver teardown/cleanup, and exit. Typing `quit` or `exit` without the slash does the same, so leaving is never a guessing game. An unknown `/command` prints the available commands instead of failing silently. |

> **`/device` and remote Appium hubs.** `/device` shells out to the local `adb devices`
> and `idevice_id -l`, so it only ever sees devices plugged into the machine running
> `optics live`. If your session drives a device through a remote Appium hub, that device
> is attached to the hub's machine, not yours — `/device` will not list it, and reports
> no devices found even while the session is happily driving one. That's out of scope,
> not a fault: pick the hub device the way you already do, through the `udid` /
> `deviceName` capabilities in your `config.yaml`.

## Keys

| Key            | Action |
|----------------|--------|
| `Enter`        | Run the command, or accept the highlighted completion |
| `Tab` / `S-Tab`| Cycle completions |
| `${`           | Suggest element names |
| `Up` / `Down`  | Scroll an open popup (`PgUp`/`PgDn` by page); otherwise recall previous input |
| `Ctrl-K`       | Toggle the keyword browser |
| `Ctrl-N`       | Toggle natural-language (AI) mode |
| `Ctrl-X`       | Abort a running AI run (stops at the next step) |
| `Esc`          | Close any popup or the keyword browser |
| `Ctrl-C`       | Quit |

## Natural-language mode (optional)

Press `Ctrl-N` to toggle AI mode, then type an instruction in plain English
(e.g. `type "movies for kids" in the search bar`). `Ctrl-X` aborts. It works with whatever
driver your config uses (Appium/Selenium/Playwright).

Each turn the agent reads the screen as a list of rows, for example
`e7 button "Sign in" [tap] #login`. `e7` is a ref, the words in quotes are on the screen,
and `[tap]` lists what the element accepts. The LLM picks one action on a ref (`tap`, `type`,
`select`, `scroll`, `key`, `open`, `check`, or any keyword) and says what text the next
screen must show or lose. The agent then:

- runs the action through a locator that matches only that element;
- reads the screen again and judges the step in code as **pass**, **fail** or **unknown**;
- accepts **done** only when the goal text is on the screen. A run that ends done without
  goal text shows as `PASS (unverified)`.

The agent turns each element it acts on into a named element, such as `${sign_in_button}`,
whose values are the element's locators and, last, its label. When a project element has the
same first locator, the agent uses that element. The recorded step is
`press_element ${sign_in_button}`. The new elements join the session only when the instruction
completes, and `/save` writes them to your elements CSV. AI self-heal is off while the agent
runs, so every step it takes shows in its history.

When an instruction completes, the recorded steps are **curated** before they enter the
`/save` buffer: a final LLM pass keeps only the steps that contribute to the goal and drops
the agent's dead-ends, backtracks, and no-op gestures — so what you save is a minimal,
replayable script, not a transcript of everything it tried. Only the elements that the kept
steps use are added. An incomplete instruction (failed/aborted/step-limit) records nothing
and adds no elements. If the curation pass can't produce a usable result it
safely falls back to keeping every successful step, so a working recording is never lost.
Three steps to enable AI mode:

**1. Install the extra for your provider** (the SDKs are not in the base install):

```bash
pip install 'optics-framework[gemini]'    # or [openai], [anthropic]; [llm] installs all three
```

**2. Export your key** (read from the environment — don't hardcode it):

```bash
export GEMINI_API_KEY=your_key            # or OPENAI_API_KEY, ANTHROPIC_API_KEY, OPENROUTER_API_KEY
```

**3. Enable the engine in your project's `config.yaml`** (alongside your driver/element sources):

```yaml
llm_models:
  - gemini:
      enabled: true
```

The `openai` engine also reaches OpenRouter, Azure OpenAI and local servers such as Ollama,
and `anthropic` also runs Claude on Bedrock or Vertex AI. See
[Configuration → LLM Models](../configuration.md#llm-models) for each engine's options. An
engine's SDK is **only imported when that engine is enabled**, so non-AI users are
unaffected. If you toggle `Ctrl-N` without an enabled `llm_models` entry, the session
tells you to add one; if the extra isn't installed, you get the install command.

## Recording & saving

Recording is always on. Every successful keyword is appended to an in-memory buffer
in the order it ran. The buffer is only written to disk when you run
`/save <test_case> <module_name>`, which persists the buffered actions as one module
and then **clears the buffer** so the next actions form the next module. If you
`/quit` with unsaved actions, you are warned once — run `/save <test_case> <module_name>`
to keep them, or `/quit` again to discard and exit.

### Secrets are not saved

A value typed into a secret field is not written to disk. Live finds secret fields on the
screen by their type (a password field), a masked value, or a name, caption, hint or
locator such as "Password" or "PIN". A value typed without an element goes into the field
that has focus. When live cannot tell which field that is, a secret field anywhere on the
screen makes the value secret. The recorded step uses a new element, for example
`${password_field_value}`, in place of the value. The session keeps the real value, so the
steps run again in the same session. `/save` writes that element as `<redacted>`, so put
the real value in the elements CSV before you run the saved test.

### Screenshots are saved automatically

The framework auto-generates screenshots for every keyword call (a pre-action
screenshot, the post-action result image, and annotated/AOI captures). In a live
session these are written to a **persistent per-session folder**,
`screenshots/session_<timestamp>/`, and **survive `/quit`** — so every keyword you run
(typed or AI-driven) leaves a visual record with no extra step. The `<timestamp>`
matches the session log (`logs/optics_live_<timestamp>.log`) so the two correlate. An
empty session folder (no screenshots captured) is removed on exit; otherwise it's kept.

`/save <test_case> <module_name>` additionally bundles a **copy** of that session's
screenshots into `execution_output/<module_name>/`, alongside the saved module, so a
saved test is self-contained. Re-running `/save` for the same module refreshes the copy.

> The screenshots that the AI mode sends to the model are captured separately and are
> not written to disk; what you see in `screenshots/session_<timestamp>/` are the
> keyword pre/post/annotated frames.

## Logs

Every live session writes a chronological log of both the framework's internal
and execution loggers to `<project>/logs/optics_live_<timestamp>.log`. The path is
shown as the first entry in the history pane on startup, and again on stderr after
you `/quit`. Logs survive `/quit` regardless of whether you `/save` — they're for
diagnostics, not for the saved script.
