import pytest
from optics_framework.api.flow_control import FlowControl
from optics_framework.common.models import ApiData, ApiCollection, ApiDefinition, RequestDefinition, ExpectedResultDefinition
from optics_framework.common.error import OpticsError


@pytest.fixture
def api_test_data(mock_api_server):
    return ApiData(
        collections={
            "authentication_apis": ApiCollection(
                name="Authentication and OTP APIs",
                base_url=mock_api_server,
                global_headers={},
                apis={
                    "post_token": ApiDefinition(
                        name="Token Generation",
                        description="Generate OAuth token",
                        endpoint="/token",
                        request=RequestDefinition(
                            method="POST",
                            headers={"Content-Type": "application/json"},
                            body={"username": "test", "password": "password"}
                        ),
                        expected_result=ExpectedResultDefinition(extract={"auth_token": "access_token", "user_id": "user.userId"})
                    ),
                    "send_otp": ApiDefinition(
                        name="Send OTP",
                        description="Send OTP to user",
                        endpoint="/sendotp",
                        request=RequestDefinition(
                            method="POST",
                            headers={"Authorization": "${auth_token}", "Content-Type": "application/json"},
                            body={"userId": "${user_id}", "txnType": "GEN"}
                        ),
                        expected_result={"expected_status": 200}
                    )
                }
            )
        }
    )

@pytest.fixture
def flow_control(mock_runner, api_test_data):
    mock_runner.apis = api_test_data
    mock_runner.modules = {}
    keyword_map = {}
    flow_control = FlowControl(mock_runner, keyword_map)
    flow_control.session = mock_runner
    return flow_control

def test_invoke_api_success(flow_control):
    # 1. Invoke the first API (post_token)
    flow_control.invoke_api("authentication_apis.post_token")

    # Assertions for the first API call
    assert flow_control.session.elements.get_first("auth_token") == "real_auth_token_123"
    assert flow_control.session.elements.get_first("user_id") == "98765"

    # 2. Invoke the second API (send_otp)
    flow_control.invoke_api("authentication_apis.send_otp")

    # No direct assertion on the second API call response here, as it's handled internally by FlowControl
    # and we're primarily testing the invocation and data flow.

def test_invoke_api_collection_not_found(flow_control):
    with pytest.raises(OpticsError, match="API collection 'non_existent_apis' not found."):
        flow_control.invoke_api("non_existent_apis.some_api")

def test_invoke_api_definition_not_found(flow_control):
    with pytest.raises(OpticsError, match="API 'non_existent_api' not found in collection 'Authentication and OTP APIs'."):
        flow_control.invoke_api("authentication_apis.non_existent_api")

def test_invoke_api_invalid_identifier(flow_control):
    with pytest.raises(OpticsError, match="Invalid API identifier format: 'invalid_identifier'. Expected 'collection.api_name'."):
        flow_control.invoke_api("invalid_identifier")

def test_invoke_api_request_failure(flow_control):
    # Point the collection at a closed port to force a connection failure.
    # api_test_data is function-scoped, so this mutation cannot leak to other tests.
    flow_control.session.apis.collections["authentication_apis"].base_url = "http://127.0.0.1:9"

    with pytest.raises(OpticsError, match="API request to http://127.0.0.1:9/token failed:"):
        flow_control.invoke_api("authentication_apis.post_token")


@pytest.fixture
def served_session(mock_runner, api_test_data):
    """A session shaped as ``optics serve`` creates one: ``elements=None``, with no way to
    fill it afterwards. Every other fixture here hands FlowControl a ready ``ElementData``,
    which is why nothing caught that ``extract`` could not run in a served session.
    """
    mock_runner.apis = api_test_data
    mock_runner.modules = {}
    mock_runner.elements = None
    flow_control = FlowControl(mock_runner, {})
    flow_control.session = mock_runner
    return flow_control


def test_extract_works_in_a_session_created_without_an_element_store(served_session):
    served_session.invoke_api("authentication_apis.post_token")

    assert served_session.session.elements.get_first("auth_token") == "real_auth_token_123"
    assert served_session.session.elements.get_first("user_id") == "98765"


def test_a_later_api_reads_what_an_earlier_one_extracted(served_session):
    """The store has to survive on the session, not just inside the call that made it:
    ``send_otp`` sends ``${auth_token}``, which only ``post_token`` supplies."""
    served_session.invoke_api("authentication_apis.post_token")
    served_session.invoke_api("authentication_apis.send_otp")

    assert served_session.session.elements.get_first("auth_token") == "real_auth_token_123"


def test_an_existing_element_store_is_kept_rather_than_replaced(flow_control):
    """A packaged run arrives with elements loaded from its csvs; an extract adds to those."""
    flow_control.session.elements.add_element("from_a_csv", "//button")
    flow_control.invoke_api("authentication_apis.post_token")

    assert flow_control.session.elements.get_first("from_a_csv") == "//button"
    assert flow_control.session.elements.get_first("auth_token") == "real_auth_token_123"


def test_invoke_api_returns_response(flow_control):
    result = flow_control.invoke_api("authentication_apis.post_token")

    assert result["status_code"] == 200
    assert result["body"]["access_token"] == "real_auth_token_123"
    assert isinstance(result["headers"], dict)
    assert isinstance(result["elapsed_ms"], float)


@pytest.mark.parametrize(
    "path,expected",
    [
        ("$.access_token", "tok"),
        ("access_token", "tok"),
        ("$.user.userId", "98765"),
        ("user.userId", "98765"),
        ("$.resultObj.containers[0].metadata.title", "Taj Mahal"),
        ("resultObj.containers[0].metadata.title", "Taj Mahal"),
        ("$.missing", None),
        ("user.missing.deeper", None),
    ],
)
def test_extract_from_json_paths(path, expected):
    data = {
        "access_token": "tok",
        "user": {"userId": "98765"},
        "resultObj": {"containers": [{"metadata": {"title": "Taj Mahal"}}]},
    }
    assert FlowControl.__new__(FlowControl)._extract_from_json(data, path) == expected


def test_extraction_creates_element_store_when_missing():
    class SessionWithoutElements:
        elements = None

    flow_control = FlowControl.__new__(FlowControl)
    flow_control.session = SessionWithoutElements()

    flow_control._extract_and_store_single_value({"dummy": "482913"}, "otp", "$.dummy")

    assert flow_control.session.elements.get_first("otp") == "482913"
