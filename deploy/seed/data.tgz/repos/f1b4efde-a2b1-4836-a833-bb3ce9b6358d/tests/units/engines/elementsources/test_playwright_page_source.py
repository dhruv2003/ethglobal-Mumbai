from unittest.mock import MagicMock

import pytest
from lxml import etree

from optics_framework.common.error import Code, OpticsError
from optics_framework.engines.elementsources import playwright_page_source as pw

pytestmark = pytest.mark.white_box


def _source(html):
    page = MagicMock()
    page.content.return_value = html
    src = pw.PlaywrightPageSource(driver=MagicMock(page=page, run=lambda coro, **_: coro))
    return src, page


def _grid_html(n):
    items = "".join(f'<button id="item-{i}">Item {i}</button>' for i in range(n))
    return f"<html><body>{items}</body></html>"


def _candidate_count(html):
    """Every node .//* sees, including lxml's implicit <head/>."""
    tree = etree.HTML(html)
    return len(tree.xpath(".//*")) if tree is not None else 0


def _uniform_rects(width=20, height=20):
    def _side_effect(script, xpaths):
        if script != pw.BOUNDS_JS:
            return [None] * len(xpaths)
        return [{"x": i, "y": i, "width": width, "height": height} for i, _ in enumerate(xpaths)]
    return _side_effect


def test_page_source_waits_for_the_page_to_settle_before_reading():
    src, page = _source("<html><body></body></html>")
    order = []
    src.driver.wait_for_page_settled.side_effect = lambda: order.append("settle")
    page.content.side_effect = lambda: order.append("read") or "<html><body></body></html>"
    src.get_page_source()
    assert order == ["settle", "read"]


class TestBatchedEvaluateCallCount:
    @pytest.mark.parametrize("compact", [False, True])
    @pytest.mark.parametrize("n", [1, 50])
    def test_evaluate_calls_do_not_grow_with_node_count(self, n, compact):
        src, page = _source(_grid_html(n))
        page.evaluate.side_effect = _uniform_rects()
        elements = src.get_interactive_elements(None, compact=compact)
        assert page.evaluate.call_count == 2  # bounds, then locator suggestions
        assert [el["text"] for el in elements] == [f"Item {i}" for i in range(n)]

    def test_evaluate_not_called_when_there_are_no_candidate_nodes(self):
        src, page = _source("")
        page.evaluate.side_effect = _uniform_rects()
        elements = src.get_interactive_elements(None)
        assert elements == []
        assert page.evaluate.call_count == 0


class TestOutputShapeAndFiltering:
    def test_mixed_present_absent_bounds_matches_prior_semantics(self):
        html = (
            "<html><body>"
            '<button id="btn-a">Alpha</button>'
            '<button id="btn-b">Beta</button>'
            '<button id="btn-c">Gamma</button>'
            "</body></html>"
        )
        src, page = _source(html)
        def side_effect(script, xpaths):
            # btn-b gets no bounds, so it is dropped.
            if script != pw.BOUNDS_JS:
                return [None] * len(xpaths)
            rects = []
            for xp in xpaths:
                if xp and "btn-a" in xp:
                    rects.append({"x": 10, "y": 20, "width": 100, "height": 40})
                elif xp and "btn-c" in xp:
                    rects.append({"x": 200, "y": 20, "width": 100, "height": 40})
                else:
                    rects.append(None)
            return rects
        page.evaluate.side_effect = side_effect
        elements = src.get_interactive_elements(None)

        assert page.evaluate.call_count == 2  # bounds, then locator suggestions
        texts = {el["text"] for el in elements}
        assert texts == {"Alpha", "Gamma"}
        alpha = next(el for el in elements if el["text"] == "Alpha")
        assert set(alpha.keys()) == {"text", "bounds", "xpath", "extra"}
        assert alpha["bounds"] == {"x1": 10, "y1": 20, "x2": 110, "y2": 60}
        assert alpha["xpath"]

    def test_compact_drops_only_the_candidate_without_bounds(self):
        html = (
            "<html><body>"
            '<button id="btn-a">Alpha</button>'
            '<button id="btn-b">Beta</button>'
            "</body></html>"
        )
        src, page = _source(html)
        page.evaluate.side_effect = lambda script, xpaths: [
            {"x": 0, "y": 0, "width": 10, "height": 10} if xp and "btn-a" in xp else None
            for xp in xpaths
        ]
        elements = src.get_interactive_elements(None, compact=True)
        assert [el["text"] for el in elements] == ["Alpha"]

    def test_filter_config_still_applies_after_bounds_check(self):
        html = (
            "<html><body>"
            '<button id="btn-a">Alpha</button>'
            '<span id="span-a">Not a button</span>'
            "</body></html>"
        )
        src, page = _source(html)
        page.evaluate.side_effect = _uniform_rects()
        elements = src.get_interactive_elements(["buttons"])
        assert [el["text"] for el in elements] == ["Alpha"]

    def test_all_filter_returns_every_bounded_element(self):
        html = _grid_html(5)
        src, page = _source(html)
        page.evaluate.side_effect = _uniform_rects()

        elements = src.get_interactive_elements(["all"])

        assert len(elements) == _candidate_count(html)


class TestBatchFailureDegradesGracefully:
    def test_evaluate_exception_returns_no_elements_without_per_node_fallback(self):
        src, page = _source(_grid_html(3))
        page.evaluate.side_effect = RuntimeError("page navigated mid-evaluate")
        elements = src.get_interactive_elements(None)
        assert elements == []
        # A whole-batch failure must not fall back to one evaluate() call per node.
        assert page.evaluate.call_count == 1

    def test_compact_batch_failure_is_unavailable_not_empty(self):
        # The NL agent falls back to page source on "unavailable", so a failed batch
        # must raise rather than return [] and look like a genuinely empty screen.
        src, page = _source(_grid_html(3))
        page.evaluate.side_effect = RuntimeError("page navigated mid-evaluate")
        with pytest.raises(OpticsError) as excinfo:
            src.get_interactive_elements(None, compact=True)
        assert excinfo.value.code == Code.E0202
        assert page.evaluate.call_count == 1

    @pytest.mark.parametrize(
        "payload",
        [
            [{"x": 0, "y": 0, "width": 5, "height": 5}],  # too short
            {"unexpected": "payload"},  # not a list at all
        ],
    )
    def test_compact_malformed_batch_is_unavailable_not_empty(self, payload):
        src, page = _source(_grid_html(3))
        page.evaluate.return_value = payload
        with pytest.raises(OpticsError) as excinfo:
            src.get_interactive_elements(None, compact=True)
        assert excinfo.value.code == Code.E0202

    def test_compact_empty_page_still_returns_empty_list(self):
        src, page = _source("")
        page.evaluate.side_effect = _uniform_rects()
        assert src.get_interactive_elements(None, compact=True) == []
        assert page.evaluate.call_count == 0

    def test_compact_all_bounds_invisible_still_returns_empty_list(self):
        # A length-matched payload of nulls is a real "nothing visible" answer, not a
        # failed lookup, so it must keep the [] that means empty.
        src, page = _source(_grid_html(3))
        page.evaluate.side_effect = lambda script, xpaths: [None] * len(xpaths)
        assert src.get_interactive_elements(None, compact=True) == []

    def test_mismatched_length_response_is_treated_as_all_absent(self):
        src, page = _source(_grid_html(3))
        page.evaluate.return_value = [{"x": 0, "y": 0, "width": 5, "height": 5}]  # too short
        elements = src.get_interactive_elements(None)
        assert elements == []
