"""Unit tests for the keyword-based AI self-heal handler and its ActionKeyword wiring.

No network: a scripted fake LLM drives the handler and a fake keyword executor records the
keyword lines dispatched. Covers each action type, the bounded loop, give_up, done, malformed
JSON, LLM/executor errors, missing-screenshot inertness, page-source injection, the
ActionKeyword inert/active paths, and ActionKeyword._heal_execute's own shlex parsing,
dispatch-table lookup, and error surfacing in isolation.
"""
import json
from dataclasses import dataclass

import numpy as np
import pytest

from optics_framework.common import ai_self_heal as ash
from optics_framework.common.ai_self_heal import (
    AISelfHealHandler,
    HealContext,
    HealKeywordSpec,
    HEAL_ACTION_SCHEMA,
    HEAL_SYSTEM_PROMPT,
)
from optics_framework.common.error import OpticsError, Code
from optics_framework.common.step_curation import CURATION_SCHEMA

pytestmark = pytest.mark.white_box


@pytest.fixture(autouse=True)
def _no_sleep(monkeypatch):
    """Never actually sleep during the settle delay."""
    monkeypatch.setattr(ash.time, "sleep", lambda *_a, **_k: None)


class FakeLLM:
    """Returns scripted JSON dicts from generate_json, ignoring prompt/images."""

    def __init__(self, scripted):
        self.scripted = list(scripted)
        self.calls = 0
        self.last_prompt = None
        self.last_system = None

    def generate(self, *a, **k):  # pragma: no cover - handler uses generate_json
        raise RuntimeError("unexpected generate() call")

    def generate_json(self, prompt, response_schema, images=None, system=None, temperature=None):
        self.calls += 1
        self.last_prompt = prompt
        self.last_system = system
        assert response_schema is HEAL_ACTION_SCHEMA
        assert images and isinstance(images[0], (bytes, bytearray))
        return self.scripted.pop(0)


@dataclass
class ExecResult:
    ok: bool
    message: str = ""


class FakeExecutor:
    """Records keyword lines dispatched by the handler."""

    def __init__(self, *, fail_keywords=None):
        self.calls = []
        self._fail_keywords = fail_keywords or set()

    def __call__(self, line: str) -> ExecResult:
        self.calls.append(line)
        keyword = line.split()[0] if line else ""
        if keyword in self._fail_keywords:
            return ExecResult(ok=False, message=f"Element not found for '{keyword}'")
        return ExecResult(ok=True)


def _catalog():
    return [
        HealKeywordSpec(name="press_element", signature="press_element <element> [repeat]"),
        HealKeywordSpec(name="enter_text", signature="enter_text <element> <text>"),
        HealKeywordSpec(name="scroll", signature="scroll <direction>"),
        HealKeywordSpec(name="swipe_by_percentage", signature="swipe_by_percentage <percent_x> <percent_y> <direction> [swipe_length]"),
        HealKeywordSpec(name="press_keycode", signature="press_keycode <keycode>"),
        HealKeywordSpec(name="press_by_percentage", signature="press_by_percentage <percent_x> <percent_y>"),
    ]


def _shots():
    return b"PNGBYTES"


def _no_ps():
    return None


def _ctx():
    return HealContext(intent_keyword="press_element", intent_params=["Login"], element="Login")


class TestActionSchema:
    def test_required_minimal(self):
        assert HEAL_ACTION_SCHEMA["required"] == ["reason", "action"]

    def test_no_anyof(self):
        assert "anyOf" not in json.dumps(HEAL_ACTION_SCHEMA)


class TestHandlerActions:
    def test_press_element_completes(self):
        """LLM emits press_element with text target — single step, completed."""
        llm = FakeLLM([
            {"action": "keyword", "keyword": "press_element", "params": ["Shop"],
             "completed": True, "reason": "press target"},
        ])
        executor = FakeExecutor()
        res = AISelfHealHandler(llm, executor, lambda: _catalog()).heal(_ctx(), _shots, _no_ps)
        assert res.ok is True
        assert executor.calls == ['press_element Shop']
        assert llm.calls == 1

    def test_scroll_then_press_element(self):
        """LLM scrolls to reveal target, then presses by text."""
        llm = FakeLLM([
            {"action": "keyword", "keyword": "scroll", "params": ["down"],
             "completed": False, "reason": "reveal target"},
            {"action": "keyword", "keyword": "press_element", "params": ["Shop"],
             "completed": True, "reason": "press target"},
        ])
        executor = FakeExecutor()
        res = AISelfHealHandler(llm, executor, lambda: _catalog(), max_steps=2).heal(_ctx(), _shots, _no_ps)
        assert res.ok is True
        assert executor.calls == ['scroll down', 'press_element Shop']
        assert llm.calls == 2

    def test_enter_text_completes(self):
        """LLM emits enter_text — single step completion."""
        ctx = HealContext(intent_keyword="enter_text", intent_params=["Search", "hello"], element="Search")
        llm = FakeLLM([
            {"action": "keyword", "keyword": "enter_text", "params": ["Search", "hello"],
             "completed": True, "reason": "type it"},
        ])
        executor = FakeExecutor()
        res = AISelfHealHandler(llm, executor, lambda: _catalog()).heal(ctx, _shots, _no_ps)
        assert res.ok is True
        assert executor.calls == ["enter_text Search hello"]

    def test_press_keycode_then_press_element(self):
        """LLM presses back, then targets element by text."""
        llm = FakeLLM([
            {"action": "keyword", "keyword": "press_keycode", "params": ["4"],
             "completed": False, "reason": "go back"},
            {"action": "keyword", "keyword": "press_element", "params": ["Login"],
             "completed": True, "reason": "press it"},
        ])
        executor = FakeExecutor()
        res = AISelfHealHandler(llm, executor, lambda: _catalog(), max_steps=2).heal(_ctx(), _shots, _no_ps)
        assert res.ok is True
        assert executor.calls == ['press_keycode 4', 'press_element Login']

    def test_done_action_succeeds(self):
        """LLM signals done — goal reached without a keyword."""
        llm = FakeLLM([
            {"action": "done", "reason": "target already visible and pressed"},
        ])
        executor = FakeExecutor()
        res = AISelfHealHandler(llm, executor, lambda: _catalog()).heal(_ctx(), _shots, _no_ps)
        assert res.ok is True
        assert executor.calls == []

    def test_give_up_fails(self):
        llm = FakeLLM([{"action": "give_up", "reason": "blocked"}])
        executor = FakeExecutor()
        res = AISelfHealHandler(llm, executor, lambda: _catalog()).heal(_ctx(), _shots, _no_ps)
        assert res.ok is False
        assert "blocked" in res.message

    def test_malformed_action_treated_as_give_up(self):
        llm = FakeLLM([{"action": "frobnicate", "reason": "nonsense"}])
        executor = FakeExecutor()
        res = AISelfHealHandler(llm, executor, lambda: _catalog()).heal(_ctx(), _shots, _no_ps)
        assert res.ok is False
        assert executor.calls == []

    def test_step_budget_exhausted(self):
        llm = FakeLLM([
            {"action": "keyword", "keyword": "scroll", "params": ["down"], "reason": "x"}
        ] * 2)
        executor = FakeExecutor()
        res = AISelfHealHandler(llm, executor, lambda: _catalog(), max_steps=2).heal(_ctx(), _shots, _no_ps)
        assert res.ok is False
        assert llm.calls == 2
        assert executor.calls == ['scroll down', 'scroll down']
        assert "scroll down" in res.message

    def test_keyword_failure_does_not_abort(self):
        """A failing keyword lets the LLM retry a different approach."""
        llm = FakeLLM([
            {"action": "keyword", "keyword": "press_element", "params": ["WrongText"],
             "completed": True, "reason": "try pressing"},
            {"action": "keyword", "keyword": "press_element", "params": ["Login"],
             "completed": True, "reason": "correct target"},
        ])
        executor = FakeExecutor(fail_keywords={"press_element"})
        # Both fail because we set press_element as failing, so heal should fail
        res = AISelfHealHandler(llm, executor, lambda: _catalog(), max_steps=2).heal(_ctx(), _shots, _no_ps)
        assert res.ok is False
        assert len(executor.calls) == 2

    def test_prompt_lists_prior_heal_steps_with_outcomes(self):
        """Each turn sees the heal's own earlier calls, so a FAIL isn't retried blind."""
        prompts = []

        class RecordingLLM(FakeLLM):
            def generate_json(self, prompt, *args, **kwargs):
                prompts.append(prompt)
                return super().generate_json(prompt, *args, **kwargs)

        llm = RecordingLLM([
            {"action": "keyword", "keyword": "press_element", "params": ["WrongText"],
             "completed": True, "reason": "try pressing"},
            {"action": "keyword", "keyword": "scroll", "params": ["down"],
             "completed": False, "reason": "reveal"},
            {"action": "give_up", "reason": "stuck"},
        ])
        executor = FakeExecutor(fail_keywords={"press_element"})
        AISelfHealHandler(llm, executor, lambda: _catalog(), max_steps=3).heal(_ctx(), _shots, _no_ps)

        assert "SELF-HEAL STEPS SO FAR" not in prompts[0]
        assert "1. press_element WrongText -> FAIL" in prompts[1]
        assert "1. press_element WrongText -> FAIL" in prompts[2]
        assert "2. scroll down -> PASS" in prompts[2]

    def test_system_prompt_names_only_dispatchable_gestures(self):
        """The prompt must not steer the model to a keyword the heal allowlist lacks."""
        assert "`swipe`" not in HEAL_SYSTEM_PROMPT
        assert "swipe instead of scroll" not in HEAL_SYSTEM_PROMPT.lower()
        for name in ("scroll", "swipe_by_percentage", "press_keycode", "press_by_percentage"):
            assert f"`{name}`" in HEAL_SYSTEM_PROMPT

    def test_intermediate_press_then_final_press(self):
        """LLM presses a menu (completed=False), then the final target (completed=True)."""
        llm = FakeLLM([
            {"action": "keyword", "keyword": "press_element", "params": ["Apps"],
             "completed": False, "reason": "open apps drawer"},
            {"action": "keyword", "keyword": "press_element", "params": ["Shop"],
             "completed": True, "reason": "press target"},
        ])
        executor = FakeExecutor()
        res = AISelfHealHandler(llm, executor, lambda: _catalog(), max_steps=2).heal(_ctx(), _shots, _no_ps)
        assert res.ok is True
        assert executor.calls == ['press_element Apps', 'press_element Shop']

    def test_swipe_uses_percentage(self):
        llm = FakeLLM([
            {"action": "keyword", "keyword": "swipe_by_percentage", "params": ["50", "80", "up", "30"],
             "completed": False, "reason": "reveal target"},
            {"action": "give_up", "reason": "still not visible"},
        ])
        executor = FakeExecutor()
        res = AISelfHealHandler(llm, executor, lambda: _catalog(), max_steps=2).heal(_ctx(), _shots, _no_ps)
        assert res.ok is False
        assert executor.calls == ['swipe_by_percentage 50 80 up 30']


class _FailByParamExecutor:
    """Executor that fails when a substring appears in the keyword line."""

    def __init__(self, fail_substring: str):
        self.calls = []
        self._fail_substring = fail_substring

    def __call__(self, line: str) -> ExecResult:
        self.calls.append(line)
        if self._fail_substring in line:
            return ExecResult(ok=False, message="not found")
        return ExecResult(ok=True)


class CuratingFakeLLM:
    """FakeLLM that also serves the post-heal curation turn.

    HEAL_ACTION_SCHEMA turns come from ``scripted``; the single CURATION_SCHEMA turn
    returns ``curation_reply``. Curation is text-only, so ``images`` must be None.
    """

    def __init__(self, scripted, curation_reply):
        self.scripted = list(scripted)
        self.curation_reply = curation_reply
        self.calls = 0
        self.curation_calls = 0
        self.last_curation_prompt = None

    def generate(self, *a, **k):  # pragma: no cover - handler uses generate_json
        raise RuntimeError("unexpected generate() call")

    def generate_json(self, prompt, response_schema, images=None, system=None, temperature=None):
        if response_schema is CURATION_SCHEMA:
            self.curation_calls += 1
            self.last_curation_prompt = prompt
            assert images is None
            return self.curation_reply
        self.calls += 1
        assert response_schema is HEAL_ACTION_SCHEMA
        return self.scripted.pop(0)


class TestSuggestedSteps:
    def test_suggested_steps_are_the_passing_steps(self):
        """A navigation step then a completing step: both passed -> both suggested."""
        llm = FakeLLM([
            {"action": "keyword", "keyword": "scroll", "params": ["down"],
             "completed": False, "reason": "reveal"},
            {"action": "keyword", "keyword": "press_element", "params": ["Login"],
             "completed": True, "reason": "press"},
        ])
        res = AISelfHealHandler(llm, FakeExecutor(), lambda: _catalog(), max_steps=2).heal(
            _ctx(), _shots, _no_ps
        )
        assert res.ok is True
        assert res.suggested_steps == [("scroll", ["down"]), ("press_element", ["Login"])]

    def test_failed_attempts_excluded_from_suggested_but_kept_in_steps_taken(self):
        """A failed intermediate attempt pollutes steps_taken but not suggested_steps."""
        llm = FakeLLM([
            {"action": "keyword", "keyword": "press_element", "params": ["Wrong"],
             "completed": True, "reason": "try"},
            {"action": "keyword", "keyword": "scroll", "params": ["down"],
             "completed": False, "reason": "reveal"},
            {"action": "keyword", "keyword": "press_element", "params": ["Login"],
             "completed": True, "reason": "press"},
        ])
        executor = _FailByParamExecutor("Wrong")
        res = AISelfHealHandler(llm, executor, lambda: _catalog(), max_steps=3).heal(
            _ctx(), _shots, _no_ps
        )
        assert res.ok is True
        assert res.suggested_steps == [("scroll", ["down"]), ("press_element", ["Login"])]
        # steps_taken keeps the noisy full history, including the failed attempt.
        assert res.steps_taken == ["press_element Wrong", "scroll down", "press_element Login"]

    def test_curation_off_by_default_makes_no_extra_llm_call(self):
        llm = FakeLLM([
            {"action": "keyword", "keyword": "scroll", "params": ["down"],
             "completed": False, "reason": "reveal"},
            {"action": "keyword", "keyword": "press_element", "params": ["Login"],
             "completed": True, "reason": "press"},
        ])
        res = AISelfHealHandler(llm, FakeExecutor(), lambda: _catalog(), max_steps=2).heal(
            _ctx(), _shots, _no_ps
        )
        assert res.ok is True
        assert llm.calls == 2  # no curation round-trip
        assert res.suggested_steps == [("scroll", ["down"]), ("press_element", ["Login"])]

    def test_curation_prunes_suggested_steps(self):
        """With curate=True, the curation pass drops the overshoot/backtrack steps."""
        llm = CuratingFakeLLM(
            [
                {"action": "keyword", "keyword": "scroll", "params": ["down"],
                 "completed": False, "reason": "overshoot"},
                {"action": "keyword", "keyword": "scroll", "params": ["up"],
                 "completed": False, "reason": "backtrack"},
                {"action": "keyword", "keyword": "press_element", "params": ["Login"],
                 "completed": True, "reason": "press"},
            ],
            curation_reply={"keep": [3], "reason": "only the final press contributed"},
        )
        res = AISelfHealHandler(
            llm, FakeExecutor(), lambda: _catalog(), max_steps=3, curate=True
        ).heal(_ctx(), _shots, _no_ps)
        assert res.ok is True
        assert llm.curation_calls == 1
        assert res.suggested_steps == [("press_element", ["Login"])]
        # The goal (the original failed keyword) is named in the curation prompt.
        assert "press_element Login" in llm.last_curation_prompt

    def test_curation_keeps_all_on_degenerate_reply(self):
        """A curation reply that keeps everything leaves suggested_steps unpruned."""
        llm = CuratingFakeLLM(
            [
                {"action": "keyword", "keyword": "scroll", "params": ["down"],
                 "completed": False, "reason": "reveal"},
                {"action": "keyword", "keyword": "press_element", "params": ["Login"],
                 "completed": True, "reason": "press"},
            ],
            curation_reply={"keep": [1, 2], "reason": "both needed"},
        )
        res = AISelfHealHandler(
            llm, FakeExecutor(), lambda: _catalog(), max_steps=2, curate=True
        ).heal(_ctx(), _shots, _no_ps)
        assert res.ok is True
        assert res.suggested_steps == [("scroll", ["down"]), ("press_element", ["Login"])]

    def test_budget_exhausted_reports_passed_steps_uncurated(self):
        llm = FakeLLM([
            {"action": "keyword", "keyword": "scroll", "params": ["down"], "reason": "x"}
        ] * 2)
        res = AISelfHealHandler(
            llm, FakeExecutor(), lambda: _catalog(), max_steps=2, curate=True
        ).heal(_ctx(), _shots, _no_ps)
        assert res.ok is False
        assert res.suggested_steps == [("scroll", ["down"]), ("scroll", ["down"])]


class TestHandlerErrorHandling:
    def test_llm_error_returns_not_ok(self):
        class BoomLLM:
            def generate_json(self, *a, **k):
                raise OpticsError(Code.E0801, message="bad json")

        res = AISelfHealHandler(BoomLLM(), FakeExecutor(), lambda: _catalog()).heal(_ctx(), _shots, _no_ps)
        assert res.ok is False
        assert "bad json" in res.message

    def test_executor_exception_returns_not_ok(self):
        def boom_executor(line):
            raise RuntimeError("device offline")

        llm = FakeLLM([{"action": "keyword", "keyword": "press_element", "params": ["X"], "reason": "x"}])
        res = AISelfHealHandler(llm, boom_executor, lambda: _catalog()).heal(_ctx(), _shots, _no_ps)
        assert res.ok is False
        assert "device offline" in res.message

    def test_no_screenshot_is_inert(self):
        llm = FakeLLM([{"action": "keyword", "keyword": "press_element", "params": ["X"], "reason": "x"}])
        res = AISelfHealHandler(llm, FakeExecutor(), lambda: _catalog()).heal(_ctx(), lambda: None, _no_ps)
        assert res.ok is False
        assert llm.calls == 0


class TestPromptContext:
    def test_page_source_and_context_injected(self):
        llm = FakeLLM([{"action": "give_up", "reason": "x"}])
        ps = 'EditText "User" id=login_field bounds=[0,0][10,10] clickable'
        ctx = HealContext(
            intent_keyword="enter_text",
            intent_params=["User", "bob"],
            element="User",
            recent_steps=[("press_element", ["Menu"])],
            failed_strategies=["XPathStrategy", "TextDetectionStrategy"],
        )
        AISelfHealHandler(llm, FakeExecutor(), lambda: _catalog()).heal(ctx, _shots, lambda: ps)
        assert "login_field" in llm.last_prompt
        assert "CURRENT SCREEN ELEMENTS" in llm.last_prompt
        assert "enter_text" in llm.last_prompt
        assert "press_element" in llm.last_prompt  # recent step
        assert "TextDetectionStrategy" in llm.last_prompt
        assert "last-resort" in llm.last_system.lower()

    def test_keyword_catalog_in_prompt(self):
        llm = FakeLLM([{"action": "give_up", "reason": "x"}])
        AISelfHealHandler(llm, FakeExecutor(), lambda: _catalog()).heal(_ctx(), _shots, _no_ps)
        assert "AVAILABLE KEYWORDS" in llm.last_prompt
        assert "press_element <element>" in llm.last_prompt
        assert "scroll <direction>" in llm.last_prompt


# --------------------------------------------------------------------------------------------
# ActionKeyword integration: inert when off / no LLM, active when on.
# --------------------------------------------------------------------------------------------

from unittest.mock import MagicMock, patch  # noqa: E402
import tempfile  # noqa: E402

from optics_framework.api.action_keyword import ActionKeyword  # noqa: E402
from optics_framework.common.optics_builder import OpticsBuilder  # noqa: E402


class _Builder(OpticsBuilder):
    def __init__(self, *, ai_self_heal, llm):
        self.mock_driver = MagicMock()
        self.mock_element_source = MagicMock()
        self._llm = llm
        self.session_config = MagicMock()
        self.session_config.execution_output_path = tempfile.mkdtemp()
        self.session_config.ai_self_heal = ai_self_heal

    def get_driver(self):
        return self.mock_driver

    def get_element_source(self):
        return self.mock_element_source

    def get_text_detection(self):
        return None

    def get_image_detection(self):
        return None

    def get_llm(self):
        return self._llm

    @property
    def event_sdk(self):
        return MagicMock()


def _make_action_keyword(*, ai_self_heal, llm):
    with patch("optics_framework.api.action_keyword.Verifier", MagicMock()):
        return ActionKeyword(_Builder(ai_self_heal=ai_self_heal, llm=llm))


class TestActionKeywordWiring:
    def test_toggle_off_is_inert(self):
        ak = _make_action_keyword(ai_self_heal=False, llm=MagicMock(instances=[object()]))
        assert ak.ai_self_heal_enabled is False
        assert ak._llm is None
        shot = np.zeros((10, 10, 3), dtype=np.uint8)
        assert ak._ai_self_heal("X", "press_element", (), shot) is False

    def test_no_screenshot_inert(self):
        ak = _make_action_keyword(ai_self_heal=True, llm=MagicMock(instances=[object()]))
        assert ak._ai_self_heal("X", "press_element", (), None) is False

    def test_llm_without_instances_inert(self):
        ak = _make_action_keyword(ai_self_heal=True, llm=MagicMock(instances=[]))
        shot = np.zeros((10, 10, 3), dtype=np.uint8)
        assert ak._ai_self_heal("X", "press_element", (), shot) is False

    def test_heal_catalog_returns_specs(self):
        ak = _make_action_keyword(ai_self_heal=True, llm=MagicMock(instances=[object()]))
        catalog = ak._heal_catalog()
        names = [spec.name for spec in catalog]
        assert "press_element" in names
        assert "scroll" in names
        assert "enter_text" in names
        # Signatures should be human-readable
        pe_spec = next(s for s in catalog if s.name == "press_element")
        assert "<element>" in pe_spec.signature

    def test_active_press_element_heals(self, monkeypatch):
        monkeypatch.setattr(ash.time, "sleep", lambda *_a, **_k: None)
        llm = FakeLLM([
            {"action": "keyword", "keyword": "scroll", "params": ["down"],
             "completed": False, "reason": "reveal"},
            {"action": "keyword", "keyword": "press_element", "params": ["Login"],
             "completed": True, "reason": "press it"},
        ])
        llm.instances = [object()]  # InstanceFallback-like truthiness gate
        ak = _make_action_keyword(ai_self_heal=True, llm=llm)
        # Mock strategy manager to return valid screenshot bytes and no page source.
        shot = np.zeros((10, 10, 3), dtype=np.uint8)
        ak.strategy_manager.capture_screenshot = MagicMock(return_value=shot)
        ak.strategy_manager.capture_pagesource = MagicMock(return_value=None)

        # scroll is non-locating, so `_heal_execute` calls the real method; let it
        # run against the mocked `ak.driver` and assert the call reached the driver
        # with the parsed params (`_heal_dispatch` binds the real method at __init__,
        # so reassigning `ak.scroll` here would never be consulted — see press_element
        # below for the correct way to intercept a locating keyword).
        # press_element runs `_locate_and_act`, which needs a working
        # strategy_manager.locate; mock it to return a located result.
        mock_result = MagicMock()
        mock_result.is_coordinates = False
        mock_result.value = MagicMock()
        mock_result.strategy = MagicMock()
        ak.strategy_manager.locate = MagicMock(return_value=iter([mock_result]))

        assert ak._ai_self_heal("Login", "press_element", (), shot) is True
        ak.driver.scroll.assert_called_once_with("down", 1000, event_name=None)
        # Healed keyword is recorded as a breadcrumb (may appear more than once —
        # the inner press_element records one, and _log_heal_outcome records another).
        steps = list(ak._recent_steps)
        assert any(s == ("press_element", ["Login"]) for s in steps)


# --------------------------------------------------------------------------------------------
# ActionKeyword._heal_execute: shlex parsing, dispatch-table lookup, error surfacing.
#
# These substitute entries in `_heal_dispatch` directly rather than reassigning
# `ak.<method>` — `_heal_execute` looks the callable up fresh from `_heal_dispatch` on
# every call, so that's the correct interception point (see the comment on
# `test_active_press_element_heals` above for why reassigning the instance attribute
# doesn't work).
# --------------------------------------------------------------------------------------------


class TestHealExecute:
    def test_unknown_keyword_returns_not_ok(self):
        ak = _make_action_keyword(ai_self_heal=True, llm=MagicMock(instances=[object()]))
        result = ak._heal_execute("frobnicate foo")
        assert result.ok is False
        assert "Unknown keyword: frobnicate" in result.message

    def test_empty_line_returns_not_ok(self):
        ak = _make_action_keyword(ai_self_heal=True, llm=MagicMock(instances=[object()]))
        result = ak._heal_execute("")
        assert result.ok is False
        assert "Empty keyword line" in result.message

    def test_unbalanced_quotes_return_parse_error(self):
        ak = _make_action_keyword(ai_self_heal=True, llm=MagicMock(instances=[object()]))
        result = ak._heal_execute('scroll "unterminated')
        assert result.ok is False
        assert "Parse error" in result.message

    def test_dispatches_with_parsed_positional_params(self):
        """A quoted multi-word param built via `_build_line` round-trips through
        `shlex.split` and reaches the dispatched callable as separate positional args."""
        ak = _make_action_keyword(ai_self_heal=True, llm=MagicMock(instances=[object()]))
        captured = []
        ak._heal_dispatch["enter_text"] = lambda element, text: captured.append((element, text))

        line = AISelfHealHandler._build_line("enter_text", ["Search box", "hello world"])
        result = ak._heal_execute(line)

        assert result.ok is True
        assert captured == [("Search box", "hello world")]

    def test_opticserror_from_dispatched_method_surfaces_message(self):
        ak = _make_action_keyword(ai_self_heal=True, llm=MagicMock(instances=[object()]))

        def boom(element):
            raise OpticsError(Code.E0201, message="element not found")

        ak._heal_dispatch["press_element"] = boom
        result = ak._heal_execute("press_element Login")

        assert result.ok is False
        assert "element not found" in result.message

    def test_recursion_guard_disables_and_restores_toggle(self):
        """`ai_self_heal_enabled` must be off for the duration of the dispatched call
        (so a nested locate failure can't re-trigger self-heal) and restored afterwards
        — even when the dispatched method raises."""
        ak = _make_action_keyword(ai_self_heal=True, llm=MagicMock(instances=[object()]))
        seen_enabled = []

        def spy(direction):
            seen_enabled.append(ak.ai_self_heal_enabled)
            raise RuntimeError("device offline")

        ak._heal_dispatch["scroll"] = spy
        result = ak._heal_execute("scroll down")

        assert result.ok is False
        assert "device offline" in result.message
        assert seen_enabled == [False]
        assert ak.ai_self_heal_enabled is True


class TestSuggestedStepsWiring:
    def test_pop_last_heal_info_exposes_structured_suggested_steps(self, monkeypatch):
        monkeypatch.setattr(ash.time, "sleep", lambda *_a, **_k: None)
        # Single completing step: curation short-circuits (<=1 step), so no extra LLM turn.
        llm = FakeLLM([
            {"action": "keyword", "keyword": "press_element", "params": ["Login"],
             "completed": True, "reason": "press it"},
        ])
        llm.instances = [object()]
        ak = _make_action_keyword(ai_self_heal=True, llm=llm)
        shot = np.zeros((10, 10, 3), dtype=np.uint8)
        ak.strategy_manager.capture_screenshot = MagicMock(return_value=shot)
        ak.strategy_manager.capture_pagesource = MagicMock(return_value=None)
        mock_result = MagicMock()
        mock_result.is_coordinates = False
        mock_result.value = MagicMock()
        mock_result.strategy = MagicMock()
        ak.strategy_manager.locate = MagicMock(return_value=iter([mock_result]))

        assert ak._ai_self_heal("Login", "press_element", (), shot) is True
        info = ak._pop_last_heal_info()
        assert info is not None
        assert info["suggested_steps"] == [{"keyword": "press_element", "params": ["Login"]}]
        assert "press_element Login" in info["summary"]
        # Read-and-clear: a second pop returns nothing so a heal never leaks onto the next call.
        assert ak._pop_last_heal_info() is None
