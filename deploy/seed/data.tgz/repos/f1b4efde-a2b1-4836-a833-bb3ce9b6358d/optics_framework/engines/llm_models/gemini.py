from typing import Optional, List, Dict, Any

from optics_framework.common.llm_interface import LLMInterface, image_mime_type, missing_extra_error, request_timeout_s
from optics_framework.common.logging_config import internal_logger
from optics_framework.common.error import OpticsError, Code
from optics_framework.common.google_credentials import service_account_credentials

# The google-genai SDK is an optional extra (``optics-framework[gemini]``). Import is guarded
# so merely importing this module never fails when the extra is absent; the actionable error
# is raised on instantiation, i.e. only when a 'gemini' engine is actually enabled in config.
try:
    from google import genai
    from google.genai import types as genai_types

    _IMPORT_ERROR: Optional[Exception] = None
except ImportError as exc:  # pragma: no cover - exercised only without the extra installed
    genai = None  # type: ignore[assignment]
    genai_types = None  # type: ignore[assignment]
    _IMPORT_ERROR = exc


_DEFAULT_MODEL = "gemini-2.5-flash"


def _vertex_kwargs(caps: dict[str, Any]) -> dict[str, Any]:
    """The Vertex AI client settings in ``caps``; a ``credentials_path`` key selects Vertex AI in the key's project."""
    kwargs: dict[str, Any] = {key: caps[key] for key in ("project", "location") if caps.get(key)}
    if "use_vertexai" in caps:
        kwargs["vertexai"] = bool(caps["use_vertexai"])
    if caps.get("credentials_path"):
        credentials = service_account_credentials(caps["credentials_path"])
        kwargs["credentials"] = credentials
        kwargs.setdefault("vertexai", True)
        if kwargs["vertexai"]:
            kwargs.setdefault("project", credentials.project_id)
    return kwargs


class GeminiLLM(LLMInterface):
    """
    Google Gemini engine (``google-genai`` SDK), supporting both the Gemini Developer API
    and Vertex AI. With no explicit ``capabilities`` the SDK auto-selects the backend and
    credentials from the environment (``GOOGLE_GENAI_USE_VERTEXAI``,
    ``GOOGLE_API_KEY`` / ``GEMINI_API_KEY``, ``GOOGLE_CLOUD_PROJECT``,
    ``GOOGLE_CLOUD_LOCATION``, ``GOOGLE_APPLICATION_CREDENTIALS``). Capabilities override env
    when present; secrets are never hardcoded.
    """

    def __init__(self, config: Optional[Dict[str, Any]] = None):
        if genai is None:
            raise missing_extra_error("gemini", "google-genai", _IMPORT_ERROR)

        caps: Dict[str, Any] = (config or {}).get("capabilities") or {}
        self.model_name: str = caps.get("model", _DEFAULT_MODEL)
        # Unset means the model's own default: Gemini 3 documents looping and degraded
        # output below 1.0, so pinning 0.0 is an explicit capabilities opt-in.
        self.temperature: Optional[float] = caps.get("temperature")

        # Explicit overrides win over env vars; absent kwargs fall back to SDK env auto-config.
        client_kwargs: Dict[str, Any] = {
            "http_options": genai_types.HttpOptions(timeout=int(request_timeout_s(caps) * 1000)),
            **_vertex_kwargs(caps),
        }
        api_key = caps.get("api_key") or caps.get("gemini_api_key")
        if api_key:
            client_kwargs["api_key"] = api_key
            internal_logger.warning(
                "GeminiLLM: an API key was read from the config 'capabilities'. Storing "
                "secrets in a plaintext config is insecure — prefer the GOOGLE_API_KEY / "
                "GEMINI_API_KEY environment variables, and never commit a config with a key."
            )

        try:
            self.client = genai.Client(**client_kwargs)
        except Exception as exc:  # noqa: BLE001 - surface any client/auth init failure uniformly
            raise OpticsError(
                Code.E0601, message=f"Failed to initialize Gemini client: {exc}"
            ) from exc
        internal_logger.debug("GeminiLLM initialized with model '%s'", self.model_name)

    def generate(
        self,
        prompt: str,
        images: Optional[List[bytes]] = None,
        system: Optional[str] = None,
        response_schema: Optional[Dict[str, Any]] = None,
        *,
        temperature: Optional[float] = None,
    ) -> str:
        contents: List[Any] = [prompt]
        if images:
            for img in images:
                contents.append(
                    genai_types.Part.from_bytes(data=img, mime_type=image_mime_type(img))
                )

        config_kwargs: Dict[str, Any] = {}
        effective_temperature = self.temperature if temperature is None else temperature
        if effective_temperature is not None:
            config_kwargs["temperature"] = effective_temperature
        if system:
            config_kwargs["system_instruction"] = system
        if response_schema is not None:
            config_kwargs["response_mime_type"] = "application/json"
            config_kwargs["response_json_schema"] = response_schema
        gen_config = genai_types.GenerateContentConfig(**config_kwargs)

        try:
            response = self.client.models.generate_content(
                model=self.model_name, contents=contents, config=gen_config
            )
        except Exception as exc:  # noqa: BLE001 - normalize all SDK/transport errors
            raise OpticsError(
                Code.E0801, message=f"Gemini request failed: {exc}"
            ) from exc
        usage = getattr(response, "usage_metadata", None)
        if usage is not None:
            internal_logger.debug(
                "Gemini usage (%s): prompt=%s cached=%s output=%s thoughts=%s",
                self.model_name, usage.prompt_token_count, usage.cached_content_token_count,
                usage.candidates_token_count, usage.thoughts_token_count,
            )
        return response.text or ""
