import time
from typing import Optional, Any, Tuple, List
from lxml import etree  # type: ignore
from appium.webdriver.webdriver import WebDriver
from appium.webdriver.common.appiumby import AppiumBy
from selenium.common.exceptions import NoSuchElementException
from optics_framework.common.logging_config import internal_logger, execution_logger
from optics_framework.common import utils
from optics_framework.common.elementsource_interface import ElementSourceInterface
from optics_framework.common.error import OpticsError, Code

APPIUM_NOT_INITIALISED_MSG = "Appium driver is not initialized for AppiumPageSource."

class AppiumPageSource(ElementSourceInterface):
    REQUIRED_DRIVER_TYPE = "appium"
    """
    Appium Find Element Class
    """

    driver: Optional[Any]  # Can be Appium WebDriver or Appium wrapper
    tree: Optional[Any]
    root: Optional[Any]

    def __init__(self, driver: Optional[Any] = None):
        """
        Initialize the Appium Page Source Class.
        Args:
            driver: The Appium driver instance (should be passed explicitly).
        """
        self.driver = driver
        self.tree = None
        self.root = None

    def _require_webdriver(self) -> WebDriver:
        # If self.driver is None, raise error first
        if self.driver is None:
            internal_logger.error(
                APPIUM_NOT_INITIALISED_MSG
            )
            raise RuntimeError(
                APPIUM_NOT_INITIALISED_MSG
            )
        # If self.driver is a wrapper, extract the raw driver
        if hasattr(self.driver, "driver"):
            return self.driver.driver
        raise RuntimeError(APPIUM_NOT_INITIALISED_MSG)

    def capture(self):
        """
        Capture the current screen state.

        return """
        internal_logger.exception('Appium Page Source does not support capturing the screen state.')
        raise NotImplementedError(
            'Appium Page Source does not support capturing the screen state.')

    def get_page_source(self) -> Tuple[str, str]:
        """
        Get the page source of the current page.

        Returns:
            str: The page source.
        """
        time_stamp = utils.get_timestamp()

        driver = self._require_webdriver()
        page_source = driver.page_source
        self.tree = etree.ElementTree(etree.fromstring(page_source.encode('utf-8')))
        if self.tree is not None:
            self.root = self.tree.getroot()
        else:
            self.root = None
        internal_logger.debug('Page source fetched at: %s', time_stamp)
        return str(page_source), str(time_stamp)

    def get_interactive_elements(self, filter_config: Optional[List[str]] = None, compact: bool = False):
        if self.driver is not None and hasattr(self.driver, "ui_helper"):
            return self.driver.ui_helper.get_interactive_elements(filter_config, compact=compact)
        internal_logger.error(APPIUM_NOT_INITIALISED_MSG)
        raise RuntimeError(APPIUM_NOT_INITIALISED_MSG)

    def _strict_element_match(self) -> bool:
        """Whether project config requests exact-only matching (Config.strict_element_match).

        Governs both locate and presence/assert checks so the two stay uniform -- see
        assert_elements. Defaults False (fuzzy) when the config chain is unavailable.
        """
        try:
            return bool(self.driver.event_sdk.config_handler.config.strict_element_match)
        except AttributeError:
            return False

    def _locate_by_text(self, driver: WebDriver, element: str, element_type: str, index: Optional[int] = None) -> Any:
        locator = utils.without_prefix(element, "text=")
        strict = self._strict_element_match()
        if index is not None:
            xpath = self.find_xpath_from_text_index(locator, index, strict=strict)
        else:
            xpath = self.find_xpath_from_text(locator, strict=strict)
        if not xpath:
            raise OpticsError(Code.E0201, message=f"Element of type {element_type} not found in the page source: {element}")
        try:
            execution_logger.debug(f"Finding element by text: {locator} with xpath: {xpath}")
            element_obj = driver.find_element(AppiumBy.XPATH, xpath)
            return element_obj
        except NoSuchElementException as e:
            raise OpticsError(Code.E0201, message=f"Element of type {element_type} not found using: {element}", cause=e) from e
        except Exception as e:
            internal_logger.exception("Error finding element by text: %s: %s", xpath, e)
            raise RuntimeError("Error finding element by text.") from e

    def _locate_by_xpath(self, driver: WebDriver, element: str, element_type: str) -> Any:
        if self.driver is not None and hasattr(self.driver, "ui_helper") and self.driver.ui_helper is not None:
            xpath, _ = self.driver.ui_helper.find_xpath(element, strict=self._strict_element_match())
            if not xpath:
                raise OpticsError(Code.E0201, message=f"Element of type {element_type} not found in the page source: {element}")
            try:
                element_obj = driver.find_element(AppiumBy.XPATH, xpath)
                return element_obj
            except NoSuchElementException as e:
                raise OpticsError(Code.E0201, message=f"Element of type {element_type} not found using: {element}", cause=e) from e
            except Exception as e:
                internal_logger.exception("Error finding element by xpath: %s: %s", xpath, e)
                raise RuntimeError("Error finding element by xpath.") from e
        else:
            internal_logger.error(APPIUM_NOT_INITIALISED_MSG)
            raise RuntimeError(APPIUM_NOT_INITIALISED_MSG)

    def can_locate(self, element: str) -> bool:
        element_type = utils.determine_element_type(element)
        if element_type == "XPath":
            return not (utils.is_dom_only_xpath(element) and self.driver is not None and self.driver.native_ui_platform())
        return element_type in ("Text",)

    def locate(self, element: str, index: Optional[int] = None) -> Any:
        """
        Locate a UI element on the current page using Appium.

        This method determines the type of the element (text, XPath, or image) and attempts
        to locate it using the Appium driver. Image-based search is not supported.

        Args:
            element (str): The element identifier to locate. This can be text, an XPath, or an image path.
            index (int, optional): If multiple elements match the given text, the index specifies
                which one to retrieve. Used only when element type is text.

        Returns:
            The found WebElement object if found, None otherwise. For unsupported types (e.g., image), returns None.
        """
        driver = self._require_webdriver()
        element_type = utils.determine_element_type(element)

        if element_type == 'Image':
            internal_logger.debug('Appium Page Source does not support finding images.')
            return None
        elif element_type == 'Text':
            return self._locate_by_text(driver, element, element_type, index)
        elif element_type == 'XPath':
            return self._locate_by_xpath(driver, element, element_type)
        raise RuntimeError("Unknown element type.")

    def get_element_bboxes(
        self, elements: List[str]
    ) -> List[Optional[Tuple[Tuple[int, int], Tuple[int, int]]]]:
        """
        Return bounding boxes for each element using WebElement location and size.
        Compatible with Android (UIAutomator2) and iOS (XCUITest); both expose
        W3C location/size/rect on the WebElement.
        """
        def locate_safe(element: str) -> Any:
            try:
                return self.locate(element)
            except Exception:
                return None

        return utils.bboxes_from_webelements(locate_safe, elements)

    def get_bbox_for_element(
        self, element: Any
    ) -> Optional[Tuple[Tuple[int, int], Tuple[int, int]]]:
        """
        Return bounding box for an already-located Appium WebElement.
        Uses location/size or rect first (Android and iOS); falls back to
        get_attribute("bounds") (Android) or get_attribute("rect") (iOS).
        """
        bbox = utils.bbox_from_webelement_like(element)
        if bbox is not None:
            return bbox
        return utils.bbox_from_appium_attribute_fallback(element)

    def locate_using_index(self, element, index, strategy=None) -> Optional[Any]:
        if self.driver is not None and hasattr(self.driver, "ui_helper") and self.driver.ui_helper is not None:
            locators = self.driver.ui_helper.get_locator_and_strategy_using_index(
                element, index, strategy, strict=self._strict_element_match()
            )
            if locators:
                strategy = locators['strategy']
                locator = locators['locator']
                xpath = self.driver.ui_helper.get_view_locator(strategy=strategy, locator=locator)
                try:
                    element_obj = self._require_webdriver().find_element(AppiumBy.XPATH, xpath)
                except NoSuchElementException:
                    return None
                except Exception as e:
                    internal_logger.exception("Error finding element by index: %s: %s", xpath, e)
                    return None
                return element_obj
            return None
        else:
            internal_logger.error(APPIUM_NOT_INITIALISED_MSG)
            raise RuntimeError(APPIUM_NOT_INITIALISED_MSG)


    def assert_elements(self, elements, timeout=30, rule='any'):
        """
        Assert the presence of elements on the current page.

        Args:
            elements (list): List of elements to assert on the page.
            timeout (int): Maximum time to wait for the elements to appear.
            rule (str): Rule to apply ("any" or "all").

        Returns:
            None

        Raises:
            Exception: If elements are not found based on the rule within the timeout.
        """
        self._validate_rule(rule)
        start_time = time.time()
        while time.time() - start_time < timeout:
            if (all if rule == "all" else any)(self.check_elements(elements)):
                return True, utils.get_timestamp()
            time.sleep(0.3)

        # Timeout reached
        internal_logger.warning(f"Timeout reached. Rule: {rule}, Elements: {elements}")
        raise TimeoutError(
            f"Timeout reached: Elements not found based on rule '{rule}': {elements}"
        )

    def check_elements(self, elements: list[str], visible: bool = False) -> list[bool]:
        self.get_page_source()
        strict = self._strict_element_match()
        return [self._in_page_source(element, strict) for element in elements]

    def _in_page_source(self, element: str, strict: bool) -> bool:
        element_type = utils.determine_element_type(element)
        if element_type == "Text":
            return bool(self.ui_text_search([element], strict=strict))
        if element_type == "XPath" and getattr(self.driver, "ui_helper", None) is not None:
            return bool(self.driver.ui_helper.find_xpath(element, strict=strict)[0])
        return False

    def _validate_rule(self, rule):
        if rule not in ["any", "all"]:
            raise ValueError("Invalid rule. Use 'any' or 'all'.")

    def find_xpath_from_text(self, text, strict: bool = False):
        """
        Find the XPath of an element based on the text content.

        Args:
            text (str): The text content to search for in the UI tree.
            strict (bool): if True, only exact/suffix matches are considered.

        Returns:
            str: The XPath of the element containing the
            text content, or None if not found.
        """
        if self.driver is not None and hasattr(self.driver, "ui_helper") and self.driver.ui_helper is not None:
            locators = self.driver.ui_helper.get_locator_and_strategy(text, strict=strict)
            if locators:
                strategy = locators['strategy']
                locator = locators['locator']
                xpath = self.driver.ui_helper.get_view_locator(strategy=strategy, locator=locator)
                return xpath
        else:
            internal_logger.error(APPIUM_NOT_INITIALISED_MSG)
            raise RuntimeError(APPIUM_NOT_INITIALISED_MSG)
        raise RuntimeError("Failed to find XPath from text.")

    def find_xpath_from_text_index(self, text, index, strategy=None, strict: bool = False):
        if self.driver is not None and hasattr(self.driver, "ui_helper") and self.driver.ui_helper is not None:
            locators = self.driver.ui_helper.get_locator_and_strategy_using_index(
                text, index, strategy, strict=strict
            )
            if locators:
                strategy = locators['strategy']
                locator = locators['locator']
                utils.warn_if_ambiguous(text, locators.get('count', 1), index)
                if locators.get('occurrence', 1) > 1:
                    return self.driver.ui_helper.nth_view_locator(strategy, locator, locators['occurrence'])
                return self.driver.ui_helper.get_view_locator(strategy=strategy, locator=locator)
            return None
        else:
            internal_logger.error(APPIUM_NOT_INITIALISED_MSG)
            raise RuntimeError(APPIUM_NOT_INITIALISED_MSG)

    def _validate_tree(self):
        """Validates that the element tree is initialized."""
        if self.tree is None:
            internal_logger.error("Element tree is not initialized. Cannot perform xpath search.")
            raise RuntimeError("Element tree is not initialized.")

    def _search_text_in_attribute(self, text, attrib, strict: bool = False):
        """Searches for text in a specific attribute across all elements."""
        matching_elements = self.tree.xpath(f"//*[@{attrib}]")

        for elem in matching_elements:
            attrib_value = elem.attrib.get(attrib, '').strip()
            if attrib_value and utils.compare_text(attrib_value, text, strict=strict):
                internal_logger.debug(f"Match found using {attrib} for '{text}'")
                return True
        return False

    def _search_single_text(self, text, strict: bool = False):
        """Searches for a single text across all strategies."""
        strategies = ["text", "resource-id", "content-desc", "name", "value", "label"]
        internal_logger.debug(f'Searching for text: {text}')

        for attrib in strategies:
            if self._search_text_in_attribute(text, attrib, strict):
                return True
        return False

    def ui_text_search(self, texts, rule='any', strict: bool = False):
        """
        Checks if any or all given texts exist in the UI tree.

        Args:
            texts (list): List of text strings to search for.
            rule (str): Rule for matching ('any' or 'all').
            strict (bool): if True, only exact matches are considered -- no partial/fuzzy fallback.

        Returns:
            bool: True if the condition is met, otherwise False.
        """
        self._validate_tree()
        found_texts = set()

        for text in texts:
            if self._search_single_text(text, strict):
                found_texts.add(text)
                if rule == 'any':
                    return True

        return len(found_texts) == len(texts) if rule == 'all' else False
