import time
from collections import Counter
from typing import Optional, Any, Tuple, List, Dict
from lxml import etree  # type: ignore

from optics_framework.common.logging_config import internal_logger
from optics_framework.common.elementsource_interface import ElementSourceInterface
from optics_framework.common.error import OpticsError, Code
from optics_framework.common import utils


PLAYWRIGHT_NOT_INITIALISED_MSG = (
    "Playwright driver is not initialized for PlaywrightPageSource."
)

# Compact web inspector (get_interactive_elements(compact=True)). HTML carries no
# clickable/editable attributes, so actionable nodes are inferred from tag/role/type.
WEB_TAP_TAGS = frozenset({"button", "summary", "label"})
WEB_TAP_ROLES = frozenset({
    "button", "link", "menuitem", "tab", "option", "checkbox", "radio", "switch",
    "menuitemcheckbox", "menuitemradio", "treeitem", "combobox", "slider", "spinbutton",
})
WEB_TOGGLE_INPUT_TYPES = frozenset({"checkbox", "radio"})
WEB_TOGGLE_ROLES = frozenset({"switch", "checkbox", "radio", "menuitemcheckbox", "menuitemradio"})
WEB_TEXT_INPUT_ROLES = frozenset({"textbox", "searchbox"})
WEB_TEXT_INPUT_TYPES = frozenset({
    "text", "search", "email", "password", "tel", "url", "number",
    "date", "datetime-local", "month", "time", "week",
})
WEB_SKIP_TAGS = frozenset(
    {"script", "style", "meta", "link", "title", "head", "noscript", "template"}
)
WEB_MEDIA_TAGS = frozenset({"img", "svg", "canvas", "video", "audio", "iframe"})
WEB_INLINE_TAGS = frozenset({
    "a", "abbr", "b", "bdi", "bdo", "br", "cite", "code", "data", "dfn", "em", "i", "kbd",
    "mark", "q", "s", "samp", "small", "span", "strong", "sub", "sup", "time", "u", "var", "wbr",
}) | WEB_MEDIA_TAGS | WEB_SKIP_TAGS
WEB_TEST_ATTRS = ("data-testid", "data-test", "data-test-id", "data-qa", "data-cy")
WEB_COMPACT_LABEL_MAX_CHARS = 120

# Approximates Playwright's bounding_box() "not visible" -> null contract, which page JavaScript cannot reach.
BOUNDS_JS = r"""
(xpaths) => {
    const vv = window.visualViewport;
    const view = vv
        ? [vv.offsetTop, vv.offsetLeft, vv.offsetTop + vv.height, vv.offsetLeft + vv.width]
        : [0, 0, window.innerHeight, window.innerWidth];
    const shows = (el, rect) => {
        let [top, left, bottom, right] = [rect.top, rect.left, rect.bottom, rect.right];
        for (let node = el.parentElement; node; node = node.parentElement) {
            if (window.getComputedStyle(node).overflow === 'visible') continue;
            const clip = node.getBoundingClientRect();
            [top, left] = [Math.max(top, clip.top), Math.max(left, clip.left)];
            [bottom, right] = [Math.min(bottom, clip.bottom), Math.min(right, clip.right)];
        }
        [top, left] = [Math.max(top, view[0]), Math.max(left, view[1])];
        [bottom, right] = [Math.min(bottom, view[2]), Math.min(right, view[3])];
        return bottom > top && right > left;
    };
    return xpaths.map((xp) => {
        if (!xp) return null;
        try {
            const el = document.evaluate(
                xp, document, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null
            ).singleNodeValue;
            if (!el) return null;
            const rect = el.getBoundingClientRect();
            if (!rect || rect.width <= 0 || rect.height <= 0) return null;
            const style = window.getComputedStyle(el);
            if (style.visibility === 'hidden' || style.display === 'none') return null;
            return {
                x: rect.x, y: rect.y, width: rect.width, height: rect.height,
                offscreen: !shows(el, rect),
                pointer: style.cursor === 'pointer',
            };
        } catch (e) {
            return null;
        }
    });
}
"""

# Per xpath: a locator matching only that node, or null. Rungs run most durable first.
SUGGEST_LOCATORS_JS = r"""
(xpaths) => {
    const TEST_ATTRS = ['data-testid', 'data-test', 'data-test-id', 'data-qa', 'data-cy'];
    const NAMING_ATTRS = ['name', 'placeholder', 'aria-label', 'title', 'alt'];
    const TEXT_ATTRS = new Set(['aria-label', 'title', 'alt']);
    const STATE_CLASS = /^(is-|has-)?(active|selected|current|open|closed|disabled|hidden|focus(ed)?|hover|checked|expanded|collapsed|show(n)?|visible|loading)$/i;
    const HEADINGS = new Set(['h1', 'h2', 'h3', 'h4', 'h5', 'h6', 'legend', 'caption', 'th', 'dt', 'label']);
    const MAX_TEXT = 80;
    const MAX_ANCESTORS = 5;
    const MAX_LANDMARKS = 3;
    const norm = (s) => (s || '').replace(/[ \t\r\n]+/g, ' ').trim();
    const hasDigit = (v) => /\d/.test(v);
    const generatedName = (v) => !/^[A-Za-z_-][\w-]*$/.test(v) || /\d{3,}/.test(v)
        || (v.match(/[0-9a-f]{6,}/gi) || []).some((run) => /\d/.test(run) && /[a-f]/i.test(run));
    const cssQuote = (v) => '"' + v.replace(/\\/g, '\\\\').replace(/"/g, '\\"') + '"';
    const xpQuote = (v) => {
        if (!v.includes("'")) return "'" + v + "'";
        if (!v.includes('"')) return '"' + v + '"';
        return 'concat(' + v.split("'").map((part) => "'" + part + "'").join(`, "'", `) + ')';
    };
    const cssMatches = (sel, root) => {
        try { return (root || document).querySelectorAll(sel); } catch (e) { return []; }
    };
    const xpMatches = (xp, root) => {
        try {
            const hits = document.evaluate(xp, root || document, null, XPathResult.ORDERED_NODE_SNAPSHOT_TYPE, null);
            return Array.from({ length: hits.snapshotLength }, (_, i) => hits.snapshotItem(i));
        } catch (e) {
            return [];
        }
    };
    const only = (hits, el) => hits.length === 1 && hits[0] === el;
    // Text steps for `tag` holding `text`: the exact text and, when it holds digits, its leading words.
    const textSteps = (tag, text) => {
        if (!text || text.length > MAX_TEXT) return [];
        const exact = { css: null, xp: `${tag}[normalize-space()=${xpQuote(text)}]`, digits: hasDigit(text) };
        if (!exact.digits) return [exact];
        const lead = text.slice(0, text.search(/\d/)).trim();
        if (!/\p{L}{2}/u.test(lead)) return [exact];
        return [{ css: null, xp: `${tag}[starts-with(normalize-space(), ${xpQuote(lead)})]`, digits: false }, exact];
    };
    // One step names an element on its own: {css, xp, digits}; css is null for text steps.
    const steps = (el, withText) => {
        const tag = el.tagName.toLowerCase();
        const out = [];
        for (const attr of TEST_ATTRS) {
            const v = el.getAttribute(attr);
            if (v) out.push({ css: `[${attr}=${cssQuote(v)}]`, xp: `*[@${attr}=${xpQuote(v)}]`, digits: hasDigit(v) });
        }
        if (el.id && !generatedName(el.id)) out.push({ css: '#' + el.id, xp: `*[@id=${xpQuote(el.id)}]`, digits: false });
        for (const attr of NAMING_ATTRS) {
            const v = el.getAttribute(attr);
            if (v) {
                out.push({
                    css: `${tag}[${attr}=${cssQuote(v)}]`, xp: `${tag}[@${attr}=${xpQuote(v)}]`,
                    digits: TEXT_ATTRS.has(attr) && hasDigit(v),
                });
            }
        }
        const href = tag === 'a' && el.getAttribute('href');
        if (href) out.push({ css: `a[href=${cssQuote(href)}]`, xp: `a[@href=${xpQuote(href)}]`, digits: false });
        if (withText) out.push(...textSteps(tag, norm(el.textContent)));
        for (const name of el.classList) {
            if (generatedName(name) || STATE_CLASS.test(name)) continue;
            out.push({
                css: `${tag}.${name}`,
                xp: `${tag}[contains(concat(' ', normalize-space(@class), ' '), ' ${name} ')]`,
                digits: false,
            });
        }
        return out;
    };
    const render = (cssParts, xpParts) => cssParts.every((part) => part !== null)
        ? 'css=' + cssParts.join(' ')
        : 'xpath=//' + xpParts.join('//');
    const unique = (cssParts, xpParts, el) => cssParts.every((part) => part !== null)
        ? only(cssMatches(cssParts.join(' ')), el)
        : only(xpMatches('//' + xpParts.join('//')), el);
    // Text leaves inside an ancestor that can tell it apart: headings first, in page order.
    const landmarks = (ancestor, el) => {
        const leaves = [];
        for (const node of ancestor.querySelectorAll('*')) {
            if (node.children.length || el.contains(node) || node.contains(el)) continue;
            const text = norm(node.textContent);
            if (text && text.length <= MAX_TEXT) leaves.push({ node, text });
        }
        leaves.sort((a, b) => HEADINGS.has(b.node.tagName.toLowerCase()) - HEADINGS.has(a.node.tagName.toLowerCase()));
        return leaves.slice(0, MAX_LANDMARKS).flatMap(({ node, text }) => textSteps(node.tagName.toLowerCase(), text).map(
            (step) => ({ css: null, xp: `${ancestor.tagName.toLowerCase()}[.//${step.xp}]`, digits: step.digits })
        ));
    };
    const ancestors = (el) => {
        const out = [];
        for (let node = el.parentElement; node && node !== document.body && node !== document.documentElement
            && out.length < MAX_ANCESTORS; node = node.parentElement) out.push(node);
        return out;
    };
    const structural = (el) => {
        const parts = [];
        for (let node = el; node && node.nodeType === 1; node = node.parentElement) {
            if (node !== el && node.id && !generatedName(node.id) && only(cssMatches('#' + node.id), node)) {
                parts.unshift('#' + node.id);
            } else {
                const tag = node.tagName.toLowerCase();
                const parent = node.parentElement;
                const same = parent ? Array.from(parent.children).filter((c) => c.tagName === node.tagName) : [node];
                parts.unshift(same.length > 1 ? `${tag}:nth-of-type(${same.indexOf(node) + 1})` : tag);
            }
            const sel = parts.join(' > ');
            if (only(cssMatches(sel), el)) return 'css=' + sel;
        }
        return null;
    };
    const suggest = (el) => {
        const own = steps(el, true);
        const relative = [...own, { css: el.tagName.toLowerCase(), xp: el.tagName.toLowerCase(), digits: false }];
        for (const digits of [false, true]) {
            for (const step of own) {
                if (step.digits === digits && unique([step.css], [step.xp], el)) return render([step.css], [step.xp]);
            }
            for (const ancestor of ancestors(el)) {
                const inside = relative.filter((step) => step.digits <= digits && (step.css
                    ? only(cssMatches(':scope ' + step.css, ancestor), el)
                    : only(xpMatches('.//' + step.xp, ancestor), el)));
                if (!inside.length) continue;
                for (const anchor of [...steps(ancestor, false), ...landmarks(ancestor, el)]) {
                    if (anchor.digits > digits || !unique([anchor.css], [anchor.xp], ancestor)) continue;
                    for (const step of inside) {
                        if (unique([anchor.css, step.css], [anchor.xp, step.xp], el)) {
                            return render([anchor.css, step.css], [anchor.xp, step.xp]);
                        }
                    }
                }
            }
        }
        return structural(el);
    };
    return xpaths.map((xp) => {
        if (!xp) return null;
        try {
            const el = document.evaluate(
                xp, document, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null
            ).singleNodeValue;
            return el && el.nodeType === 1 ? suggest(el) : null;
        } catch (e) {
            return null;
        }
    });
}
"""


def _has_word(text: str) -> bool:
    # Punctuation alone ("|", "(") is layout, not something to read or assert on.
    return any(ch.isalnum() for ch in text)


def _own_text(node: etree.Element) -> str:
    return (node.text or "") + "".join(child.tail or "" for child in node)


class WebDomInspector:
    """lxml-side half of the web element sources; :meth:`_inspect_nodes` is the only browser round trip."""

    tree: Any = None

    def _inspect_nodes(
        self, xpaths: List[Optional[str]], locate: List[Optional[str]]
    ) -> Tuple[Optional[List[Optional[Dict[str, Any]]]], List[Optional[str]]]:
        """Rects for ``xpaths`` (``None`` if the batch failed) and a locator per aligned ``locate`` entry."""
        raise NotImplementedError

    def _web_interactive_elements(self, filter_config: Optional[List[str]], compact: bool) -> List[Dict]:
        if self.tree is None:
            return []
        if compact:
            return self._extract_compact_web_interactives()
        nodes = [(node, self._compact_web_candidate(node)) for node in self.tree.xpath(".//*")]
        # Unfiltered, list what the compact view does, not every wrapper.
        if filter_config:
            nodes = [(node, candidate) for node, candidate in nodes if self._should_include_element(node, filter_config)]
        else:
            nodes = [(node, candidate) for node, candidate in nodes if candidate is not None]
        xpaths = [self._build_simple_xpath(node) for node, _ in nodes]
        # Locating every node would be slow, so only the useful ones get a loc.
        locate = [xp if candidate is not None else None for (_, candidate), xp in zip(nodes, xpaths)]
        rects, locators = self._inspect_nodes(xpaths, locate)
        if rects is None:
            # No bounds means every element would be dropped below anyway; keep the
            # pre-batching "no elements this pass" result for this best-effort list.
            return []
        entries = (
            self._web_entry(node, rect, locator, None if filter_config else candidate[0])
            for (node, candidate), rect, locator in zip(nodes, rects, locators)
        )
        return [entry for entry in entries if entry is not None]

    def _web_entry(
        self, node: etree.Element, rect: Optional[Dict[str, Any]], locator: Optional[str], label: Optional[str]
    ) -> Optional[Dict[str, Any]]:
        bounds = self._rect_to_bounds(rect)
        if not bounds:
            return None

        text, used_key = (label, None) if label else self._extract_display_text(node)
        if not text:
            # If no text-like attribute, use tag name
            text, used_key = node.tag, None

        xpath = self.get_xpath(node)
        extra = self._build_extra_metadata(node.attrib, used_key, node.tag)

        entry = {"text": text, "bounds": bounds, "xpath": xpath, "extra": extra}
        if locator:
            entry["loc"] = locator
        if rect.get("offscreen"):
            entry["offscreen"] = True
        return entry

    def _try_inner_text(self, node: etree.Element) -> Tuple[Optional[str], Optional[str]]:
        """The node's descendant text, as a stand-in for the browser's innerText."""
        text = " ".join("".join(node.itertext()).split())
        return (text, "innerText") if text else (None, None)

    @staticmethod
    def _rect_to_bounds(rect: Optional[Dict[str, float]]) -> Optional[Dict[str, int]]:
        """Convert a ``{x,y,width,height}`` rect (or ``None``) into ``{x1,y1,x2,y2}``."""
        if not rect:
            return None
        try:
            x1 = int(rect["x"])
            y1 = int(rect["y"])
            x2 = int(rect["x"] + rect["width"])
            y2 = int(rect["y"] + rect["height"])
        except (KeyError, TypeError, ValueError):
            return None
        return {"x1": x1, "y1": y1, "x2": x2, "y2": y2}

    def _escape_xpath_value(self, val: str) -> str:
        """
        Escape single quotes in XPath value.

        :param val: Value to escape
        :return: Escaped XPath value
        """
        if "'" not in val:
            return f"'{val}'"
        # Use concat for values with single quotes
        parts = val.split("'")
        return "concat('" + "', \"'\", '".join(parts) + "')"

    def _build_xpath_from_attribute(self, tag: str, attr_name: str, attr_value: str) -> str:
        """
        Build XPath from a single attribute.

        :param tag: Element tag name
        :param attr_name: Attribute name
        :param attr_value: Attribute value
        :return: XPath string
        """
        escaped_value = self._escape_xpath_value(attr_value)
        return f"//{tag}[@{attr_name}={escaped_value}]"

    def _try_unique_attributes(self, tag: str, attrs: dict) -> Optional[str]:
        """XPath from the first id, data-testid or name that no other node with this tag shares."""
        counts = self._attribute_counts()
        for attr_name in ["id", "data-testid", "name"]:
            value = attrs.get(attr_name)
            if value and counts[(tag, attr_name, value)] == 1:
                return self._build_xpath_from_attribute(tag, attr_name, value)
        return None

    def _attribute_counts(self) -> Counter:
        """How many nodes carry each ``(tag, attr, value)``; a shared attribute XPath would measure only the first."""
        cache = getattr(self, "_attribute_count_cache", None)
        if cache is None or cache[0] is not self.tree:
            counts: Counter = Counter(
                (node.tag, attr_name, node.attrib[attr_name])
                for node in self.tree.iter()
                for attr_name in ("id", "data-testid", "name")
                if node.attrib.get(attr_name)
            )
            cache = self._attribute_count_cache = (self.tree, counts)
        return cache[1]

    def _build_hierarchical_path(self, node: etree.Element) -> Optional[str]:
        """
        Build hierarchical XPath path with index.

        :param node: Element node
        :return: XPath path string or None
        """
        path = []
        current = node
        while current is not None and hasattr(current, "tag"):
            parent = current.getparent()
            if parent is None:
                path.insert(0, current.tag or "*")
                break

            siblings = [sib for sib in parent if sib.tag == current.tag]
            if len(siblings) > 1:
                idx = siblings.index(current) + 1
                path.insert(0, f"{current.tag}[{idx}]")
            else:
                path.insert(0, current.tag or "*")

            current = parent

        return "/" + "/".join(path) if path else None

    def _build_simple_xpath(self, node: etree.Element) -> Optional[str]:
        """
        Build a simple XPath for locating an element in Playwright.
        This is a fallback method for getting bounds.
        """
        if node is None or not hasattr(node, "tag"):
            return None

        tag = node.tag or "*"
        attrs = node.attrib or {}

        # Try unique attributes first
        xpath = self._try_unique_attributes(tag, attrs)
        if xpath:
            return xpath

        # Fallback to hierarchical path with index
        return self._build_hierarchical_path(node)

    def _try_text_content(self, node: etree.Element) -> Tuple[Optional[str], Optional[str]]:
        """
        Try to extract text from node text content or tail.

        :param node: Element node
        :return: Tuple of (text_value, attribute_used) or (None, None)
        """
        text_content = node.text
        if text_content and text_content.strip():
            return text_content.strip(), "text"

        if node.tail and node.tail.strip():
            return node.tail.strip(), "tail"

        return None, None

    def _try_attribute_text(self, attrs: dict, attr_name: str, key: str) -> Tuple[Optional[str], Optional[str]]:
        """
        Try to extract text from a specific attribute.

        :param attrs: Element attributes
        :param attr_name: Attribute name to check
        :param key: Key name to return
        :return: Tuple of (text_value, attribute_used) or (None, None)
        """
        value = attrs.get(attr_name, "").strip()
        if value:
            return value, key
        return None, None

    def _try_class_text(self, attrs: dict) -> Tuple[Optional[str], Optional[str]]:
        """
        Try to extract text from class attribute (last resort).

        :param attrs: Element attributes
        :return: Tuple of (text_value, attribute_used) or (None, None)
        """
        class_name = attrs.get("class", "").strip()
        if class_name:
            first_class = class_name.split()[0]
            if first_class:
                return first_class, "class"
        return None, None

    def _extract_display_text(self, node: etree.Element) -> Tuple[Optional[str], Optional[str]]:
        """
        Extract display text from a web element.

        Priority order:
        1. Text content from lxml element (fastest)
        2. aria-label
        3. title
        4. alt (for images)
        5. placeholder (for inputs)
        6. innerText (see :meth:`_try_inner_text`)
        7. id
        8. class (last resort)

        Returns:
            Tuple of (text_value, attribute_used)
        """
        attrs = node.attrib or {}

        # Try text content from lxml element first (fastest)
        text, key = self._try_text_content(node)
        if text:
            return text, key

        # Try attributes in priority order
        for attr_name, key_name in [("aria-label", "aria-label"), ("title", "title"),
                                     ("alt", "alt"), ("placeholder", "placeholder")]:
            text, key = self._try_attribute_text(attrs, attr_name, key_name)
            if text:
                return text, key

        text, key = self._try_inner_text(node)
        if text:
            return text, key

        # Try id
        text, key = self._try_attribute_text(attrs, "id", "id")
        if text:
            return text, key

        # Try class (last resort)
        return self._try_class_text(attrs)

    # ---------------------------------------------------------
    # Compact extraction helpers (get_interactive_elements(compact=True))
    # ---------------------------------------------------------

    def _web_is_hidden(self, node: etree.Element) -> bool:
        """Cheap hidden/disabled checks; CSS-driven hiding is caught by the bounds probe."""
        attrs = node.attrib or {}
        if attrs.get("hidden") is not None or (attrs.get("aria-hidden") or "").lower() == "true":
            return True
        if (node.tag or "").lower() == "input" and (attrs.get("type") or "").lower() == "hidden":
            return True
        style = (attrs.get("style") or "").lower().replace(" ", "")
        return "display:none" in style or "visibility:hidden" in style

    def _is_web_toggle(self, node: etree.Element) -> bool:
        tag = (node.tag or "").lower()
        attrs = node.attrib or {}
        role = (attrs.get("role") or "").lower()
        return (
            (tag == "input" and (attrs.get("type") or "").lower() in WEB_TOGGLE_INPUT_TYPES)
            or role in WEB_TOGGLE_ROLES
        )

    def _is_web_disabled(self, node: etree.Element) -> bool:
        """Native disabled or an ARIA widget marked non-operable."""
        attrs = node.attrib or {}
        return "disabled" in attrs or (attrs.get("aria-disabled") or "").lower() == "true"

    def _web_element_actions(self, node: etree.Element) -> List[str]:
        """Interactions a web node affords: tap/toggle/input (empty => none).

        Inferred from tag/role/type because HTML has none of UiAutomator2's action
        attributes. Scroll-only elements have no static signal and stay unclassified.
        """
        if self._web_is_hidden(node) or self._is_web_disabled(node):
            return []
        tag = (node.tag or "").lower()
        attrs = node.attrib or {}
        role = (attrs.get("role") or "").lower()
        input_type = (attrs.get("type") or "").lower()
        contenteditable = attrs.get("contenteditable")
        text_input = (
            (tag == "input" and (not input_type or input_type in WEB_TEXT_INPUT_TYPES))
            or tag == "textarea"
            or (contenteditable is not None and contenteditable.lower() != "false")
            or role in WEB_TEXT_INPUT_ROLES
        )
        clickable = (
            tag in WEB_TAP_TAGS
            or (tag == "a" and attrs.get("href"))
            or role in WEB_TAP_ROLES
            or "onclick" in attrs
            or tag in ("input", "select")
            or text_input
        )
        actions: List[str] = []
        if clickable:
            actions.append("tap")
        if self._is_web_toggle(node):
            actions.append("toggle")
        if text_input:
            actions.append("input")
        return actions

    def _web_own_label(self, node: etree.Element) -> str:
        """The node's own visible text, else its accessibility-ish attributes."""
        text = (node.text or "").strip()
        if text:
            return text
        attrs = node.attrib or {}
        for key in ("aria-label", "title", "alt", "placeholder", "value"):
            if key == "value" and (self._is_web_toggle(node) or (attrs.get("type") or "").lower() == "password"):
                continue  # a checkbox/radio value is a form payload and a password value a secret, not a label
            val = (attrs.get(key) or "").strip()
            if val:
                return val
        return self._label_for(node)

    def _label_for(self, node: etree.Element) -> str:
        cache = getattr(self, "_label_cache", None)
        if cache is None or cache[0] is not self.tree:
            labels: dict[str, str] = {}
            for label in self.tree.iter("label") if self.tree is not None else ():
                target = label.attrib.get("for")
                if target and target not in labels:
                    labels[target] = " ".join("".join(label.itertext()).split())
            cache = self._label_cache = (self.tree, labels)
        return cache[1].get(node.attrib.get("id") or "", "")

    def _web_folded_label(self, node: etree.Element) -> str:
        # An attribute label wins when the node has no direct text of its own; otherwise
        # fold in direct text, descendant text and inline tails.
        if not (node.text or "").strip():
            own = self._web_own_label(node)
            if own:
                return own[:WEB_COMPACT_LABEL_MAX_CHARS]
        parts: List[str] = []
        self._collect_web_text(node, parts)
        return " ".join(dict.fromkeys(parts))[:WEB_COMPACT_LABEL_MAX_CHARS]

    def _collect_web_text(self, node: etree.Element, parts: List[str]) -> None:
        # node.text is only the text before the first child and each child's tail is the
        # text after it, so both are needed to keep "Save <b>Changes</b> now" whole.
        # Nested actionable subtrees are not descended into.
        text = self._web_own_label(node)
        if text:
            parts.append(text)
        for child in node:
            if (
                isinstance(child.tag, str)
                and child.tag.lower() not in WEB_SKIP_TAGS
                and not self._web_element_actions(child)
            ):
                self._collect_web_text(child, parts)
            if child.tail and child.tail.strip():
                parts.append(child.tail.strip())

    def _web_folds_text(self, node: etree.Element) -> bool:
        return bool(self._web_element_actions(node))

    def _has_web_folding_ancestor(self, node: etree.Element) -> bool:
        return any(self._web_folds_text(parent) for parent in node.iterancestors())

    def _has_actionable_web_descendant(self, node: etree.Element) -> bool:
        return any(self._web_element_actions(child) for child in node.iterdescendants(etree.Element))

    def _compact_web_entry(
        self, node: etree.Element, label: str, actions: List[str], bounds: Dict,
        locator: str | None = None, offscreen: bool = False,
    ) -> Dict:
        extra = {"class": (node.tag or "").lower()}
        rid = node.attrib.get("id")
        if rid:
            extra["resource-id"] = rid
        if extra["class"] == "input" and (node.attrib.get("type") or "").lower() == "password":
            extra["password"] = True
        entry = {"text": label, "bounds": bounds, "act": actions, "extra": extra}
        if locator:
            entry["loc"] = locator
        if offscreen:
            entry["offscreen"] = True
        return entry

    def _compact_web_candidate(
        self, node: etree.Element
    ) -> Optional[Tuple[str, List[str]]]:
        """``(label, actions)`` for a node worth reporting, or ``None`` to drop it.

        Deliberately bounds-free so every kept node can be resolved in one batched
        lookup rather than a browser round trip each.
        """
        if not isinstance(node.tag, str) or node.tag.lower() in WEB_SKIP_TAGS:
            return None
        if self._web_is_hidden(node):
            return None
        actions = self._web_element_actions(node)
        if actions:
            label = self._web_folded_label(node)
            # An empty-labelled wrapper around another actionable element (a div around
            # its button) is noise; the inner element carries the label.
            if not label and self._has_actionable_web_descendant(node):
                return None
        else:
            if self._has_web_folding_ancestor(node) or (
                self._has_web_line_ancestor(node) and not self._is_web_media(node)
            ):
                return None
            label = self._web_reading(node)
            if label is None:
                return None
        return label, actions

    def _web_reading(self, node: etree.Element) -> Optional[str]:
        """What a non-actionable node shows a reader, or ``None`` when it is only layout.

        Media stays even unnamed; a wrapper named only by aria-label/title/test id stays when nothing inside is a row.
        """
        own = _own_text(node)
        if _has_word(own):
            text = self._web_line_text(node) if self._is_web_line(node) else own
            return " ".join(text.split())[:WEB_COMPACT_LABEL_MAX_CHARS]
        attrs = node.attrib or {}
        named = next((attrs[key].strip() for key in ("aria-label", "title", "alt") if (attrs.get(key) or "").strip()), "")
        if self._is_web_media(node):
            return named
        if len(node) == 0 and _has_word(label := self._web_own_label(node)):
            return label
        if (named or any(attrs.get(key) for key in WEB_TEST_ATTRS)) and not self._has_web_content_descendant(node):
            return named
        return None

    @staticmethod
    def _is_web_media(node: etree.Element) -> bool:
        return node.tag.lower() in WEB_MEDIA_TAGS or ((node.attrib or {}).get("role") or "").lower() == "img"

    def _is_web_line(self, node: etree.Element) -> bool:
        """Words with only inline markup inside, so the node reads as one line of text."""
        return _has_word(_own_text(node)) and all(
            not isinstance(child.tag, str) or child.tag.lower() in WEB_INLINE_TAGS for child in node
        )

    def _web_line_text(self, node: etree.Element) -> str:
        parts = [node.text or ""]
        for child in node:
            if isinstance(child.tag, str) and child.tag.lower() not in WEB_SKIP_TAGS and not self._web_is_hidden(child):
                parts.append(self._web_line_text(child))
            parts.append(child.tail or "")
        return " ".join(parts)

    def _has_web_line_ancestor(self, node: etree.Element) -> bool:
        return any(self._is_web_line(parent) for parent in node.iterancestors())

    def _has_web_content_descendant(self, node: etree.Element) -> bool:
        for child in node.iterdescendants(etree.Element):
            if child.tag.lower() in WEB_SKIP_TAGS:
                continue
            if child.tag.lower() in WEB_MEDIA_TAGS or _has_word(_own_text(child)) or self._web_element_actions(child):
                return True
        return False

    def _extract_compact_web_interactives(self) -> List[Dict]:
        # Actionable elements (folded labels) + standalone visible text; drops the rest.
        # Candidates are chosen first so one batched lookup covers all of their bounds.
        candidates = [
            (node, candidate)
            for node in self.tree.iter()
            if (candidate := self._compact_web_candidate(node)) is not None
        ]
        xpaths = [self._build_simple_xpath(node) for node, _ in candidates]
        rects, locators = self._inspect_nodes(xpaths, xpaths)
        if rects is None:
            # Every entry needs bounds, so a failed batch would collapse to an empty list
            # indistinguishable from a genuinely empty screen. Consumers such as the live
            # NL agent fall back to page source on "unavailable" but not on "empty", so
            # surface the failure instead of swallowing it.
            raise OpticsError(
                Code.E0202,
                message="Batched bounds lookup failed; compact elements unavailable.",
            )
        entries = []
        for (node, (label, actions)), rect, locator in zip(candidates, rects, locators):
            bounds = self._rect_to_bounds(rect)
            if bounds:
                # A click handler added by script leaves no attribute; the hand cursor a person sees is the sign.
                if rect.get("pointer") and "tap" not in actions and not self._is_web_disabled(node):
                    actions = ["tap", *actions]
                entries.append(
                    self._compact_web_entry(node, label, actions, bounds, locator, bool(rect.get("offscreen")))
                )
        return entries

    def _check_filter_type(self, node: etree.Element, filter_type: str) -> bool:
        """
        Check if element matches a specific filter type.

        :param node: Element node
        :param filter_type: Filter type to check
        :return: True if element matches filter type
        """
        filter_checks = {
            "interactive": self._is_probably_interactive,
            "buttons": self._is_button,
            "inputs": self._is_input,
            "images": self._is_image,
            "text": self._is_text,
        }
        check_func = filter_checks.get(filter_type)
        return check_func(node) if check_func else False

    def _should_include_element(self, node: etree.Element, filter_config: Optional[List[str]]) -> bool:
        """
        Determine if an element should be included based on filter_config.

        Args:
            node: The XML element node
            filter_config: Optional list of filter types

        Returns:
            True if element should be included, False otherwise
        """
        # Default behavior: show all elements when filter_config is None or empty
        if not filter_config or len(filter_config) == 0:
            return True

        # If "all" is in filter_config, show all elements
        if "all" in filter_config:
            return True

        # Check each filter type
        for filter_type in filter_config:
            if self._check_filter_type(node, filter_type):
                return True

        return False

    def _is_button(self, node: etree.Element) -> bool:
        """Check if element is a button."""
        tag = node.tag or ""
        attrs = node.attrib or {}

        # HTML button tag
        if tag.lower() == "button":
            return True

        # Elements with role="button"
        if attrs.get("role", "").lower() == "button":
            return True

        # Links that act as buttons (common pattern)
        if tag.lower() == "a" and (
            attrs.get("role", "").lower() == "button" or
            "button" in attrs.get("class", "").lower()
        ):
            return True

        return False

    def _is_input(self, node: etree.Element) -> bool:
        """Check if element is an input/text field."""
        tag = node.tag or ""

        # HTML input elements
        input_tags = ["input", "textarea", "select"]
        return tag.lower() in input_tags

    def _is_image(self, node: etree.Element) -> bool:
        """Check if element is an image."""
        tag = node.tag or ""
        attrs = node.attrib or {}

        # HTML img tag
        if tag.lower() == "img":
            return True

        # Elements with role="img"
        if attrs.get("role", "").lower() == "img":
            return True

        return False

    def _is_text(self, node: etree.Element) -> bool:
        """Check if element is a text element (non-input)."""
        tag = node.tag or ""
        attrs = node.attrib or {}

        # Exclude inputs
        if self._is_input(node):
            return False

        # Text-containing tags
        text_tags = ["p", "span", "div", "h1", "h2", "h3", "h4", "h5", "h6",
                     "label", "li", "td", "th", "a", "strong", "em", "b", "i"]

        if tag.lower() in text_tags:
            # Check if it has text content or aria-label
            text_content = attrs.get("aria-label", "").strip()
            if text_content:
                return True
            # If it's a text tag, assume it might have text (will be checked via innerText)
            return True

        return False

    def _is_probably_interactive(self, node: etree.Element) -> bool:
        """
        Check if element is probably interactive (clickable, enabled, etc.).
        """
        tag = node.tag or ""
        attrs = node.attrib or {}

        # Buttons are interactive
        if self._is_button(node):
            return True

        # Links are interactive
        if tag.lower() == "a" and attrs.get("href"):
            return True

        # Inputs are interactive
        if self._is_input(node):
            return True

        # Elements with onclick handlers
        if "onclick" in attrs or attrs.get("onclick"):
            return True

        # Elements with role="button" or role="link"
        role = attrs.get("role", "").lower()
        if role in ["button", "link", "menuitem", "tab"]:
            return True

        # Elements with tabindex (usually interactive)
        if "tabindex" in attrs:
            try:
                tabindex = int(attrs.get("tabindex", "0"))
                if tabindex >= 0:  # Non-negative tabindex means focusable
                    return True
            except ValueError as e:
                internal_logger.debug(f"Invalid tabindex value: {e}")

        return False

    def _determine_xpath_uniqueness(self, xpath: str, doc_tree: Any, node: etree.Element) -> Tuple[bool, Optional[int]]:
        """
        Evaluate XPath against document and determine uniqueness.

        :param xpath: XPath string to evaluate
        :param doc_tree: Document tree
        :param node: Target node
        :return: Tuple of (is_unique, index_if_not_unique)
        """
        try:
            matches = doc_tree.xpath(xpath)
        except (etree.XPathError, ValueError, TypeError):
            return False, None

        if not matches:
            return False, None

        if len(matches) > 1:
            try:
                idx = matches.index(node)
            except ValueError:
                idx = 0
            return False, idx

        return True, None

    def _build_xpath_from_single_attribute(self, tag: str, attrs: dict, attr_name: str, val: Optional[str] = None) -> Optional[str]:
        """
        Build XPath from a single attribute.

        :param tag: Element tag name
        :param attrs: Element attributes
        :param attr_name: Attribute name
        :param val: Optional attribute value override
        :return: XPath string or None
        """
        value = val if val is not None else attrs.get(attr_name)
        if not value:
            return None

        if attr_name == "class":
            class_token = value.strip().split()[0]
            if not class_token:
                return None
            token_literal = self._escape_for_xpath_literal(f" {class_token} ")
            return f"//{tag}[contains(concat(' ', normalize-space(@class), ' '), {token_literal})]"

        return f"//{tag}[@{attr_name}={self._escape_for_xpath_literal(value)}]"

    def _build_xpath_from_attribute_pair(self, tag: str, attrs: dict, a1: str, a2: str) -> Optional[str]:
        """
        Build XPath from a pair of attributes.

        :param tag: Element tag name
        :param attrs: Element attributes
        :param a1: First attribute name
        :param a2: Second attribute name
        :return: XPath string or None
        """
        v1, v2 = attrs.get(a1), attrs.get(a2)
        if not v1 or not v2:
            return None
        return f"//{tag}[@{a1}={self._escape_for_xpath_literal(v1)} and @{a2}={self._escape_for_xpath_literal(v2)}]"

    def _build_xpath_from_text(self, tag: str, node: etree.Element) -> Optional[str]:
        """
        Build XPath from text content (short text only).

        :param tag: Element tag name
        :param node: Element node
        :return: XPath string or None
        """
        try:
            text_content = " ".join(node.itertext()).strip()
        except Exception:
            return None
        if not text_content:
            return None
        # Avoid overly long or noisy text selectors
        if len(text_content) > 80 or "\n" in text_content:
            return None
        return f"//{tag}[normalize-space(.)={self._escape_for_xpath_literal(text_content)}]"

    def _resolve_xpath(self, xpath: str, doc_tree: Any, node: etree.Element) -> Optional[str]:
        """
        Return unique or semi-unique XPath.

        :param xpath: XPath string to resolve
        :param doc_tree: Document tree
        :param node: Target node
        :return: Resolved XPath string or None
        """
        is_unique, idx = self._determine_xpath_uniqueness(xpath, doc_tree, node)
        if is_unique:
            return xpath
        if idx is not None:
            return f"({xpath})[{idx + 1}]"
        return None

    def _try_unique_attributes_xpath(self, tag: str, attrs: dict, doc_tree: Any, node: etree.Element) -> Optional[str]:
        """
        Try to build XPath from unique attributes.

        :param tag: Element tag name
        :param attrs: Element attributes
        :param doc_tree: Document tree
        :param node: Target node
        :return: Resolved XPath string or None
        """
        unique_attrs = [
            "id", "data-testid", "data-test", "data-qa", "data-cy",
            "data-automation", "name",
        ]
        for attr in unique_attrs:
            xpath = self._build_xpath_from_single_attribute(tag, attrs, attr)
            if xpath:
                resolved = self._resolve_xpath(xpath, doc_tree, node)
                if resolved:
                    return resolved
        return None

    def _try_attribute_pairs_xpath(self, tag: str, attrs: dict, doc_tree: Any, node: etree.Element) -> Optional[str]:
        """
        Try to build XPath from attribute pairs.

        :param tag: Element tag name
        :param attrs: Element attributes
        :param doc_tree: Document tree
        :param node: Target node
        :return: Resolved XPath string or None
        """
        unique_attrs = ["id", "data-testid", "data-test", "data-qa", "data-cy", "data-automation", "name"]
        pair_candidates = unique_attrs + ["aria-label", "placeholder", "title", "alt", "role", "type"]
        for i, a1 in enumerate(pair_candidates):
            for a2 in pair_candidates[i + 1:]:
                xpath = self._build_xpath_from_attribute_pair(tag, attrs, a1, a2)
                if xpath:
                    resolved = self._resolve_xpath(xpath, doc_tree, node)
                    if resolved:
                        return resolved
        return None

    def _try_text_xpath(self, tag: str, node: etree.Element, doc_tree: Any) -> Optional[str]:
        """
        Try to build XPath from text content.

        :param tag: Element tag name
        :param node: Element node
        :param doc_tree: Document tree
        :return: Resolved XPath string or None
        """
        text_xpath = self._build_xpath_from_text(tag, node)
        if text_xpath:
            return self._resolve_xpath(text_xpath, doc_tree, node)
        return None

    def _try_maybe_unique_attributes_xpath(self, tag: str, attrs: dict, doc_tree: Any, node: etree.Element) -> Optional[str]:
        """
        Try to build XPath from maybe-unique attributes.

        :param tag: Element tag name
        :param attrs: Element attributes
        :param doc_tree: Document tree
        :param node: Target node
        :return: Resolved XPath string or None
        """
        maybe_unique_attrs = [
            "aria-label", "placeholder", "title", "alt", "role", "type", "class",
        ]
        for attr in maybe_unique_attrs:
            xpath = self._build_xpath_from_single_attribute(tag, attrs, attr)
            if xpath:
                resolved = self._resolve_xpath(xpath, doc_tree, node)
                if resolved:
                    return resolved
        return None

    def get_xpath(self, node: etree.Element) -> str:
        """
        Generate an optimal XPath for a given HTML element.

        Prioritizes:
        1. Stable unique attributes (id, data-testid, name, etc.)
        2. Attribute pairs for semi-uniqueness (fast + reliable)
        3. Short text-based selectors when safe
        4. Fallbacks like aria-label, title, placeholder, class token
        5. Hierarchical path with tag names
        """
        if node is None or not hasattr(node, "tag"):
            return ""

        tag = node.tag or "*"
        attrs = node.attrib or {}
        doc_tree = node.getroottree()

        # Try unique attributes first
        xpath = self._try_unique_attributes_xpath(tag, attrs, doc_tree, node)
        if xpath:
            return xpath

        # Try attribute pairs for better uniqueness
        xpath = self._try_attribute_pairs_xpath(tag, attrs, doc_tree, node)
        if xpath:
            return xpath

        # Try short text-based XPath (useful for buttons/links)
        xpath = self._try_text_xpath(tag, node, doc_tree)
        if xpath:
            return xpath

        # Try maybe-unique attributes
        xpath = self._try_maybe_unique_attributes_xpath(tag, attrs, doc_tree, node)
        if xpath:
            return xpath

        # Fallback to hierarchical path
        return self._build_hierarchical_xpath(node)

    def _build_hierarchical_xpath(self, node: etree.Element) -> str:
        """
        Build hierarchical XPath based on element structure.
        """
        tag = node.tag
        if not tag:
            return ""

        parent = node.getparent()
        segment = f"/{tag}"

        if parent is not None:
            siblings_same_tag = [c for c in parent if c.tag == tag]
            if len(siblings_same_tag) > 1:
                idx = siblings_same_tag.index(node) + 1
                segment += f"[{idx}]"

        if parent is not None and hasattr(parent, "tag"):
            parent_xpath = self._build_hierarchical_xpath(parent)
            return f"{parent_xpath}{segment}"

        return segment

    def _escape_for_xpath_literal(self, s: str) -> str:
        """
        Safely escape a string for inclusion in an XPath string literal.
        Uses the concat() trick if both single and double quotes are present.
        """
        if '"' not in s:
            return f'"{s}"'
        if "'" not in s:
            return f"'{s}'"
        # If it contains both, break on double quotes and concat with '\"'
        parts = s.split('"')
        escaped_parts = []
        for i, p in enumerate(parts):
            if i == len(parts) - 1:
                escaped_parts.append(f'"{p}"')
            else:
                escaped_parts.extend([f'"{p}"', "'\"'"])
        return 'concat(' + ', '.join(escaped_parts) + ')'

    def _build_extra_metadata(self, attrs: dict, used_key: Optional[str], tag: str) -> dict:
        """
        Build metadata dictionary with element attributes.

        Args:
            attrs: Element attributes dictionary
            used_key: The attribute key used for text extraction (to exclude from extra)
            tag: Element tag name

        Returns:
            Dictionary with metadata
        """
        extra = {
            k: v
            for k, v in attrs.items()
            if k != used_key and v and (isinstance(v, str) and v.lower() != "false" or not isinstance(v, str))
        }

        # Keep common fields explicitly
        extra["tag"] = tag
        extra["class"] = attrs.get("class")
        extra["id"] = attrs.get("id")
        extra["role"] = attrs.get("role")
        extra["type"] = attrs.get("type")  # For input elements
        extra["href"] = attrs.get("href")  # For links

        return extra


class PlaywrightPageSource(ElementSourceInterface, WebDomInspector):
    """
    Playwright Page Source Element Source
    """
    REQUIRED_DRIVER_TYPE = "playwright"

    def __init__(self, driver: Optional[Any] = None):
        # 🔑 DO NOT validate here
        self.driver = driver
        self.page = None
        self.tree = None
        self.root = None

    # ---------------------------------------------------------
    # Internal helpers
    # ---------------------------------------------------------

    def _require_page(self):
        internal_logger.debug(
            "[PlaywrightPageSource] driver=%s | has_page_attr=%s | page=%s",
            self.driver,
            hasattr(self.driver, "page") if self.driver else False,
            getattr(self.driver, "page", None) if self.driver else None
        )

        # 🔴 Driver not injected
        if self.driver is None:
            raise OpticsError(
                Code.E0101,
                message=(
                    "Playwright driver is not injected into PlaywrightPageSource. "
                    "Session may not be initialized."
                )
            )

        # 🔴 Driver exists but page attribute missing
        if not hasattr(self.driver, "page"):
            raise OpticsError(
                Code.E0101,
                message=(
                    "Playwright driver does not expose 'page'. "
                    "Invalid driver implementation or setup."
                )
            )

        # 🔴 Page attribute exists but page not yet created
        if self.driver.page is None:
            raise OpticsError(
                Code.E0101,
                message=(
                    "Playwright page is not initialized yet. "
                    "Ensure launch_app() completed before using element sources."
                )
            )

        self.page = self.driver.page
        return self.page

    # ---------------------------------------------------------
    # Required interface methods
    # ---------------------------------------------------------

    def capture(self):
        internal_logger.exception(
            "PlaywrightPageSource does not support screen capture."
        )
        raise NotImplementedError(
            "PlaywrightPageSource does not support screen capture."
        )

    def get_page_source(self) -> Tuple[str, str]:
        """
        Returns full DOM HTML and timestamp.
        Returns:
            Tuple[str, str]: (page_source, timestamp)
        """
        page = self._require_page()
        self.driver.wait_for_page_settled()
        timestamp = utils.get_timestamp()

        html: str = self.driver.run(page.content())
        internal_logger.debug(
            "[PlaywrightPageSource] Page source fetched, length=%d",
            len(html)
        )
        self.tree = etree.HTML(html)
        self.root = self.tree
        return html, str(timestamp)

    def get_interactive_elements(self, filter_config: Optional[List[str]] = None, compact: bool = False) -> List[Dict]:
        """
        Cross-platform element extraction for web pages.

        Args:
            filter_config: Optional list of filter types. Valid values:
                - "all": Show all elements (default when None or empty)
                - "interactive": Only interactive elements
                - "buttons": Only button elements
                - "inputs": Only input/text field elements
                - "images": Only image elements
                - "text": Only text elements
                Can be combined: ["buttons", "inputs"]
            compact: When True, ignore filter_config and return only actionable
                elements (labels folded in from descendants, with an ``act`` list)
                plus standalone visible text (``act: []``), shaped for the Verifier's
                compact projection.

        Returns:
            List of dictionaries with keys: text, bounds, xpath, extra. In compact
            mode each dict carries ``act`` instead of ``xpath``.
        """
        # Ensure page source is fetched and parsed
        self.get_page_source()  # Returns (html, timestamp); updates self.tree

        if self.tree is None:
            internal_logger.error("[PlaywrightPageSource] Tree is None, cannot extract elements")
            return []

        return self._web_interactive_elements(filter_config, compact)

    # ---------------------------------------------------------
    # Browser side of the shared web inspector
    # ---------------------------------------------------------

    def _inspect_nodes(
        self, xpaths: List[Optional[str]], locate: List[Optional[str]]
    ) -> Tuple[Optional[List[Optional[Dict[str, Any]]]], List[Optional[str]]]:
        page = self._require_page()
        rects = self._resolve_bounds_batch(page, xpaths)
        if rects is None or not any(locate):
            return rects, [None] * len(xpaths)
        return rects, self._suggest_locators(page, locate)

    def _resolve_bounds_batch(
        self, page: Any, xpaths: List[Optional[str]]
    ) -> Optional[List[Optional[Dict[str, float]]]]:
        """Resolve bounding rects for every candidate xpath in one round trip.

        ``None`` means the batch lookup itself failed: ``page.evaluate`` raised or
        returned a malformed payload. That is deliberately distinct from a list of
        per-element ``None``s, which just means no candidate had visible bounds.
        """
        if not xpaths:
            return []
        try:
            rects = self.driver.run(page.evaluate(BOUNDS_JS, xpaths))
        except Exception as e:
            # The batch call itself failed (e.g. page mid-navigation). Falling back to one
            # evaluate() per node here would reintroduce the exact per-node round-trip cost
            # this batching exists to avoid.
            internal_logger.debug(
                f"[PlaywrightPageSource] Batched bounds lookup failed: {e}"
            )
            return None
        if not isinstance(rects, list) or len(rects) != len(xpaths):
            internal_logger.debug(
                "[PlaywrightPageSource] Batched bounds lookup returned a malformed payload"
            )
            return None
        return rects

    def _try_inner_text(self, node: etree.Element) -> Tuple[Optional[str], Optional[str]]:
        """
        Try to get innerText via Playwright (slower, but more accurate).

        :param node: Element node
        :return: Tuple of (text_value, attribute_used) or (None, None)
        """
        page = self._require_page()
        try:
            xpath = self._build_simple_xpath(node)
            if not xpath:
                return None, None

            locator = page.locator(f"xpath={xpath}")
            count = self.driver.run(locator.count())
            if count > 0:
                inner_text = self.driver.run(locator.first.inner_text())
                if inner_text and inner_text.strip():
                    return inner_text.strip(), "innerText"
        except Exception as e:
            internal_logger.debug(f"Failed to get innerText via Playwright: {e}")

        return None, None

    def _suggest_locators(self, page: Any, xpaths: list[str | None]) -> list[str | None]:
        try:
            return list(self.driver.run(page.evaluate(SUGGEST_LOCATORS_JS, xpaths)))
        except Exception as e:
            internal_logger.debug("[PlaywrightPageSource] Locator suggestions failed: %s", e)
            return [None] * len(xpaths)

    # ---------------------------------------------------------
    # Element location
    # ---------------------------------------------------------

    def _resolve_optics_element(self, element: str) -> tuple[str, str]:
        """
        Resolve Optics element name to selector.

        :param element: Original element string
        :return: Tuple of (original_element, resolved_element)
        """
        original_element = element

        if hasattr(self.driver, "optics") and self.driver.optics:
            resolved = self.driver.optics.get_element_value(element)
            if resolved:
                element = resolved[0]
                internal_logger.debug(
                    "[PlaywrightLocate] Resolved element '%s' → '%s'",
                    original_element, element
                )
            else:
                internal_logger.debug(
                    "[PlaywrightLocate] Using raw selector '%s'",
                    element
                )

        return original_element, element

    def _strict_element_match(self) -> bool:
        """Whether project config requests exact-only matching (Config.strict_element_match).

        Governs both locate and presence/assert checks so the two stay uniform -- see
        assert_elements. Defaults False (fuzzy) when the config chain is unavailable.
        """
        try:
            return bool(self.driver.event_sdk.config_handler.config.strict_element_match)
        except AttributeError:
            return False

    def locate(self, element: str, index: Optional[int] = None) -> Any:
        """Locate without waiting; PlaywrightFindElement is the source that waits."""
        self._require_page()

        original_element, element = self._resolve_optics_element(element)
        from optics_framework.engines.drivers import playwright_locator  # here, so AppiumWeb can import this module without playwright
        try:
            return playwright_locator.find(
                self.driver, element, index=int(index or 0), exact=self._strict_element_match()
            )
        except Exception as e:
            internal_logger.error(
                "[PlaywrightLocate] Error locating element '%s' (resolved='%s')",
                original_element,
                element,
                exc_info=True
            )
            raise OpticsError(
                Code.E0201,
                message=f"No elements found for: {original_element}",
                cause=e,
            ) from e

    # ---------------------------------------------------------
    # Assertions
    # ---------------------------------------------------------

    def _check_single_element_presence(self, element: str) -> bool:
        from optics_framework.engines.drivers import playwright_locator
        try:
            return playwright_locator.is_present(self.driver, element, exact=self._strict_element_match())
        except Exception as e:
            internal_logger.debug(
                "[PlaywrightPageSource] Error checking '%s': %s",
                element, str(e)
            )
            return False

    def check_elements(self, elements: list[str], visible: bool = False) -> list[bool]:
        self._require_page()
        return [self._check_single_element_presence(element) for element in elements]

    def _check_elements_batch(self, elements: List[str], rule: str) -> Tuple[bool, List[bool]]:
        """
        Check a batch of elements and return results.

        :param elements: List of element selectors
        :param rule: Assertion rule ("any" or "all")
        :return: Tuple of (should_return_early, results_list)
        """
        results = []
        for element in elements:
            found = self._check_single_element_presence(element)
            results.append(found)

            if rule == "any" and found:
                return True, results

        if rule == "all" and all(results):
            return True, results

        return False, results

    def assert_elements(self, elements, timeout=30, rule="any"):
        """
        Assert the presence of elements on the current page (Playwright).

        Args:
            elements (list | str): List of selectors or single selector
            timeout (int): Max wait time in seconds
            rule (str): "any" or "all"

        Returns:
            (bool, str): (status, timestamp)
        """
        if rule not in ("any", "all"):
            raise OpticsError(Code.E0403, message="Invalid rule. Use 'any' or 'all'.")

        if isinstance(elements, str):
            elements = [elements]

        # Ensure driver is initialized before entering the loop (OpticsError propagates if not)
        self._require_page()

        start_time = time.time()

        internal_logger.info(
            "[PlaywrightPageSource] Asserting elements=%s rule=%s timeout=%ss",
            elements, rule, timeout
        )

        while time.time() - start_time < timeout:
            should_return, _ = self._check_elements_batch(elements, rule)
            if should_return:
                return True, utils.get_timestamp()

            time.sleep(0.3)

        internal_logger.warning(
            "[PlaywrightPageSource] Timeout reached. rule=%s elements=%s",
            rule, elements
        )
        raise TimeoutError(
            f"Timeout reached: Elements not found based on rule '{rule}': {elements}"
        )
