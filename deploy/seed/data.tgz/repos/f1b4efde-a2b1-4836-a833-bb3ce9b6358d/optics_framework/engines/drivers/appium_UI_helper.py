import re
from bisect import bisect_left
from typing import Any, List, Dict, Tuple, Optional, Union, cast
from fuzzywuzzy import fuzz
from lxml import etree
from optics_framework.common.logging_config import internal_logger
from optics_framework.common import utils
## Removed import of get_appium_driver (no longer needed)


# XPath attribute sets for get_xpath (mobile-centric with web-friendly aliases)
XPATH_UNIQUE_ATTRIBUTES = [
    "name", "content-desc", "id", "resource-id", "accessibility-id",
]
XPATH_MAYBE_UNIQUE_ATTRIBUTES = ["label", "text", "value"]
# An input's text/value is what was typed into it, so its locator names it by its hint instead.
XPATH_INPUT_MAYBE_UNIQUE_ATTRIBUTES = ["label", "hint", "placeholderValue"]

# The only attributes get_xpath ever probes, so the only ones worth indexing.
XPATH_INDEXED_ATTRIBUTES = (*XPATH_UNIQUE_ATTRIBUTES, *XPATH_MAYBE_UNIQUE_ATTRIBUTES, "hint", "placeholderValue")
_OBFUSCATED_ID_RE = re.compile(r"\d+_resource_name_obfuscated")

# Class-name fragments for the compact extractor. iOS has no clickable/checkable/
# scrollable attributes, so its XCUIElementType* nodes are classified by name.
# "XCUIElementTypeKey" is deliberately a fragment: it prefix-matches the keyboard
# container too, which drops out as an unlabelled node with actionable descendants.
TAP_CLASS_FRAGMENTS = (
    "Button", "SeekBar", "Slider", "XCUIElementTypeCell", "XCUIElementTypeSwitch",
    "XCUIElementTypeStepper", "XCUIElementTypeLink", "XCUIElementTypeTab", "XCUIElementTypeMenuItem",
    "XCUIElementTypeKey",
)
TOGGLE_CLASS_FRAGMENTS = ("Switch", "CheckBox", "RadioButton", "ToggleButton")
INPUT_CLASS_FRAGMENTS = ("EditText", "TextField", "SecureTextField", "AutoCompleteTextView", "SearchField")
# A field's text (Android) and value (iOS) hold what was typed, not its name.
FIELD_NAME_ATTRS = ("hint", "content-desc", "label", "name", "placeholderValue")
SCROLL_CLASS_FRAGMENTS = (
    "XCUIElementTypeScrollView", "XCUIElementTypeTable", "XCUIElementTypeCollectionView",
    "XCUIElementTypePickerWheel",
)
COMPACT_LABEL_MAX_CHARS = 120


def _obfuscated_id(rid: str) -> bool:
    return bool(_OBFUSCATED_ID_RE.fullmatch(rid.rsplit(":id/", 1)[-1]))


class XPathUniquenessIndex:
    """Document-order posting lists answering "how many nodes match this probe?".

    ``get_xpath`` decides between an attribute-based and a hierarchical XPath by
    asking, for each candidate attribute, whether ``//tag[@attr=value]`` matches
    exactly one node. Evaluating that with a real ``xpath()`` call rescans the whole
    document once per probe, so labelling a whole hierarchy costs O(nodes x probes)
    full-document scans -- seconds of CPU on a large iOS tree, which is enough to
    trip an external health checker watching the same process. One indexing pass
    answers every probe from a dict instead, keeping the walk linear in tree size.

    Match sets are kept in document order because callers position a non-unique node
    among its peers (``(xpath)[n]``), which must agree with what XPath itself would
    have returned.
    """

    __slots__ = ("_by_tag", "_by_tag_attr", "_doc_pos", "_multi_cache", "xpath_cache")

    def __init__(self, root: Any):
        self._by_tag: Dict[str, List[Any]] = {}
        self._by_tag_attr: Dict[Tuple[str, str, str], List[Any]] = {}
        self._doc_pos: Dict[Any, int] = {}
        self._multi_cache: Dict[Tuple[Any, ...], List[Any]] = {}
        self.xpath_cache: Dict[Any, str] = {}
        for position, node in enumerate(root.iter()):
            tag = node.tag
            if not isinstance(tag, str):
                continue  # comments and processing instructions carry a callable tag
            if "{" in tag:
                # lxml reports a namespaced tag in Clark notation ("{uri}local"), which
                # is not valid XPath: every probe built from one fails to parse. Leaving
                # these nodes unindexed keeps their probes empty, so they fall through to
                # the hierarchical builder -- where evaluating the probe always sent them.
                continue
            self._doc_pos[node] = position
            self._by_tag.setdefault(tag, []).append(node)
            attrib = node.attrib
            for attr in XPATH_INDEXED_ATTRIBUTES:
                val = attrib.get(attr)
                if val:
                    self._by_tag_attr.setdefault((tag, attr, val), []).append(node)

    def matches(self, tag: str, conditions: Tuple[Tuple[str, str], ...]) -> List[Any]:
        """Nodes matching ``//tag[@a=v and ...]``, in document order."""
        if not conditions:
            return self._by_tag.get(tag, [])
        if len(conditions) == 1:
            attr, val = conditions[0]
            return self._by_tag_attr.get((tag, attr, val), [])
        # Filtering the shortest posting list keeps a multi-attribute probe off a
        # per-pair index, but costs that list's length. Sibling rows sharing a label
        # issue byte-identical probes, so without this memo the same intersection is
        # recomputed once per row -- the quadratic this index exists to remove. Trees
        # with distinct values resolve on one attribute and never reach here.
        cache_key = (tag, conditions)
        cached = self._multi_cache.get(cache_key)
        if cached is not None:
            return cached
        postings = [self._by_tag_attr.get((tag, a, v), []) for a, v in conditions]
        shortest = min(postings, key=len)
        result = [n for n in shortest if all(n.attrib.get(a) == v for a, v in conditions)]
        self._multi_cache[cache_key] = result
        return result

    def position_of(self, matches: List[Any], node: Any) -> int:
        """0-based position of ``node`` within a document-ordered match list.

        A list where every row repeats one label puts every row in the same match
        list, so scanning it per node would reintroduce the quadratic cost this index
        exists to remove. Both sequences are ordered by document position, so a binary
        search answers it in log time.
        """
        pos = self._doc_pos.get(node)
        if pos is None:
            return 0
        found = bisect_left(matches, pos, key=lambda n: self._doc_pos[n])
        return found if found < len(matches) and matches[found] is node else 0


class UIHelper:
    def __init__(self, appium_driver):
        """
        Initialize UIHelper with Appium object (not just WebDriver).
        """
        self.driver = appium_driver
        self.tree = None
        self.root = None
        self.prev_hash = None

    def get_page_source(self):
        """
        Fetch the current UI tree (page source) from the Appium driver.
        """
        time_stamp = utils.get_timestamp()
        page_source = self.driver.driver.page_source
        self.tree = etree.ElementTree(etree.fromstring(page_source.encode("utf-8")))
        self.root = self.tree.getroot()
        internal_logger.debug(f"Page source fetched at: {time_stamp}")
        utils.save_page_source(page_source, time_stamp, self.driver.event_sdk.config_handler.config.execution_output_path)
        return page_source, time_stamp

    # fetching page source and handling UI tree
    def get_distinct_page_source(self):
        """
        Fetch the current UI tree (page source) from the Appium driver continuously.
        Update instance's root and tree attributes when there's a change in page UI.
        """
        time_stamp = utils.get_timestamp()
        page_source = self.driver.driver.page_source
        new_hash = utils.compute_hash(page_source)

        if self.prev_hash == new_hash:
            internal_logger.debug(
                "\nPage source unchanged. Skipping further processing.\n"
            )
            return None, time_stamp

        self.prev_hash = new_hash
        self.tree = etree.ElementTree(etree.fromstring(page_source.encode("utf-8")))
        self.root = self.tree.getroot()
        internal_logger.debug(f"Page source fetched at: {time_stamp}")
        return page_source, time_stamp

    def find_xpath_from_text(self, text):
        """
        Find the XPath of an element based on the text content.

        Args:
            text (str): The text content to search for in the UI tree.

        Returns:
            str: The XPath of the element containing the
            text content, or None if not found.
        """
        locators = self.get_locator_and_strategy(text)
        if locators:
            strategy = locators["strategy"]
            locator = locators["locator"]
            xpath = self.get_view_locator(strategy=strategy, locator=locator)
            return xpath
        return None

    def find_xpath(self, xpath, strict: bool = False):
        """
        Process the given XPath and return the exact path from the UI tree after applying various matching strategies.
        """
        internal_logger.debug(f"Finding Xpath {xpath}...")
        _, time_stamp = (
            self.get_page_source()
        )  # Fetch UI tree when processing the XPath
        try:
            # 1. Exact Match
            try:
                # internal_logger.debug(f'Finding Xpath using exact match')
                found_xpath = self.find_exact(xpath)

                if found_xpath:
                    internal_logger.debug("Xpath found using exact match")
                    return found_xpath, time_stamp
            except Exception as e:
                internal_logger.debug(
                    f"Error in exact match for XPath '{xpath}': {str(e)}"
                )

            # 2. Relative Match
            try:
                found_xpath = self.find_relative(xpath)
                if found_xpath:
                    internal_logger.debug("Xpath found using relative match")
                    return found_xpath, time_stamp
            except Exception as e:
                internal_logger.debug(
                    f"Error in relative match for XPath '{xpath}': {str(e)}"
                )

            if not strict:
                # 3. Partial Match
                try:
                    found_xpath = self.find_partial(xpath)
                    if found_xpath:
                        internal_logger.debug("Xpath found using partial match")
                        return found_xpath, time_stamp
                except Exception as e:
                    internal_logger.debug(
                        f"Error in partial match for XPath '{xpath}': {str(e)}"
                    )

                # 4. Attribute Match with Fuzzy Prefix and Suffix Handling
                try:
                    found_xpath = self.find_attribute_match(xpath)
                    if found_xpath:
                        internal_logger.debug("Xpath found using attribute match")
                        return found_xpath, time_stamp
                except Exception as e:
                    internal_logger.debug(
                        f"Error in attribute match for XPath '{xpath}': {str(e)}"
                    )

            # If no match is found
            internal_logger.debug(
                f"No match found for XPath '{xpath}' after applying all strategies."
            )
            return None, None
        except Exception as e:
            internal_logger.debug(
                f"Unexpected error in find_xpath for XPath '{xpath}': {str(e)}"
            )
            return None, None

    def find_exact(self, xpath):
        """Attempts an exact match for the given XPath."""
        try:
            elements = self.root.xpath(xpath)
            if elements:
                internal_logger.debug(f"Exact XPath: {xpath}")
                return xpath
        except Exception as e:
            internal_logger.debug(f"Exact match error: {e}")
        return None

    def find_relative(self, xpath):
        """Attempts to match a simplified, relative XPath."""
        relative_xpath = self.make_relative(xpath)
        internal_logger.debug(f"Relative XPath: {relative_xpath}")
        try:
            elements = self.root.xpath(relative_xpath)
            if elements:
                internal_logger.debug(
                    f"Relative match found, element type: {type(elements[0])}"
                )
                # Use ElementTree.getpath()
                return self.simplify_xpath(elements[0])
        except Exception as e:
            internal_logger.debug(f"Relative match error: {e}")
        return None

    def make_relative(self, xpath):
        """
        Simplifies the XPath by removing intermediate elements,
        supports both Android and iOS, and avoids redundant `//`.
        """
        parts = xpath.split("/")
        simplified = []

        for part in parts:
            # Skip empty parts (caused by leading or redundant slashes)
            if not part:
                continue

            # Add `//` only if the part starts with specific prefixes and doesn't already have `//`
            if part.startswith("android.widget") or part.startswith("XCUIElementType"):
                if simplified and simplified[-1].startswith("//"):
                    simplified.append(part)
                else:
                    simplified.append("//" + part)
            else:
                simplified.append(part)

        # Join the parts back into a single simplified XPath
        return "/".join(simplified)

    def make_partial_match(self, xpath):
        """
        Converts the XPath for partial matching using `contains()` for specified attributes,
        while ignoring common stop words.
        """
        # List of attributes to support for partial matching
        attributes = ["content-desc", "resource-id", "name", "value", "label", "text"]

        # List of common stop words to ignore
        stop_words = {"a", "an", "the", "for", "in", "on", "with", "of", "and", "or"}

        # Loop through each supported attribute and process it
        for attribute in attributes:
            attr_placeholder = f"@{attribute}="
            if attr_placeholder in xpath:
                # Extract the attribute value
                attr_value = self.extract_attribute(xpath, attribute)
                if attr_value:
                    # Split the attribute value into terms
                    terms = attr_value.split()
                    # Filter out stop words
                    filtered_terms = [
                        term for term in terms if term.lower() not in stop_words
                    ]
                    if filtered_terms:
                        # Construct conditions using `contains()` for each filtered term
                        conditions = " or ".join(
                            [
                                f'contains(@{attribute}, "{term}")'
                                for term in filtered_terms
                            ]
                        )
                        # Replace the exact match in the XPath with the partial match conditions
                        xpath = xpath.replace(
                            f'@{attribute}="{attr_value}"', conditions
                        )

        return xpath

    def find_partial(self, xpath):
        """Attempts partial matching using `contains()` in XPath."""
        partial_xpath = self.make_partial_match(xpath)
        internal_logger.debug(f"Partial XPath: {partial_xpath}")
        try:
            elements = self.root.xpath(partial_xpath)
            if elements:
                internal_logger.debug(
                    f"Partial match found, element type: {type(elements[0])}"
                )
                # Use ElementTree.getpath()
                return self.simplify_xpath(elements[0])
        except Exception as e:
            internal_logger.debug(f"Partial match error: {e}")
        return None

    def fuzzy_match_prefix(self, prefix1, prefix2):
        """Performs a fuzzy comparison of two prefixes."""
        return fuzz.ratio(prefix1, prefix2) >= 80

    def find_attribute_match(self, xpath):
        """Attempts matching by focusing on resource-id (fuzzy for prefix, exact or fuzzy for suffix)."""
        input_attributes = {
            "resource-id": self.extract_attribute(xpath, "resource-id"),
            "content-desc": self.extract_attribute(xpath, "content-desc"),
            "text": self.extract_attribute(xpath, "text"),
            "value": self.extract_attribute(xpath, "value"),
            "name": self.extract_attribute(xpath, "name"),
            "label": self.extract_attribute(xpath, "label"),
        }
        # If no attributes are found, return None
        if not any(input_attributes.values()):
            return None

        best_match = None
        best_fuzzy_score = 0

        # Ensure self.root is valid
        if not hasattr(self, "root") or self.root is None:
            internal_logger.error("Root element is not initialized.")
            return None

        for element in self.root.findall(".//*"):
            if element is None:  # Safeguard against invalid elements
                continue

            for attr, input_value in input_attributes.items():
                if not input_value:
                    continue

                elem_value = element.get(attr)
                if not elem_value:
                    continue

                # Handle splitting logic for attributes with `/`
                input_prefix, input_suffix = self.split_element(input_value)
                elem_prefix, elem_suffix = self.split_element(elem_value)

                # Check exact match first
                if input_value == elem_value:
                    internal_logger.debug(f"Exact match found for {attr}: {elem_value}")
                    return self.simplify_xpath(element)

                # Fuzzy match logic
                if self.fuzzy_match_prefix(input_prefix, elem_prefix):
                    if input_suffix == elem_suffix:
                        internal_logger.debug(
                            f"Attribute match found for {attr} with exact suffix match: {elem_value}"
                        )
                        return self.simplify_xpath(element)

                    # Fuzzy match on suffix if exact match fails
                    suffix_score = fuzz.ratio(input_suffix or "", elem_suffix or "")
                    if suffix_score > best_fuzzy_score:
                        best_fuzzy_score = suffix_score
                        best_match = element

        # Handle best fuzzy match
        if best_fuzzy_score >= 70:  # Threshold for fuzzy match acceptance
            internal_logger.debug(
                f"Fuzzy match found with score {best_fuzzy_score}, element: {best_match}"
            )
            return self.simplify_xpath(best_match)

        # No match found
        internal_logger.debug("No match found using attribute matching.")
        return None

    def split_element(self, element):
        """Splits an element into prefix and suffix."""
        return element.rsplit(":", 1) if ":" in element else (element, "")

    def extract_attribute(self, xpath, attribute):
        """Extracts the value of a given attribute from the XPath."""
        marker = f"@{attribute}="
        try:
            start = xpath.index(marker) + len(marker) + 1
            end = xpath.index('"', start)
            return xpath[start:end]
        except ValueError:
            return None

    def simplify_xpath(self, element):
        """
        Simplify the XPath by focusing on key attributes like resource-id, content-desc, text, or class.
        """
        attributes = self.extract_key_attributes(element)

        # Start building the simplified XPath based on available attributes
        xpath_parts = []

        # Always include the class name (e.g., android.widget.FrameLayout)
        if attributes["class"]:
            xpath_parts.append(f"//{attributes['class']}")

        # Add resource-id if available
        if attributes["resource-id"]:
            xpath_parts.append(f"[@resource-id='{attributes['resource-id']}']")

        # Optionally add content-desc or text if available
        if attributes["content-desc"]:
            xpath_parts.append(
                f"[contains(@content-desc, '{attributes['content-desc']}')]"
            )
        elif attributes["text"]:
            xpath_parts.append(f"[contains(@text, '{attributes['text']}')]")

        # Combine all parts into a simplified XPath
        simplified_xpath = "".join(xpath_parts)

        internal_logger.debug(f"Simplified XPath: {simplified_xpath}")
        return simplified_xpath

    def extract_key_attributes(self, element):
        """
        Extracts the key attributes from an element for both Android and iOS.

        Android attributes:
            - resource-id
            - content-desc
            - text
            - class (widget class)

        iOS attributes:
            - name
            - value
            - label
            - class (XCUIElementType)

        :param element: XML element from the UI tree.
        :return: Dictionary containing extracted attributes.
        """
        attributes = {
            "resource-id": element.attrib.get("resource-id", ""),  # Android
            "content-desc": element.attrib.get("content-desc", ""),  # Android
            "text": element.attrib.get("text", ""),  # Android
            "name": element.attrib.get("name", ""),  # iOS
            "value": element.attrib.get("value", ""),  # iOS
            "label": element.attrib.get("label", ""),  # iOS
            "class": element.tag,  # Widget class (e.g., android.widget.Button or XCUIElementTypeButton)
        }

        # Remove empty attributes for cleaner output
        attributes = {k: v for k, v in attributes.items() if v}
        return attributes

    def _find_exact_or_suffix_match(
        self, element: str, strategies: List[Tuple[str, str, str]], time_stamp: str
    ) -> Optional[Dict]:
        """First pass: return match dict for exact or suffix match, or None."""
        for strategy_name, xpath_query, attrib in strategies:
            elements = self.tree.xpath(xpath_query)
            for elem in elements:
                value = elem.attrib.get(attrib, "").strip()
                if not value:
                    continue
                if value == element:
                    internal_logger.debug("Exact match found.")
                    internal_logger.debug(f"Match found using '{strategy_name}' strategy: '{value}'")
                    return {
                        "strategy": strategy_name,
                        "locator": value,
                        "attributes": elem.attrib,
                        "timestamp": time_stamp,
                    }
                if "/" in value and value.rsplit("/", 1)[-1] == element:
                    internal_logger.debug("Exact suffix match found.")
                    internal_logger.debug(f"Match found using '{strategy_name}' strategy: '{value}'")
                    return {
                        "strategy": strategy_name,
                        "locator": value,
                        "attributes": elem.attrib,
                        "timestamp": time_stamp,
                    }
        return None

    def get_locator_and_strategy(self, element, strict: bool = False):
        """
        Determines the best strategy and locator for the given element identifier.

        strict=True stops after exact/suffix matching -- no fuzzy fallback.
        """
        _, time_stamp = self.get_page_source()

        strategies = [
            ("text", "//*[@text]", "text"),
            ("resource-id", "//*[@resource-id]", "resource-id"),
            ("content-desc", "//*[@content-desc]", "content-desc"),
            ("name", "//*[@name]", "name"),
            ("value", "//*[@value]", "value"),
            ("label", "//*[@label]", "label"),
        ]

        exact = self._find_exact_or_suffix_match(element, strategies, time_stamp)
        if exact is not None:
            return exact

        if strict:
            internal_logger.debug(f"Strict matching enabled; no exact match found for '{element}'.")
            return None

        return self._find_best_fuzzy_candidate(element, strategies, time_stamp)

    @staticmethod
    def _fuzzy_ratio(value: str, element: str) -> int:
        try:
            return fuzz.ratio(value.lower().strip(), element.lower().strip())
        except Exception:
            return 0

    def _find_best_fuzzy_candidate(self, element, strategies, time_stamp):
        """Second pass: collect fuzzy candidates and return the best-scoring one, if any."""
        best_candidate = None
        best_score = 0
        for strategy_name, xpath_query, attrib in strategies:
            for elem in self.tree.xpath(xpath_query):
                value = elem.attrib.get(attrib, "").strip()
                if not value:
                    continue
                score = self._fuzzy_ratio(value, element)
                if score > best_score:
                    best_score = score
                    best_candidate = (strategy_name, value, elem.attrib)

        if not best_candidate or best_score < 80:
            internal_logger.debug(
                f"No matching element found in any of the locator strategies for '{element}'."
            )
            return None

        strategy_name, value, attributes = best_candidate
        internal_logger.debug(
            f"Fuzzy match selected (score={best_score}) using '{strategy_name}': '{value}'"
        )
        return {
            "strategy": strategy_name,
            "locator": value,
            "attributes": attributes,
            "timestamp": time_stamp,
        }

    def get_view_locator(self, strategy, locator):
        """
        Fetches the full XPath of the given element directly from the UI tree using the strategy found.
        Supports both Android and iOS attributes with prioritized attribute selection.
        """
        try:
            self.get_page_source()
            tree = self.tree
            # Construct the XPath based on the strategy and platform-specific attributes
            if strategy in [
                "text",
                "resource-id",
                "content-desc",
                "name",
                "value",
                "label",
            ]:
                # Directly use the strategy as the attribute name
                xpath_query = f"//*[@{strategy}='{locator}']"
            elif strategy == "xpath":
                # internal_logger.debug("Debug: Strategy is XPath, returning locator directly.")
                return locator
            else:
                internal_logger.debug(f"Unsupported strategy: {strategy}")
                return None

            # Run the XPath query
            elements = tree.xpath(xpath_query)
            if elements:
                # If an element is found, manually construct the full XPath of the first matching element
                element = elements[0]
                xpath_parts = []
                # Define attribute priority for Android and iOS
                android_priority = ["resource-id", "text", "content-desc"]
                ios_priority = ["name", "value", "label"]

                while element is not None:
                    tag = element.tag
                    attributes = []

                    # Choose the highest-priority attribute that exists in the element
                    for attr in android_priority + ios_priority:
                        if attr in element.attrib and element.attrib[attr]:
                            attributes.append(f"@{attr}='{element.attrib[attr]}'")
                            # break

                    # Construct the XPath part with the selected attribute
                    xpath_part = tag
                    if attributes:
                        xpath_part += "[" + " and ".join(attributes) + "]"
                        xpath_parts.insert(0, xpath_part)

                        # Stop traversal if a high-priority identifier is found
                        if (
                            "resource-id" in element.attrib
                            or "name" in element.attrib
                            or "label" in element.attrib
                        ):
                            break
                    else:
                        # If no unique attributes, add an index if siblings have the same tag
                        siblings = (
                            element.getparent().findall(tag)
                            if element.getparent() is not None
                            else []
                        )
                        index = siblings.index(element) + 1 if len(siblings) > 1 else 1
                        xpath_part += f"[{index}]"
                        xpath_parts.insert(0, xpath_part)
                    # Move to the parent element
                    element = element.getparent()

                # Combine the parts to form the final simplified XPath
                full_xpath = "//" + "/".join(xpath_parts)
                # Find the XPath that is acceptable by Appium
                final_xpath, _ = self.find_xpath(full_xpath)
                return final_xpath
            internal_logger.debug(f"No element found for '{locator}' in the UI tree.")
            return None
        except Exception as e:
            internal_logger.debug(f"Error getting view locator from tree: {e}")
            return None

    def get_locator_and_strategy_using_index(
        self, element, index, strategy=None, strict: bool = False
    ) -> dict:
        """
        Perform a linear search across all strategies (resource-id, text, content-desc, etc.) in the UI tree,
        match against the input, and index the found matches.

        Args:
            element (str): The element identifier to search for.
            index (int): zero indexing
            strategy (str): supported attributes in string, 'resource-id', 'text', 'content-desc', 'name', 'value', 'label'
            strict (bool): if True, only exact/suffix matches are considered -- no partial/fuzzy fallback.

        Returns:
            list: A list of dictionaries, each containing the strategy, value, and index of the match.
        """
        self.get_page_source()
        tree = self.tree

        # Collect all elements in positional order
        all_strategies = [
            "resource-id",
            "text",
            "content-desc",
            "name",
            "value",
            "label",
        ]  # Supported attributes
        all_elements = []

        strategies = [strategy] if strategy else all_strategies

        # If a specific strategy is provided, ensure it's valid
        if strategy and strategy not in strategies:
            raise ValueError(
                f"Invalid strategy '{strategy}'. Supported strategies: {strategies}"
            )

        for strategy in strategies:
            elements = tree.xpath(f"//*[@{strategy}]")
            for elem in elements:
                attr_value = elem.attrib.get(strategy, "").strip()
                bounds = elem.attrib.get("bounds", "")  # Parse bounds if available
                position = self.parse_bounds(bounds)
                all_elements.append(
                    {"strategy": strategy, "value": attr_value, "position": position, "node": elem}
                )

        matches = self._index_matches(tree, all_elements, element, strict)

        # Log matches
        internal_logger.debug(
            f"Found {len(matches)} matches for '{element}': {matches}"
        )

        if index >= len(matches):
            raise IndexError(
                f"Index {index} is out of range for the matches found. Total matches: {len(matches)}."
            )

        desired_match = matches[index]
        internal_logger.debug(
            f"Found the matches for {element} and returning {index} index match: {desired_match} "
        )

        strategy = desired_match["strategy"]
        locator = desired_match["value"]
        same_value = [tree.getpath(n) for n in tree.xpath(f"//*[@{strategy}=$value]", value=locator)]
        node_path = tree.getpath(desired_match["node"])
        occurrence = same_value.index(node_path) + 1 if node_path in same_value else 1

        internal_logger.debug(f"Returning strategy: {strategy}, locator: {locator}")
        return {"strategy": strategy, "locator": locator, "count": len(matches), "occurrence": occurrence}

    @staticmethod
    def _index_matches(tree, all_elements: list, element: str, strict: bool) -> list:
        """Exact (or ``pkg/name`` suffix) matches, else fuzzy ones, one per node."""
        exact_matches = []
        fuzzy_matches = []
        for idx, elem in enumerate(all_elements):
            val = elem.get("value", "")
            match = {
                "index": idx,
                "strategy": elem["strategy"],
                "value": val,
                "position": elem["position"],
                "node": elem["node"],
            }
            if val == element or ("/" in val and val.rsplit("/", 1)[-1] == element):
                exact_matches.append(match)
            elif not strict and utils.compare_text(val, element):
                fuzzy_matches.append(match)
        # A node matched through two attributes (text and content-desc) is one element.
        unique: dict = {}
        for match in exact_matches or fuzzy_matches:
            unique.setdefault(tree.getpath(match["node"]), match)
        return list(unique.values())

    def parse_bounds(self, bounds):
        """
        Parse the 'bounds' attribute to extract position information.
        Args:
            bounds (str): Bounds string in the format "[x1,y1][x2,y2]".
        Returns:
            dict: A dictionary with coordinates {x1, y1, x2, y2}.
        """
        try:
            numbers = re.findall(r"\d+", bounds)  # Extract all numbers from the string
            if len(numbers) == 4:
                x1, y1, x2, y2 = map(int, numbers)
                return {"x1": x1, "y1": y1, "x2": x2, "y2": y2}
            else:
                raise ValueError(f"Unexpected bounds format: {bounds}")
        except Exception as e:
            internal_logger.debug(f"Error parsing bounds: {bounds} - {e}")
            return {"x1": 0, "y1": 0, "x2": 0, "y2": 0}

    def get_bounding_box_for_text(self, attributes):
        """
        Extract the bounding box for a text element using its attributes.

        Args:
            attributes (dict): The attributes of the element containing 'bounds'.

        Returns:
            tuple: Bounding box coordinates in the form of (top_left, bottom_right).
        """
        if attributes and "bounds" in attributes:
            # Parse the bounds attribute to get coordinates
            bounds = attributes["bounds"]
            bounds = bounds.strip("[]").split("][")
            top_left = tuple(map(int, bounds[0].split(",")))
            bottom_right = tuple(map(int, bounds[1].split(",")))

            internal_logger.debug(f"Bounding box extracted: {top_left}, {bottom_right}")
            return (top_left, bottom_right)
        else:
            internal_logger.debug(f"Bounds not available in attributes: {attributes}")

    def get_bounding_box_for_xpath(self, xpath):
        # refresh page source tree and root
        self.get_page_source()
        if not xpath:
            internal_logger.debug("Invalid Xpath, bounding box cannot be fetched.")
            return None

        # Get the element attributes based on the xpath
        attributes = self.get_element_attributes_by_xpath(xpath)
        internal_logger.debug(attributes)

        try:
            if attributes:
                # Check if bounds key exists
                if "bounds" in attributes:
                    # Parse the bounds attribute to get coordinates
                    bounds = attributes["bounds"]
                    bounds = bounds.strip("[]").split("][")
                    top_left = tuple(map(int, bounds[0].split(",")))
                    bottom_right = tuple(map(int, bounds[1].split(",")))

                    internal_logger.debug(
                        f"Bounding box for element with xpath '{xpath}': {top_left}, {bottom_right}"
                    )
                    return (top_left, bottom_right)

                # If bounds key is not available, calculate using x, y, width, and height
                elif all(k in attributes for k in ["x", "y", "width", "height"]):
                    x = int(attributes["x"])
                    y = int(attributes["y"])
                    width = int(attributes["width"])
                    height = int(attributes["height"])

                    top_left = (x, y)
                    bottom_right = (x + width, y + height)

                    internal_logger.debug(
                        f"Bounding box calculated for element with xpath '{xpath}': {top_left}, {bottom_right}"
                    )
                    return (top_left, bottom_right)

                else:
                    internal_logger.debug(
                        f"Required attributes (x, y, width, height) not found in element attributes: {attributes}"
                    )
                    return None  # Graceful exit if required keys are missing
            else:
                internal_logger.debug(
                    f"Element with xpath '{xpath}' not found or attributes unavailable."
                )
                return None  # Graceful exit if attributes are missing

        except Exception as e:
            internal_logger.debug(
                f"Error calculating bounding box for xpath '{xpath}': {str(e)}"
            )
            return None  # Graceful exit on unexpected errors

    def get_element_attributes_by_xpath(self, xpath):
        """
        Find an element by its XPath in the Appium UI tree and retrieve its attributes.

        Args:
            xpath (str): The XPath to search for in the page source.

        Returns:
            dict: Dictionary containing the element's attributes, or None if not found.
        """

        tree = self.tree

        # Find the element using the provided XPath
        try:
            elements = tree.xpath(xpath)
            if elements:
                # If an element is found, return its attributes as a dictionary
                return dict(elements[0].attrib)
            else:
                internal_logger.debug(f"No element found with XPath: {xpath}")
                return None
        except etree.XPathSyntaxError as e:
            internal_logger.debug(f"Invalid XPath syntax: {xpath} - Error: {str(e)}")

    # Compact interactive-element extraction (get_interactive_elements(compact=True)).
    @staticmethod
    def _class_of(node: etree.Element) -> str:
        return node.attrib.get("class") or node.tag or ""

    def _element_actions(self, node: etree.Element) -> List[str]:
        """Interactions a node affords: tap/long/toggle/input/scroll (empty => none)."""
        attrs, cls = node.attrib, self._class_of(node)
        actions: List[str] = []
        if attrs.get("clickable") == "true" or any(f in cls for f in TAP_CLASS_FRAGMENTS):
            actions.append("tap")
        if attrs.get("long-clickable") == "true":
            actions.append("long")
        if attrs.get("checkable") == "true" or any(f in cls for f in TOGGLE_CLASS_FRAGMENTS):
            actions.append("toggle")
        if attrs.get("editable") == "true" or any(f in cls for f in INPUT_CLASS_FRAGMENTS):
            actions.append("input")
        if attrs.get("scrollable") == "true" or any(f in cls for f in SCROLL_CLASS_FRAGMENTS):
            actions.append("scroll")
        return actions

    def _is_actionable(self, node: etree.Element) -> bool:
        attrs = node.attrib
        if attrs.get("enabled") == "false" or attrs.get("visible") == "false":
            return False
        return bool(self._extract_bounds(node)) and bool(self._element_actions(node))

    @staticmethod
    def _own_label(node: etree.Element) -> str:
        # label before name: on iOS `label` is the human text and `name` an accessibility id.
        for key in ("text", "content-desc", "label", "name", "value"):
            val = (node.attrib.get(key) or "").strip()
            if val:
                return val
        return ""

    def _folded_label(self, node: etree.Element) -> str:
        # Own label, else descendant text; stops at nested actionable subtrees so a row
        # keeps its own label and does not swallow a control it contains.
        own = self._own_label(node)
        if own:
            return own[:COMPACT_LABEL_MAX_CHARS]
        parts: List[str] = []

        def walk(current: etree.Element, is_root: bool) -> None:
            if not is_root and self._is_actionable(current):
                return
            text = self._own_label(current)
            if text:
                parts.append(text)
            for child in current:
                walk(child, False)

        walk(node, True)
        return " ".join(dict.fromkeys(parts))[:COMPACT_LABEL_MAX_CHARS]

    def _folds_text(self, node: etree.Element) -> bool:
        # A clickable/toggle/input container folds its text; a pure scroll container does not.
        return self._is_actionable(node) and self._element_actions(node) != ["scroll"]

    def _has_folding_ancestor(self, node: etree.Element) -> bool:
        parent = node.getparent()
        while parent is not None:
            if self._folds_text(parent):
                return True
            parent = parent.getparent()
        return False

    def _compact_entry(self, node: etree.Element, label: str, actions: List[str], bounds: Dict) -> Dict:
        extra = {"class": self._class_of(node)}
        rid = node.attrib.get("resource-id")
        if rid and not _obfuscated_id(rid):
            extra["resource-id"] = rid
        if node.attrib.get("password") == "true":
            extra["password"] = True
        if "input" in actions:
            hint = next((v for a in FIELD_NAME_ATTRS if (v := (node.attrib.get(a) or "").strip())), "")
            if hint:
                extra["hint"] = hint
        return {"text": label, "bounds": bounds, "act": actions, "extra": extra}

    def _has_actionable_descendant(self, node: etree.Element) -> bool:
        return any(c is not node and self._is_actionable(c) for c in node.iter())

    def _compact_entry_for(self, node: etree.Element) -> Optional[Dict]:
        # One compact entry for a node, or None to drop it.
        bounds = self._extract_bounds(node)
        if not bounds or node.attrib.get("visible") == "false":
            return None
        actions = self._element_actions(node) if node.attrib.get("enabled") != "false" else []
        if actions == ["scroll"]:
            return self._compact_entry(node, self._own_label(node), actions, bounds)
        if actions:
            label = self._folded_label(node)
            # An empty-labelled wrapper around another actionable element (an iOS Cell
            # around its Button) is noise; the inner element carries the label.
            if label or not self._has_actionable_descendant(node):
                return self._compact_entry(node, label, actions, bounds)
            return None
        label = self._own_label(node)
        if label and len(node) == 0 and not self._has_folding_ancestor(node):
            return self._compact_entry(node, label, [], bounds)
        return None

    def _extract_compact_interactives(self, root: etree.Element) -> List[Dict]:
        # Actionable elements (folded labels) + standalone visible text; drops the rest.
        index = XPathUniquenessIndex(root)
        entries = []
        for node in root.iter():
            entry = self._compact_entry_for(node)
            if entry is not None:
                entry["loc"] = self.get_xpath(node, index)
                entries.append(entry)
        return entries

    def get_interactive_elements(
        self, filter_config: Optional[List[str]] = None, compact: bool = False
    ) -> List[Dict]:
        """
        Cross-platform element extraction supporting both Android and iOS.

        Args:
            filter_config: Optional list of filter types. Valid values:
                - "all": Show all elements (default when None or empty)
                - "interactive": Only interactive elements
                - "buttons": Only button elements
                - "inputs": Only input/text field elements
                - "images": Only image elements
                - "text": Only text elements
                Can be combined: ["buttons", "inputs"]
            compact: When True, ignore filter_config and return only actionable elements
                (with descendant labels folded in) plus standalone visible text (act: []).
        """
        page_source, _ = self.get_page_source()
        root = etree.ElementTree(
            etree.fromstring(page_source.encode("utf-8"))
        ).getroot()
        if compact:
            return self._extract_compact_interactives(root)
        elements = root.xpath(".//*")
        # One index for the whole tree: every node's XPath is derived from the same
        # document, so the uniqueness probes are shared rather than rescanned per node.
        index = XPathUniquenessIndex(root)
        results = []

        for node in elements:
            bounds = self._extract_bounds(node)
            if not bounds:
                continue

            # Check if element should be included based on filter_config
            if not self._should_include_element(node, filter_config):
                continue

            text, used_key = self._extract_display_text(node.attrib)
            if not text:
                # If no text-like attribute, use tag name
                text, used_key = node.tag, None

            xpath = self.get_xpath(node, index)
            extra = self._build_extra_metadata(node.attrib, used_key, node.tag)

            results.append(
                {"text": text, "bounds": bounds, "xpath": xpath, "extra": extra}
            )

        return results

    def _extract_bounds(self, node: etree.Element) -> Optional[Dict[str, int]]:
        """
        Supports:
        - Android: bounds="[x1,y1][x2,y2]"
        - iOS (XCUI): x=".." y=".." width=".." height=".."
        Returns dict with x1,y1,x2,y2 or None if cannot parse.
        """
        attrs = node.attrib or {}

        # Android style
        bounds_str = attrs.get("bounds", "")
        if bounds_str:
            match = re.findall(r"\[(\d+),(\d+)\]\[(\d+),(\d+)\]", bounds_str)
            if match:
                x1, y1, x2, y2 = map(int, match[0])
                return {"x1": x1, "y1": y1, "x2": x2, "y2": y2}

        # iOS style (XCUIElementType*)
        # Attributes are strings; make sure they are digits/valid ints.
        x = attrs.get("x")
        y = attrs.get("y")
        w = attrs.get("width")
        h = attrs.get("height")

        def _to_int(v: Optional[str]) -> Optional[int]:
            if v is None:
                return None
            try:
                # iOS sometimes shows floats; cast safely
                return int(float(v))
            except ValueError:
                return None

        xi, yi, wi, hi = map(_to_int, (x, y, w, h))
        if None not in (xi, yi, wi, hi):
            # Guard against zero/negative sizes
            if wi > 0 and hi > 0:
                return {"x1": xi, "y1": yi, "x2": xi + wi, "y2": yi + hi}

        return None

    def _extract_display_text(self, attrs: dict) -> Tuple[Optional[str], Optional[str]]:
        """
        Cross-platform text picking order:
          - Android: text, content-desc, resource-id tail
          - iOS: name, label, value
        We'll unify and return the first non-empty.
        """
        # Normalize occasional empty strings like "" or " "
        def norm(v: Optional[str]) -> Optional[str]:
            if v is None:
                return None
            s = v.strip()
            return s if s else None

        text_candidates = [
            ("text", norm(attrs.get("text"))),                 # Android
            ("content-desc", norm(attrs.get("content-desc"))), # Android
            ("name", norm(attrs.get("name"))),                 # iOS
            ("label", norm(attrs.get("label"))),               # iOS
            ("value", norm(attrs.get("value"))),               # iOS
            (
                "resource-id",
                norm(attrs.get("resource-id", "").split("/")[-1])
                if attrs.get("resource-id") and not _obfuscated_id(attrs["resource-id"]) else None,  # Android
            ),
        ]
        for key, val in text_candidates:
            if val:
                return val, key
        return None, None

    def _build_extra_metadata(
        self, attrs: dict, used_key: Optional[str], tag: str
    ) -> dict:
        extra = {
            k: v
            for k, v in attrs.items()
            if k != used_key and v and (isinstance(v, str) and v.lower() != "false" or not isinstance(v, str))
        }
        # Keep a few common fields explicitly
        extra["class"] = attrs.get("class")  # Android
        extra["resource-id"] = attrs.get("resource-id")  # Android
        extra["visible"] = attrs.get("visible")  # iOS
        extra["enabled"] = attrs.get("enabled")  # both
        extra["tag"] = tag  # e.g., XCUIElementTypeButton or android.widget.Button
        return extra

    def _xpath_from_single_attr(
        self, node: etree.Element, attr_name: str, tag_for_xpath: str
    ) -> Optional[Tuple[str, Tuple[Tuple[str, str], ...]]]:
        """Return the ``//tag[@attr=value]`` probe and the conditions it encodes."""
        val = node.attrib.get(attr_name)
        if not val:
            return None
        lit = self._escape_for_xpath_literal(val)
        return f"//{tag_for_xpath}[@{attr_name}={lit}]", ((attr_name, val),)

    def _xpath_from_attr_pair(
        self, node: etree.Element, attr_pair: Tuple[str, str], tag_for_xpath: str
    ) -> Optional[Tuple[str, Tuple[Tuple[str, str], ...]]]:
        """Return the two-attribute probe and the conditions it encodes."""
        a1, a2 = attr_pair
        v1, v2 = node.attrib.get(a1), node.attrib.get(a2)
        if not v1 or not v2:
            return None
        lit1, lit2 = self._escape_for_xpath_literal(v1), self._escape_for_xpath_literal(v2)
        return f"//{tag_for_xpath}[@{a1}={lit1} and @{a2}={lit2}]", ((a1, v1), (a2, v2))

    def _xpath_try_attributes_for_unique(
        self,
        node: etree.Element,
        index: XPathUniquenessIndex,
        attrs: List[Union[str, Tuple[str, str]]],
    ) -> Tuple[Optional[str], bool]:
        tag_for_xpath = node.tag or "*"
        is_pairs = bool(attrs and isinstance(attrs[0], tuple))
        semi_unique_xpath: Optional[str] = None

        for entry in attrs:
            if is_pairs:
                probe = self._xpath_from_attr_pair(node, cast(Tuple[str, str], entry), tag_for_xpath)
            else:
                probe = self._xpath_from_single_attr(node, cast(str, entry), tag_for_xpath)
            if not probe:
                continue
            xpath, conditions = probe
            matches = index.matches(tag_for_xpath, conditions)
            if len(matches) == 1:
                return xpath, True
            if semi_unique_xpath is None and matches:
                # Position the node among its peers, as `(xpath)[n]` is 1-based.
                semi_unique_xpath = f"({xpath})[{index.position_of(matches, node) + 1}]"

        if semi_unique_xpath:
            return semi_unique_xpath, False
        return None, False

    def _xpath_try_node_name(
        self, node: etree.Element, index: XPathUniquenessIndex
    ) -> Tuple[Optional[str], bool]:
        tag = node.tag or "*"
        if len(index.matches(tag, ())) != 1:
            return None, False
        return (f"/{tag}" if node.getparent() is None else f"//{tag}"), True

    def _xpath_attribute_pairs_permutations(
        self, attributes: List[str]
    ) -> List[Tuple[str, str]]:
        return [(v1, v2) for i, v1 in enumerate(attributes) for v2 in attributes[i + 1 :]]

    def _xpath_try_cases_for_unique(
        self, node: etree.Element, index: XPathUniquenessIndex
    ) -> Optional[str]:
        unique = (
            [a for a in XPATH_UNIQUE_ATTRIBUTES if a != "resource-id"]
            if _obfuscated_id(node.attrib.get("resource-id") or "") else XPATH_UNIQUE_ATTRIBUTES
        )
        maybe = XPATH_INPUT_MAYBE_UNIQUE_ATTRIBUTES if "input" in self._element_actions(node) else XPATH_MAYBE_UNIQUE_ATTRIBUTES
        cases: List[Any] = [
            unique,
            self._xpath_attribute_pairs_permutations([*unique, *maybe]),
            maybe,
            [],
        ]
        semi_unique: Optional[str] = None
        for attrs in cases:
            if len(attrs) == 0:
                xpath, is_unique = self._xpath_try_node_name(node, index)
            else:
                xpath, is_unique = self._xpath_try_attributes_for_unique(node, index, attrs)
            if is_unique and xpath:
                return xpath
            if semi_unique is None and xpath:
                semi_unique = xpath
        return semi_unique

    def _xpath_build_hierarchical(
        self, node: etree.Element, index: XPathUniquenessIndex
    ) -> str:
        tag = node.tag
        if not tag:
            return ""
        parent = node.getparent()
        segment = f"/{tag}"
        if parent is not None:
            siblings_same_tag = [c for c in parent if c.tag == tag]
            if len(siblings_same_tag) > 1:
                idx = siblings_same_tag.index(node) + 1
                segment += f"[{idx}]"
        if parent is not None and hasattr(parent, "tag"):
            return f"{self.get_xpath(parent, index)}{segment}"
        return segment

    def get_xpath(
        self, node: etree.Element, index: Optional[XPathUniquenessIndex] = None
    ) -> str:
        """
        Generate an optimal XPath for a given node using attribute-based
        uniqueness checks and semi-unique indexing, falling back to a
        hierarchical path when required. Mirrors the behavior of the
        provided getOptimalXPath logic.

        ``index`` lets a caller labelling many nodes of one tree share a single
        uniqueness index; it is built for this document when omitted. Results are
        memoised on the index because the hierarchical fallback re-derives every
        ancestor's XPath on the way up.
        """
        if node is None or not hasattr(node, "tag"):
            return ""
        if index is None:
            index = XPathUniquenessIndex(node.getroottree().getroot())
        cached = index.xpath_cache.get(node)
        if cached is not None:
            return cached
        candidate = self._xpath_try_cases_for_unique(node, index)
        if not candidate:
            candidate = self._xpath_build_hierarchical(node, index) or self._build_structural_xpath(node)
        index.xpath_cache[node] = candidate
        return candidate

    def nth_view_locator(self, strategy: str, locator: str, occurrence: int) -> str:
        return f"(//*[@{strategy}={self._escape_for_xpath_literal(locator)}])[{occurrence}]"

    def _escape_for_xpath_literal(self, s: str) -> str:
        """
        Safely escape a string for inclusion in an XPath string literal.
        Uses the concat() trick if both single and double quotes are present.
        """
        if '"' not in s:
            return f'"{s}"'
        if "'" not in s:
            return f"'{s}'"
        # If it contains both, break on double quotes and concat with '\"'
        parts = s.split('"')
        escaped_parts = []
        for i, p in enumerate(parts):
            if i == len(parts)-1:
                escaped_parts.append(f'"{p}"')
            else:
                escaped_parts.extend([f'"{p}"', "'\"'"])
        return 'concat(' + ', '.join(escaped_parts) + ')'

    def _build_attribute_condition(self, attr: str, val: str) -> str:
        """
        Return the appropriate condition expression for the attribute match.
        - Exact match for iOS name/label (typically normalized and unique)
        - Exact match for Android resource-id when namespaced
        - Contains match for content-like attributes (Android text/desc, iOS value)
        """
        val = val.strip()
        lit = self._escape_for_xpath_literal(val)

        # Android id exact match when namespaced
        if attr == "resource-id" and "/" in val:
            return f"@{attr}={lit}"

        # iOS: be strict for 'name'/'label'
        if attr in ("name", "label"):
            return f"@{attr}={lit}"

        # Keep contains() for content-ish attributes (Android text/desc, iOS value)
        return f"contains(@{attr}, {lit})"

    def _build_structural_xpath(self, node: etree.Element) -> str:
        """
        Fallback method to build full XPath based on element structure.
        Works for both Android and iOS trees.
        - Android: stops at hierarchy root
        - iOS: walks to XCUIElementTypeApplication root
        """
        path = []
        cur = node
        while cur is not None:
            parent = cur.getparent()
            if parent is None:
                # reached document root
                path.append(cur.tag)
                break
            siblings = [sib for sib in parent if sib.tag == cur.tag]
            index = siblings.index(cur) + 1 if len(siblings) > 1 else 1
            path.append(f"{cur.tag}[{index}]")
            cur = parent
        return "/" + "/".join(reversed(path))

    def _should_include_element(self, node: etree.Element, filter_config: Optional[List[str]]) -> bool:
        """
        Determine if an element should be included based on filter_config.

        Args:
            node: The XML element node
            filter_config: Optional list of filter types

        Returns:
            True if element should be included, False otherwise
        """
        # Default behavior: show all elements when filter_config is None or empty
        if not filter_config or len(filter_config) == 0:
            return True

        # If "all" is in filter_config, show all elements
        if "all" in filter_config:
            return True

        # Check each filter type - return early if any match
        if "interactive" in filter_config and self._is_probably_interactive(node):
            return True

        if "buttons" in filter_config and self._is_button(node):
            return True

        if "inputs" in filter_config and self._is_input(node):
            return True

        if "images" in filter_config and self._is_image(node):
            return True

        if "text" in filter_config and self._is_text(node):
            return True

        return False

    def _is_button(self, node: etree.Element) -> bool:
        """Check if element is a button."""
        tag = node.tag or ""
        # Android: android.widget.Button
        # iOS: XCUIElementTypeButton
        return "Button" in tag

    def _is_input(self, node: etree.Element) -> bool:
        """Check if element is an input/text field."""
        tag = node.tag or ""
        # Android: EditText, TextView (when editable/focusable)
        # iOS: XCUIElementTypeTextField, XCUIElementTypeSecureTextField, XCUIElementTypeTextView
        if any(t in tag for t in ["TextField", "EditText", "SecureTextField"]):
            return True
        if "TextView" in tag and node.attrib.get("focusable") == "true":
            return True
        return False

    def _is_image(self, node: etree.Element) -> bool:
        """Check if element is an image."""
        tag = node.tag or ""
        # Android: ImageView
        # iOS: XCUIElementTypeImage
        return "Image" in tag

    def _is_text(self, node: etree.Element) -> bool:
        """Check if element is a text element (non-input)."""
        tag = node.tag or ""
        # Android: TextView (non-editable)
        # iOS: XCUIElementTypeStaticText
        # Exclude inputs
        if self._is_input(node):
            return False
        return "StaticText" in tag or ("TextView" in tag and "EditText" not in tag)

    def _is_probably_interactive(self, node: etree.Element) -> bool:
        """
        Check if element is probably interactive (clickable, enabled, etc.).
        """
        attrs = node.attrib or {}
        tag = node.tag or ""

        # Quick heuristics
        if attrs.get("clickable") == "true":
            return True
        if attrs.get("enabled") == "true" and attrs.get("visible", "true") != "false":
            if tag.startswith("XCUIElementTypeButton") or tag.startswith("android.widget.Button"):
                return True
            if "ImageView" in tag or "XCUIElementTypeImage" in tag:
                # Often icon buttons; your call whether to include
                return True
        return False
