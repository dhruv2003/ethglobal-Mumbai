import os
import sys
from pathlib import Path
from typing import Optional

from rich.prompt import Confirm

from optics_framework.helper.initialize import available_templates

# Raw string: the `\` line-continuations below must reach the generated script
# verbatim. A normal string would let Python collapse each `\`+newline, emitting
# the `_arguments` calls as one unreadable line.
ZSH_COMPLETION_CONTENT = r"""# Description: Zsh completion script for the Optics CLI tool
local -a _optics_subcommands=(
  'list: List available API methods'
  'configure: Edit a project config.yaml (guided prompts or --edit TUI)'
  'config: Deprecated alias for configure'
  'doctor: Diagnose a project setup (engines, config, tooling)'
  'quickstart: Guided walkthrough to create and configure a first project'
  'dry_run: Run tests in dry-run mode'
  'dry-run: Run tests in dry-run mode'
  'init: Initialize a new project'
  'execute: Execute tests'
  'live: Interactive session against a live target'
  'generate: Generate framework code'
  'setup: Install optional engine backends'
  'serve: Start the optics REST server'
  'mcp: Start the MCP server'
  'completion: Enable shell completion'
)

# Static or dynamic values
local -a templates=(__OPTICS_TEMPLATES_ZSH__)
local -a runners=("test_runner" "pytest")
local -a frameworks=("pytest" "robot")
local -a transports=("stdio" "http")
# `optics setup --list` indents each installable engine key by two spaces under a
# category header; take only those indented lines so this stays correct no matter
# what the category headers are named.
local -a engines=("${(f)$(optics setup --list 2>/dev/null | awk '/^  / {print $1}')}")

_optics_completions() {
  local state

  _arguments -C \
    '(-)--version[Show the Optics Framework version]' \
    '(-)--help[-h]' \
    '1:command:->cmds' \
    '*::arg:->args'

  case $state in
    cmds)
      _describe 'command' _optics_subcommands
      ;;
    args)
      case $words[2] in
        list|config|completion|quickstart)
          _arguments '--help[-h]'
          ;;

        configure)
          _arguments \
            '*:project_folder:_files -/' \
            '--edit[Launch the full-field Textual editor]' \
            '--help[-h]'
          ;;

        doctor)
          _arguments \
            '*:project_folder:_files -/' \
            '--check[Exit non-zero if any check fails]' \
            '--help[-h]'
          ;;

        live)
          _arguments \
            '*:project_path:_files -/' \
            '--help[-h]'
          ;;

        mcp)
          _arguments \
            '--transport=[Transport]:transport:(${transports[@]})' \
            '--host=[Host address]' \
            '--port=[Port number]' \
            '--help[-h]'
          ;;

        dry_run|dry-run|execute)
          _arguments \
            '--runner=[Runner]:runner:(${runners[@]})' \
            '--use-printer[Enable printer]' \
            '--no-use-printer[Disable printer]' \
            '*--include=[Run only these test cases]:test case:' \
            '*--exclude=[Skip these test cases]:test case:' \
            '--help[-h]'
          ;;

        init)
          _arguments \
            '1:project_name:' \
            '--name=[Project name (deprecated; use the positional)]' \
            '--path=[Project path]' \
            '--force[Override existing]' \
            "--template=[Template name]:template:(${templates[@]})" \
            '--git-init[Initialize Git]' \
            '--help[-h]'
          ;;

        generate)
          _arguments \
            '*:project_path:_files' \
            '*:output_file:_files' \
            '--framework=[Framework]:framework:(${frameworks[@]})' \
            '--help[-h]'
          ;;

        setup)
          _arguments \
            "--install=[Engines]:engines:(${engines[@]})" \
            '--list[List all engines]' \
            '--help[-h]'
          ;;

        serve)
          _arguments \
            '--host=[Host address]' \
            '--port=[Port number]' \
            '--help[-h]'
          ;;

        *)
          # Unknown subcommand: offer only --help.
          _arguments '--help[-h]'
          ;;
      esac
      ;;

    *)
      # Unexpected state: nothing to complete.
      ;;
  esac
}

compdef _optics_completions optics
"""

BASH_COMPLETION_CONTENT = """#!/bin/bash

_optics_completions() {
  local cur prev words cword
  _init_completion || return

  local subcommands="list configure config doctor quickstart dry_run dry-run init execute live generate setup serve mcp completion"

  local template_options="__OPTICS_TEMPLATES_BASH__"
  local runner_options="test_runner pytest"
  # Only the two-space-indented lines are engine keys; category headers are not
  # indented, so this needs no per-header filter.
  local engine_options=$(optics setup --list 2>/dev/null | awk '/^  / {print $1}')

  case ${COMP_CWORD} in
    1)
      COMPREPLY=( $(compgen -W "$subcommands --version --help -h" -- "$cur") )
      return 0
      ;;
    *)
      # Beyond the subcommand: handled per-subcommand below.
      ;;
  esac

  case ${COMP_WORDS[1]} in
    list|config|completion|quickstart)
      COMPREPLY=( $(compgen -W "--help -h" -- "$cur") )
      ;;

    configure)
      if [[ $cur == -* ]]; then
        COMPREPLY=( $(compgen -W "--edit -h --help" -- "$cur") )
      else
        COMPREPLY=( $(compgen -d -- "$cur") )
      fi
      ;;

    doctor)
      if [[ $cur == -* ]]; then
        COMPREPLY=( $(compgen -W "--check -h --help" -- "$cur") )
      else
        COMPREPLY=( $(compgen -d -- "$cur") )
      fi
      ;;

    live)
      COMPREPLY=( $(compgen -d -- "$cur") )
      ;;

    mcp)
      if [[ $prev == "--transport" ]]; then
        COMPREPLY=( $(compgen -W "stdio http" -- "$cur") )
      else
        COMPREPLY=( $(compgen -W "--transport --host --port -h --help" -- "$cur") )
      fi
      ;;

    dry_run|dry-run|execute)
      if [[ $prev == "--runner" ]]; then
        COMPREPLY=( $(compgen -W "$runner_options" -- "$cur") )
      else
        COMPREPLY=( $(compgen -W "--runner --use-printer --no-use-printer --include --exclude -h --help" -- "$cur") )
      fi
      ;;

    init)
      case $prev in
        --template)
          COMPREPLY=( $(compgen -W "$template_options" -- "$cur") )
          ;;
        *)
          COMPREPLY=( $(compgen -W "--name --path --force --template --git-init -h --help" -- "$cur") )
          ;;
      esac
      ;;

    generate)
      COMPREPLY=( $(compgen -W "-h --help" -- "$cur") )
      if [[ $prev == "--framework" ]]; then
        COMPREPLY=( $(compgen -W "pytest robot" -- "$cur") )
      elif [[ $prev == "--output" ]]; then
        COMPREPLY=( $(compgen -f -- "$cur") )
      elif [[ $prev == "--project_path" ]]; then
        COMPREPLY=( $(compgen -d -- "$cur") )
      else
        : # keep the default --help completion set above
      fi
      ;;

    setup)
      case $prev in
        --install)
          COMPREPLY=( $(compgen -W "$engine_options" -- "$cur") )
          ;;
        *)
          COMPREPLY=( $(compgen -W "--install --list -h --help" -- "$cur") )
          ;;
      esac
      ;;

    serve)
      COMPREPLY=( $(compgen -W "--host --port -h --help" -- "$cur") )
      ;;

    *)
      # Unknown subcommand: offer only --help.
      COMPREPLY=( $(compgen -W "-h --help" -- "$cur") )
      ;;
  esac
}

complete -F _optics_completions optics
"""

def _render(content: str) -> str:
    """Fill the sample-template placeholders from the single source of truth in
    ``initialize.available_templates()`` so the completion candidates never drift
    from the templates that actually ship."""
    templates = available_templates()
    zsh_arr = " ".join(f'"{t}"' for t in templates)
    bash_list = " ".join(templates)
    return (content
            .replace("__OPTICS_TEMPLATES_ZSH__", zsh_arr)
            .replace("__OPTICS_TEMPLATES_BASH__", bash_list))


def write_completion_scripts():
    optics_dir = Path.home() / ".optics"
    optics_dir.mkdir(exist_ok=True)
    zsh_path = optics_dir / "optics_completion.zsh"
    bash_path = optics_dir / "optics_completion.sh"
    zsh_path.write_text(_render(ZSH_COMPLETION_CONTENT))
    bash_path.write_text(_render(BASH_COMPLETION_CONTENT))
    return zsh_path, bash_path

def _manual_instruction(rc_file: Path, source_line: str) -> str:
    """The copy-pasteable fallback shown when the rc file is left untouched."""
    return (f"To enable manually, add this line to {rc_file}:\n"
            f"  {source_line.strip()}")


def update_shell_rc(shell: Optional[str] = None):
    """Enable shell autocompletion — with consent.

    The ``~/.optics/optics_completion.*`` scripts are always generated. The
    rc-file mutation itself is gated: with a TTY stdin the user is asked
    before anything is appended, and a decline (or a non-TTY stdin, which
    cannot answer prompts) leaves the rc file untouched and prints the manual
    ``source`` line instead."""
    zsh_path, bash_path = write_completion_scripts()
    home = Path.home()
    if shell is None:
        shell = os.environ.get("SHELL", "")
    if "zsh" in shell:
        rc_file = home / ".zshrc"
        completion_file = zsh_path
        source_line = f"source {completion_file}\n"
    elif "bash" in shell:
        rc_file = home / ".bashrc"
        completion_file = bash_path
        source_line = f"source {completion_file}\n"
    else:
        print("Unsupported shell. Only bash and zsh are supported.")
        return

    # Avoid duplicate source lines
    if rc_file.exists():
        with open(rc_file, "r", encoding="utf-8") as f:
            lines = f.readlines()
        if any(source_line.strip() in line.strip() for line in lines):
            print(f"Autocompletion already enabled in {rc_file}")
            return

    if not sys.stdin.isatty() or not Confirm.ask(
        f"Add autocompletion to {rc_file}?", default=True
    ):
        print(_manual_instruction(rc_file, source_line))
        return

    with open(rc_file, "a", encoding="utf-8") as f:
        f.write(f"\n# Optics CLI autocompletion\n{source_line}")
    print(f"Added autocompletion to {rc_file}. Please restart your shell or run: source {rc_file}")
