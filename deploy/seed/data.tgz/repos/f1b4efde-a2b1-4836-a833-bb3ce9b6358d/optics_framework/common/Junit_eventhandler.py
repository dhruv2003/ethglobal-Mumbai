from optics_framework.common.events import EventSubscriber, Event, EventStatus, get_event_manager
import json
import xml.etree.ElementTree as ET #nosec B405
from pathlib import Path
from typing import List, Dict, Optional, Tuple
import xml.dom.minidom  #nosec B408
import time
from datetime import datetime
import logging
import threading
from optics_framework.common.logging_config import internal_logger, execution_logger, mask_secrets, mask_secret_values
from optics_framework.common.config_handler import Config
from optics_framework.common.error_detection import ON_SCREEN_ERROR_CASE
from optics_framework.common.models import TestCaseNode



class JUnitHandlerRegistry:
    """Registry for managing session-scoped JUnit handlers."""

    def __init__(self):
        self._handlers: Dict[str, "JUnitEventHandler"] = {}
        self._lock = threading.Lock()

    def setup_junit_for_session(self, session_id: str, config: Config) -> None:
        """Setup JUnit logging for a specific session."""
        with self._lock:
            # Cleanup existing handler for this session if it exists
            if session_id in self._handlers:
                self._handlers[session_id].close()
                del self._handlers[session_id]

            # Create session-specific output path
            junit_path = self._get_session_junit_path(session_id, config)
            json_log_path = self._get_json_log_path(config)
            handler = JUnitEventHandler(junit_path, json_output_path=json_log_path, suite_name=_suite_name(config))

            # Subscribe to session-specific EventManager
            event_manager = get_event_manager(session_id)
            event_manager.subscribe("junit", handler)

            self._handlers[session_id] = handler
            internal_logger.debug(f"Setup JUnit handler for session {session_id}: {junit_path}")
            internal_logger.debug(f"Session {session_id} EventManager has {len(event_manager.subscribers)} subscribers: {list(event_manager.subscribers.keys())}")

    def _get_session_junit_path(self, session_id: str, config: Config) -> Path:
        """Generate the canonical JUnit XML output path.

        Falls back to a session-suffixed name when another active handler
        already owns the canonical file in the same output directory, so
        concurrent sessions never clobber each other's report.
        """
        log_dir = Path(config.execution_output_path or (Path.cwd() / "logs"))
        junit_path = log_dir / "junit_output.xml"
        for other_id, handler in self._handlers.items():
            if other_id != session_id and handler.output_path == junit_path:
                return log_dir / f"junit_output_{session_id}.xml"
        return junit_path

    def _get_json_log_path(self, config: Config) -> Optional[Path]:
        """Generate the JSON event log output path, or None when json_log is disabled."""
        if not getattr(config, 'json_log', False):
            return None
        custom_path = getattr(config, 'json_path', None)
        if custom_path:
            return Path(custom_path).expanduser()
        log_dir = config.execution_output_path or (Path.cwd() / "logs")
        return Path(log_dir) / "logs.json"

    def cleanup_session(self, session_id: str) -> None:
        """Cleanup JUnit handler for a specific session."""
        with self._lock:
            if session_id in self._handlers:
                self._handlers[session_id].close()
                del self._handlers[session_id]
                internal_logger.debug(f"Cleaned up JUnit handler for session {session_id}")

    def get_handler(self, session_id: str) -> Optional["JUnitEventHandler"]:
        """Get the JUnit handler for a specific session."""
        with self._lock:
            return self._handlers.get(session_id)

    def get_active_sessions(self) -> List[str]:
        """Get list of sessions with active JUnit handlers."""
        with self._lock:
            return list(self._handlers.keys())

_junit_handler_registry = JUnitHandlerRegistry()

def setup_junit(session_id: str, config: Config) -> None:
    """Setup JUnit logging for a specific session."""
    _junit_handler_registry.setup_junit_for_session(session_id, config)

def cleanup_junit(session_id: str) -> None:
    """Cleanup JUnit handler for a specific session."""
    _junit_handler_registry.cleanup_session(session_id)

def get_junit_handler_registry() -> JUnitHandlerRegistry:
    """Get the global JUnitHandlerRegistry instance."""
    return _junit_handler_registry

# Legacy support - will be deprecated
junit_handler = None

class LogCaptureBuffer(logging.Handler):
    """
    Custom log handler to capture logs emitted during keyword execution.
    """
    def __init__(self):
        super().__init__()
        self.records = []

    def emit(self, record):
        self.records.append(record)

    def clear(self):
        self.records.clear()

    def get_records(self):
        return self.records


_MASKED_EVENT_FIELDS = ("message", "args", "logs")

# A test case's modules in order, each with its keywords in order.
CasePlan = List[Tuple[str, List[str]]]


def _suite_name(config: Config) -> str | None:
    """The project folder's name, which names the test suite and each test case's class."""
    if not config.project_path:
        return None
    return Path(config.project_path).resolve().name or None


def _iso_time(epoch: float) -> str:
    return datetime.fromtimestamp(epoch).astimezone().isoformat(timespec="milliseconds")


def _robot_time(epoch: float) -> str:
    return datetime.fromtimestamp(epoch).strftime("%Y%m%d %H:%M:%S.%f")[:-3]


def _set_step_result(element: ET.Element, event: Event) -> None:
    """Write a module or keyword event's status, failure message and times onto its ``kw`` element."""
    element.set("status", event.status.value)
    if event.status in (EventStatus.FAIL, EventStatus.ERROR) and event.message:
        element.set("message", event.message)
    if event.start_time:
        element.set("starttime", _robot_time(event.start_time))
    if event.end_time:
        element.set("endtime", _robot_time(event.end_time))
    if event.elapsed:
        element.set("elapsed", f"{event.elapsed:.2f}")


class JUnitEventHandler(EventSubscriber):
    def __init__(self, output_path: Path, json_output_path: Optional[Path] = None, suite_name: str | None = None):
        self.output_path = output_path
        self.json_output_path = json_output_path
        self.suite_name = suite_name
        self.testsuites = ET.Element("testsuites")
        self.session_suites: Dict[str, ET.Element] = {}
        self.testcase_cases: Dict[str, ET.Element] = {}
        self.start_times: Dict[str, float] = {}
        self.module_names: Dict[str, str] = {}
        self.module_elements: Dict[str, ET.Element] = {}
        self.active_keyword_elements: Dict[str, ET.Element] = {}  # Per keyword_id for update during execution
        self.keyword_log_buffers: Dict[str, LogCaptureBuffer] = {}
        self.json_events: List[Dict] = []
        self.run_plans: Dict[str, List[Tuple[str, CasePlan]]] = {}
        self.started_names: Dict[str, set[str]] = {}
        self.start_errors: Dict[str, str] = {}

        internal_logger.debug(f"Initialized JUnitEventHandler with output: {self.output_path}")

    def plan_run(self, session_id: str, plan: List[Tuple[str, CasePlan]], start_error: str | None = None) -> None:
        """Give the test cases the run will start, so the report lists every step and test case that never ran.

        With ``start_error`` the run could not start: each test case is reported as an error with that message.
        """
        self.run_plans[session_id] = list(plan)
        if start_error:
            self.start_errors[session_id] = start_error

    async def on_event(self, event: Event) -> None:
        internal_logger.debug(
            f"JUnitEventHandler received event: {event.model_dump()}")
        self.json_events.append(event.model_dump())
        session_id = event.extra.get("session_id") if event.extra else None
        if not session_id and event.entity_type == "test_case":
            internal_logger.warning(
                f"Test case event missing session_id: {event.model_dump()}")
            execution_logger.warning(
                f"Test case event missing session_id: {event.model_dump()}")
            return

        if event.entity_type == "test_case":
            if session_id is None:
                return
            self._handle_test_case_event(event, self._session_suite(session_id), session_id)
        elif event.entity_type == "module":
            self._handle_module_event(event)
        elif event.entity_type == "keyword":
            self._handle_keyword_event(event)

    def _session_suite(self, session_id: str) -> ET.Element:
        session_suite = self.session_suites.get(session_id)
        if session_suite is None:
            session_suite = ET.SubElement(
                self.testsuites, "testsuite",
                name=self._classname(session_id), id=session_id,
                tests="0", failures="0", errors="0", skipped="0", time="0"
            )
            self.session_suites[session_id] = session_suite
        return session_suite

    def _classname(self, session_id: str) -> str:
        return self.suite_name or f"session_{session_id}"

    def _handle_test_case_event(self, event: Event, session_suite: ET.Element, session_id: str) -> None:
        event_time = getattr(event, 'timestamp', time.time())
        internal_logger.debug(
            f"Handling test_case event: id={event.entity_id}, status={event.status}, timestamp={event_time}")
        if event.status == EventStatus.RUNNING:
            timestamp = _iso_time(event.start_time or event_time)
            session_suite.attrib.setdefault("timestamp", timestamp)
            testcase = ET.SubElement(
                session_suite, "testcase",
                name=event.name, id=event.entity_id, classname=self._classname(session_id), time="0",
                timestamp=timestamp,
            )
            self.testcase_cases[event.entity_id] = testcase
            self.start_times[event.entity_id] = event_time
            self.started_names.setdefault(session_id, set()).add(event.name)
            session_suite.set("tests", str(
                int(session_suite.get("tests", "0")) + 1))
            internal_logger.debug(
                f"Created testcase: id={event.entity_id}, start_time={event_time}")
        elif event.entity_id in self.testcase_cases:
            testcase = self.testcase_cases[event.entity_id]
            elapsed = event_time - self.start_times.get(event.entity_id, event_time)
            testcase.set("time", f"{elapsed:.2f}")
            _add_not_run_steps(testcase, self._case_plan(session_id, event.name))
            self._update_testcase_status(testcase, event, session_suite)

            total_time = float(session_suite.get("time", "0")) + elapsed
            session_suite.set("time", f"{total_time:.2f}")

            # cleanup
            del self.testcase_cases[event.entity_id]
            del self.start_times[event.entity_id]
            if event.entity_id in self.module_names:
                del self.module_names[event.entity_id]

    def _handle_module_event(self, event: Event) -> None:
        testcase = self.testcase_cases.get(event.parent_id or "")
        if testcase is None:
            return
        if event.status in (EventStatus.RUNNING, EventStatus.NOT_RUN):
            self.module_elements[event.entity_id] = ET.SubElement(testcase, "kw", name=event.name, type="setup")
        module_kw = self.module_elements.get(event.entity_id)
        if module_kw is not None:
            _set_step_result(module_kw, event)

    def _handle_keyword_event(self, event: Event) -> None:
        module_kw = self.module_elements.get(event.parent_id or "")
        if module_kw is None:
            return  # Module not active yet

        kw_element = self.active_keyword_elements.pop(event.entity_id, None)
        if kw_element is None:
            kw_element = ET.SubElement(module_kw, "kw", name=event.name)
        if event.status == EventStatus.RUNNING:
            self.active_keyword_elements[event.entity_id] = kw_element
        _set_step_result(kw_element, event)

        if event.args:
            args_element = ET.SubElement(kw_element, "arguments")
            for arg in event.args:
                ET.SubElement(args_element, "arg").text = str(arg)

        if event.logs:
            internal_logger.debug(f"Keyword {event.name} has logs: {event.logs}")
            for message in event.logs:
                ET.SubElement(kw_element, "log").text = message

    def _update_testcase_status(self, testcase: ET.Element, event: Event, testsuite: ET.Element) -> None:
        testcase.set("status", event.status.value)
        if event.status == EventStatus.FAIL:
            failure = ET.SubElement(
                testcase, "failure", message=event.message, type="Failure")
            failure.text = event.message
            testsuite.set("failures", str(
                int(testsuite.get("failures", "0")) + 1))
        elif event.status == EventStatus.ERROR:
            error = ET.SubElement(
                testcase, "error", message=event.message, type="Error")
            error.text = event.message
            testsuite.set("errors", str(int(testsuite.get("errors", "0")) + 1))
        elif event.status == EventStatus.SKIPPED:
            ET.SubElement(testcase, "skipped")
            testsuite.set("skipped", str(
                int(testsuite.get("skipped", "0")) + 1))

    def add_detected_errors(self, session_id: str, detected: list) -> None:
        """Insert a synthetic testcase with <failure> elements for detected on-screen errors.

        Using a real testcase (rather than <properties>) means standard CI tools
        (Jenkins, GitLab CI, GitHub Actions) will surface the failures and mark
        the build accordingly.

        The run's test-case events may still be queued when this is called, so
        the session suite is created here if needed and those events attach to
        it once they are processed.
        """
        if not detected:
            return
        session_suite = self._session_suite(session_id)
        testcase = ET.SubElement(
            session_suite, "testcase",
            name=ON_SCREEN_ERROR_CASE,
            classname=self._classname(session_id),
            time="0",
            status=EventStatus.FAIL.value,
        )
        for err in detected:
            parts = filter(None, [
                err["error_code"],
                err.get("severity", ""),
                err.get("match_string", ""),
                err.get("description", ""),
            ])
            msg = " | ".join(parts)
            failure = ET.SubElement(testcase, "failure", message=msg, type="OnScreenError")
            failure.text = msg
        session_suite.set("tests", str(int(session_suite.get("tests", "0")) + 1))
        session_suite.set("failures", str(int(session_suite.get("failures", "0")) + len(detected)))

    def _flush_json(self):
        if self.json_output_path is None:
            return
        try:
            self.json_output_path.parent.mkdir(parents=True, exist_ok=True)
            with open(self.json_output_path, "w", encoding="utf-8") as f:
                f.write(json.dumps([_masked_event(event) for event in self.json_events], indent=2))
        except Exception as e:
            internal_logger.error(f"Failed to flush JSON events: {str(e)}")

    def flush(self):
        try:
            internal_logger.debug(f"Flushing Robot-style XML to {self.output_path}")
            self.output_path.parent.mkdir(parents=True, exist_ok=True)

            _mask_tree(self.testsuites)
            # Convert ElementTree to string
            rough_string = ET.tostring(self.testsuites, encoding="utf-8")   #nosec B318
            reparsed = xml.dom.minidom.parseString(rough_string) #nosec B318
            pretty_xml = reparsed.toprettyxml(indent="  ")

            with open(self.output_path, "w", encoding="utf-8") as f:
                f.write(pretty_xml)
        except Exception as e:
            internal_logger.error(f"Failed to flush Robot-style XML: {str(e)}")
        self._flush_json()

    def close(self):
        self._mark_unfinished()
        self._move_detection_last()
        self.flush()

    def _move_detection_last(self) -> None:
        """Put the on-screen error test case after the test cases, which may still have been queued when it was added."""
        for suite in self.session_suites.values():
            for testcase in suite.findall(f"testcase[@name='{ON_SCREEN_ERROR_CASE}']"):
                suite.remove(testcase)
                suite.append(testcase)

    def _mark_unfinished(self) -> None:
        for session_id, suite in self.session_suites.items():
            for testcase in suite.findall("testcase"):
                if testcase.get("id", "") in self.testcase_cases:
                    self._end_with_error(testcase, suite, session_id)
        for session_id, plan in self.run_plans.items():
            self._add_never_started(session_id, plan)
        self.run_plans.clear()
        self.start_errors.clear()

    def _end_with_error(self, testcase: ET.Element, suite: ET.Element, session_id: str) -> None:
        """Give an error to a test case that started but has no result."""
        for kw in testcase.iter("kw"):
            if kw.get("status") == EventStatus.RUNNING.value:
                kw.set("status", EventStatus.ERROR.value)
        unfinished = Event(
            entity_type="test_case", entity_id=testcase.get("id", ""), name=testcase.get("name", ""),
            status=EventStatus.ERROR, message="The run ended before this test case reported a result.",
        )
        self._handle_test_case_event(unfinished, suite, session_id)

    def _add_never_started(self, session_id: str, plan: List[Tuple[str, CasePlan]]) -> None:
        started = self.started_names.get(session_id, set())
        for name, case_plan in plan:
            if name not in started:
                self._add_not_run(self._session_suite(session_id), session_id, name, case_plan)

    def _case_plan(self, session_id: str, name: str) -> CasePlan:
        return next((case_plan for case, case_plan in self.run_plans.get(session_id, []) if case == name), [])

    def _add_not_run(self, suite: ET.Element, session_id: str, name: str, case_plan: CasePlan) -> None:
        start_error = self.start_errors.get(session_id)
        status = EventStatus.ERROR if start_error else EventStatus.NOT_RUN
        testcase = ET.SubElement(
            suite, "testcase", name=name, classname=self._classname(session_id), time="0", status=status.value,
        )
        _add_not_run_steps(testcase, case_plan)
        if start_error:
            ET.SubElement(testcase, "error", message=start_error, type="Error").text = start_error
            suite.set("errors", str(int(suite.get("errors", "0")) + 1))
        else:
            ET.SubElement(testcase, "skipped", message="The run ended before this test case started.")
            suite.set("skipped", str(int(suite.get("skipped", "0")) + 1))
        suite.set("tests", str(int(suite.get("tests", "0")) + 1))


def run_plan(test_cases: Optional[TestCaseNode]) -> List[Tuple[str, CasePlan]]:
    """The test cases of an execution queue, each with its modules and their keywords, in run order."""
    plan = []
    case = test_cases
    while case:
        modules = []
        module = case.modules_head
        while module:
            keywords = []
            keyword = module.keywords_head
            while keyword:
                keywords.append(keyword.name)
                keyword = keyword.next
            modules.append((module.name, keywords))
            module = module.next
        plan.append((case.name, modules))
        case = case.next
    return plan


def _add_not_run_steps(testcase: ET.Element, case_plan: CasePlan) -> None:
    """Add the planned modules and keywords a test case did not reach, after the ones it ran, as NOT_RUN."""
    ran = testcase.findall("kw")
    if ran and len(ran) <= len(case_plan):
        last = ran[-1]
        for keyword in case_plan[len(ran) - 1][1][len(last.findall("kw")):]:
            ET.SubElement(last, "kw", name=keyword, status=EventStatus.NOT_RUN.value)
    for module, keywords in case_plan[len(ran):]:
        module_kw = ET.SubElement(testcase, "kw", name=module, type="setup", status=EventStatus.NOT_RUN.value)
        for keyword in keywords:
            ET.SubElement(module_kw, "kw", name=keyword, status=EventStatus.NOT_RUN.value)


def _mask_tree(root: ET.Element) -> None:
    """Mask secrets in the report's text and messages, but not in its names, ids and times."""
    for element in root.iter():
        if element.text:
            element.text = mask_secrets(element.text)
        if "message" in element.attrib:
            element.set("message", mask_secrets(element.attrib["message"]))


def _masked_event(event: dict) -> dict:
    return {**event, **{field: mask_secret_values(event[field]) for field in _MASKED_EVENT_FIELDS if field in event}}
