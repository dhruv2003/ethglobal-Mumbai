import json
import re
import os
import time
import uuid
import asyncio
import difflib
import tempfile
import shutil
import sys
import logging
from itertools import product
from typing import Callable, Dict, List, Optional, Union, Any
import pytest
from optics_framework.common.session_manager import Session
from optics_framework.common.error import OpticsError, Code
from optics_framework.common.config_handler import Config, ConfigHandler
from optics_framework.common.logging_config import (
    mask_secrets,
    use_secrets,
    internal_logger,
    execution_logger,
    LogCaptureBuffer,
)
from optics_framework.common import test_context
from optics_framework.common.runner.printers import (
    IResultPrinter,
    TestCaseResult,
    KeywordResult,
    ModuleResult,
    NullResultPrinter,
)
from optics_framework.common.models import (
    TestCaseNode,
    ModuleNode,
    ModuleData,
    KeywordNode,
    ElementData,
    State,
    Node,
    ApiData,
)
from optics_framework.common.events import (
    EventStatus,
    CommandType,
    Event,
)
from optics_framework.common.runner.data_reader import DataReader
from optics_framework.common.strategies import StrategyManager
from optics_framework.common import utils
from optics_framework.common.Junit_eventhandler import get_junit_handler_registry, run_plan
from optics_framework.common.session_liveness import is_dead_session_error
from optics_framework.common.error_detection import (
    ON_SCREEN_ERROR_CASE,
    extract_visible_text,
    detect_errors_in_text,
)


class Runner:
    test_case: TestCaseNode
    result_printer: IResultPrinter
    keyword_map: Dict[str, Callable[..., Any]]
    apis: ApiData
    elements: ElementData
    def _resolve_candidate_params(self, method, candidate_args):
        candidate_args = utils.substitute_inline(method, list(candidate_args), self.elements)
        positional_params, kw_params = DataReader.split_params_by_signature(
            method, candidate_args)
        raw = utils.raw_param_indices(method)
        resolved_positional_params = utils.unescape_vars(method, [
            param if i in raw else self.resolve_param(param) for i, param in enumerate(positional_params)
        ])
        resolved_kw_params = {key: self.resolve_param(value) for key, value in kw_params.items()}
        return resolved_positional_params, resolved_kw_params

    def execute_test_case(self, test_case: str) -> Optional[TestCaseResult]:
        """Empty implementation to satisfy the interface contract.
        Subclasses must provide concrete logic for executing test cases."""
        pass

    async def run_all(self) -> None:
        """Empty implementation to satisfy the interface contract.
        Subclasses must implement logic to run all test cases."""
        pass

    async def dry_run_test_case(self, test_case: str) -> Optional[TestCaseResult]:
        """Empty implementation to satisfy the interface contract.
        Subclasses must provide logic for dry-running test cases."""
        pass

    async def dry_run_all(self) -> None:
        """Empty implementation to satisfy the interface contract.
        Subclasses must implement logic to dry-run all test cases."""
        pass


async def queue_event(event: Event, event_manager) -> None:
    """Queue an event for async processing."""
    internal_logger.debug(f"Queueing event: {event.model_dump()}")
    await event_manager.publish_event(event)


def queue_event_sync(event: Event, event_manager) -> None:
    """Queue an event synchronously for pytest."""
    internal_logger.debug(f"Queueing event (sync): {event.model_dump()}")
    for _, subscriber in event_manager.subscribers.items():
        try:
            asyncio.run(subscriber.on_event(event))
        except RuntimeError as e:
            internal_logger.warning(f"Failed to process event synchronously: {e}")


class TestRunner(Runner):
    def __init__(
        self,
        session: Session,
        keyword_map: Dict[str, Callable[..., Any]],
        result_printer: IResultPrinter,
        event_manager,
    ) -> None:
        self.session = session
        self.session_id = session.session_id
        self.test_cases = self.session.test_cases
        self.modules = self.session.modules
        self.elements = self.session.elements if self.session.elements is not None else ElementData()
        self.apis = self.session.apis if self.session.apis is not None else ApiData()
        self.keyword_map = keyword_map
        self._failed_steps_elements: List[dict] = []
        self.result_printer = result_printer
        self.config = session.config
        self.event_manager = event_manager
        self._last_failure_reason: Optional[str] = None
        self._last_failure_status = EventStatus.FAIL
        if hasattr(self.modules, "modules"):
            execution_logger.debug(
                "Initialized test_state: %s with %d modules",
                self.modules.modules.keys(),
                len(self.modules.modules)
            )
        self._initialize_test_state()

    def _safe_resolve_param(self, param: str) -> str:
        try:
            return self.resolve_param(param)
        except (ValueError, OpticsError):
            return param

    def _note_failure(self, reason: str, status: EventStatus = EventStatus.FAIL) -> None:
        """Record the latest failure reason and log it so failures aren't silent."""
        self._last_failure_reason = reason
        self._last_failure_status = status
        execution_logger.error(reason)

    def _suggest_keyword(self, name: str) -> str:
        """Return a 'Did you mean ...?' hint for an unknown keyword, else empty."""
        func_name = "_".join(name.split()).lower()
        matches = difflib.get_close_matches(
            func_name, list(self.keyword_map), n=1, cutoff=0.6)
        if not matches:
            return ""
        pretty = matches[0].replace("_", " ").title()
        return f" Did you mean '{pretty}'? (run `optics list` to see all keywords)"

    def _unknown_step_reason(self, name: str) -> str:
        """Reason for a step that resolves to neither a module nor a keyword."""
        reason = f"Unknown keyword or module: '{name}'"
        hint = self._suggest_keyword(name)
        return f"{reason}.{hint}" if hint else reason

    def _initialize_test_state(self) -> None:
        def _init_keywords(module_node):
            keywords = []
            current_keyword = module_node.keywords_head
            while current_keyword:
                resolved_params = [
                    self._safe_resolve_param(param) for param in current_keyword.params
                ]
                resolved_name = mask_secrets(
                    f"{current_keyword.name} ({', '.join(str(p) for p in resolved_params)})"
                    if resolved_params
                    else current_keyword.name
                )
                keyword_result = KeywordResult(
                    id=current_keyword.id,
                    name=current_keyword.name,
                    resolved_name=resolved_name,
                    elapsed="0.00s",
                    status="NOT_RUN",
                    reason="",
                )
                keywords.append(keyword_result)
                current_keyword = current_keyword.next
            return keywords

        def _init_modules(test_case_node):
            modules = []
            current_module = test_case_node.modules_head
            while current_module:
                module_result = ModuleResult(
                    name=current_module.name,
                    elapsed="0.00s",
                    status="NOT_RUN",
                    keywords=_init_keywords(current_module),
                )
                if not isinstance(module_result.keywords, list):
                    module_result.keywords = []
                modules.append(module_result)
                current_module = current_module.next
            return modules

        test_state = {}
        current_test = self.test_cases
        while current_test:
            test_result = TestCaseResult(
                id=str(uuid.uuid4()),
                name=current_test.name,
                elapsed="0.00s",
                status="NOT_RUN",
                modules=_init_modules(current_test),
            )
            if not isinstance(test_result.modules, list):
                test_result.modules = []
            test_state[current_test.name] = test_result
            current_test = current_test.next
        self.result_printer.test_state = test_state
        internal_logger.debug(
            "Initialized test_state: %s with %d modules",
            test_state.keys(),
            sum(len(m.modules) for m in test_state.values())
        )

    def _extra(
        self, test_case: str, module: str = "N/A", keyword: str = "N/A"
    ) -> Dict[str, str]:
        return {
            "test_case": test_case,
            "test_module": module,
            "keyword": keyword,
            "session_id": self.session_id,
        }

    def resolve_param(self, param: str) -> str:
        var_name = utils.whole_var_name(param)
        if var_name is None:
            return param
        resolved_value = self.elements.get_first(var_name)
        if resolved_value is None:
            raise OpticsError(Code.E0201, f"Element not found: {var_name}")
        internal_logger.debug(f"Resolved '{param}' to '{resolved_value}'")
        return resolved_value

    def _init_test_case(self, test_case: str) -> TestCaseResult:
        test_context.current_test_case.set(test_case)
        return self.result_printer.test_state.get(
            test_case,
            TestCaseResult(
                id=str(uuid.uuid4()), name=test_case, elapsed="0.00s", status="NOT_RUN"
            ),
        )

    def _find_result(
        self,
        test_case_name: str,
        module_name: Optional[str] = None,
        keyword_id: Optional[str] = None,
    ) -> Union[TestCaseResult, ModuleResult, KeywordResult]:
        test_result = self.result_printer.test_state.get(test_case_name)
        if not test_result:
            raise ValueError(f"Test case {test_case_name} not found in test_state")
        if module_name is None:
            return test_result
        for module_result in test_result.modules:
            if module_result.name == module_name:
                if keyword_id is None:
                    return module_result
                for keyword_result in module_result.keywords:
                    if keyword_result.id == keyword_id:
                        internal_logger.debug(
                            f"Found keyword: {keyword_result.name} (id: {keyword_id})"
                        )
                        return keyword_result
                raise ValueError(
                    f"Keyword id {keyword_id} not found in module {module_name}"
                )
        raise ValueError(f"Module {module_name} not found in test_state")

    def _step_resolves(self, module_name: str) -> bool:
        definition = (
            self.modules.get_module_definition(module_name)
            if self.modules is not None
            else None
        )
        if definition:
            return True
        func_name = "_".join(module_name.split()).lower()
        return func_name in self.keyword_map

    def _update_status(
        self,
        result: Union[TestCaseResult, ModuleResult, KeywordResult],
        status: str,
        elapsed: Optional[float] = None,
        test_case_name: str = "",
    ) -> None:
        result.status = status
        if elapsed is not None:
            result.elapsed = f"{elapsed:.2f}s"
        if test_case_name:
            internal_logger.debug(
                f"Updating status for {result.__class__.__name__}: {result.name} -> {status}"
            )
            test_case_result = self.result_printer.test_state.get(test_case_name)
            if test_case_result:
                self.result_printer.print_tree_log(test_case_result)

    async def _send_event(
        self,
        entity_type: str,
        node: Node,
        status: EventStatus,
        reason: Optional[str] = None,
        parent_id: Optional[str] = None,
        args: Optional[List[Any]] = None,
        start_time: Optional[float] = None,
        end_time: Optional[float] = None,
        elapsed: Optional[float] = None,
        logs: Optional[List[logging.LogRecord]] = None,
        stored: dict[str, str] | None = None,
    ) -> None:
        log_messages = None
        if logs is not None:
            log_messages = [
                record.getMessage()
                if isinstance(record, logging.LogRecord)
                else str(record)
                for record in logs
            ]
        event = Event(
            entity_type=entity_type,
            entity_id=node.id,
            name=node.name,
            status=status,
            message=reason or "",
            parent_id=parent_id,
            extra={"session_id": self.session_id, **({"stored": json.dumps(stored)} if stored else {})},
            args=args,
            start_time=start_time,
            end_time=end_time,
            elapsed=elapsed,
            logs=log_messages,
        )
        await queue_event(event, self.event_manager)

    async def _process_commands(
        self, node: KeywordNode, parent: Optional[ModuleNode]
    ) -> bool:
        retry = False
        command = await self.event_manager.get_command()
        if command:
            if command.command == CommandType.RETRY and command.entity_id == node.id:
                node.state = State.RETRYING
                node.attempt_count += 1
                retry = True
            elif (
                command.command == CommandType.ADD
                and parent
                and command.parent_id == parent.id
            ):
                new_node = KeywordNode(
                    name=command.params[0] if command.params else "NewKeyword",
                    params=command.params[1:] if command.params else [],
                )
                new_node.next = node.next
                node.next = new_node
        return retry

    async def _execute_keyword(
        self,
        keyword_node: KeywordNode,
        module_node: ModuleNode,
        test_case_result: TestCaseResult,
        extra: Dict[str, str],
    ) -> bool:
        capture_handler = LogCaptureBuffer()
        execution_logger.addHandler(capture_handler)
        should_retry = False
        try:
            keyword_result = self._find_result(
                test_case_result.name, module_node.name, keyword_node.id
            )
            internal_logger.debug(
                "Executing keyword: %s (id: %s)", keyword_node.name, keyword_node.id
            )
            start_time = time.time()

            keyword_node.state = State.RUNNING
            await self._send_event(
                "keyword",
                keyword_node,
                EventStatus.RUNNING,
                parent_id=module_node.id,
                start_time=start_time,
            )
            self._update_status(
                keyword_result, "RUNNING", time.time() - start_time, test_case_result.name
            )

            func_name = "_".join(keyword_node.name.split()).lower()
            method = self.keyword_map.get(func_name)
            if not method:
                await self._handle_keyword_not_found(keyword_node, module_node, keyword_result, start_time, test_case_result)
                return False

            params, store_as = utils.split_store_as(keyword_node.params)
            param_candidates = await self._build_param_candidates(keyword_node, params, module_node, keyword_result, start_time, test_case_result, capture_handler, utils.raw_param_indices(method))
            if param_candidates is None:
                return False

            result = await self._try_execute_with_fallback(
                method, param_candidates, keyword_node, module_node, keyword_result, start_time, test_case_result, capture_handler,
                store_as=store_as,
            )
            if result is not None:
                return result

            await asyncio.sleep(self.config.halt_duration)
            should_retry = await self._process_commands(keyword_node, module_node)
        finally:
            execution_logger.removeHandler(capture_handler)

        if should_retry:
            return await self._execute_keyword(
                keyword_node, module_node, test_case_result, extra
            )
        return False

    async def _handle_keyword_not_found(self, keyword_node, module_node, keyword_result, start_time, test_case_result):
        keyword_node.state = State.COMPLETED_FAILED
        reason = f"Keyword not found: {keyword_node.name}.{self._suggest_keyword(keyword_node.name)}"
        self._note_failure(reason)
        keyword_result.reason = reason
        await self._send_event(
            "keyword",
            keyword_node,
            EventStatus.FAIL,
            reason=reason,
            parent_id=module_node.id,
            start_time=start_time,
            end_time=time.time(),
            elapsed=time.time() - start_time,
        )
        self._update_status(keyword_result, "FAIL", time.time() - start_time, test_case_result.name)

    async def _build_param_candidates(self, keyword_node, params, module_node, keyword_result, start_time, test_case_result, capture_handler, raw=frozenset()):
        param_candidates = []
        for i, param in enumerate(params):
            var_name = None if i in raw else utils.whole_var_name(param)
            if var_name is not None:
                values = self.elements.get_element(var_name)
                if not values:
                    # Await error handler to ensure error is processed before returning
                    await self._handle_element_not_found(
                        keyword_node, module_node, keyword_result, start_time, test_case_result, var_name, capture_handler
                    )
                    return None
                param_candidates.append(values)
            else:
                param_candidates.append([param])
        return param_candidates

    async def _handle_element_not_found(self, keyword_node, module_node, keyword_result, start_time, test_case_result, var_name, capture_handler):
        keyword_node.state = State.COMPLETED_FAILED
        reason = f"Element not found: {var_name}"
        self._note_failure(reason)
        keyword_result.reason = reason
        await self._send_event(
            "keyword",
            keyword_node,
            EventStatus.FAIL,
            reason,
            parent_id=module_node.id,
            start_time=start_time,
            end_time=time.time(),
            elapsed=time.time() - start_time,
            logs=capture_handler.records,
        )
        self._update_status(keyword_result, "FAIL", time.time() - start_time, test_case_result.name)

    async def _try_execute_with_fallback(
        self, method, param_candidates, keyword_node, module_node, keyword_result, start_time, test_case_result, capture_handler,
        store_as=None,
    ):
        # Try all combinations of param candidates (for fallback)
        MAX_ATTEMPTS = 20
        attempts = 0
        last_error: OpticsError | None = None
        for candidate_args in product(*param_candidates):
            attempts += 1
            if attempts > MAX_ATTEMPTS:
                break
            try:
                resolved_positional_params, resolved_kw_params = self._resolve_candidate_params(method, candidate_args)
                _, stored = utils.call_and_store(self.elements, method, resolved_positional_params, resolved_kw_params, store_as)
                keyword_result.stored = stored
                keyword_node.state = State.COMPLETED_PASSED
                await self._send_event(
                    "keyword",
                    keyword_node,
                    EventStatus.PASS,
                    parent_id=module_node.id,
                    start_time=start_time,
                    end_time=time.time(),
                    elapsed=time.time() - start_time,
                    logs=capture_handler.records,
                    stored=stored,
                )
                self._update_status(keyword_result, "PASS", time.time() - start_time, test_case_result.name)
                return True
            except OpticsError as oe:
                if oe.code.value.startswith("E02") or oe.code == Code.X0201:
                    internal_logger.debug(f"Keyword fallback: tried {candidate_args}, error: {oe}")
                    last_error = oe
                    continue
                else:
                    await self._handle_keyword_exception(keyword_node, module_node, keyword_result, start_time, test_case_result, oe, capture_handler)
                    return False
            except Exception as e:
                await self._handle_keyword_exception(keyword_node, module_node, keyword_result, start_time, test_case_result, e, capture_handler)
                return False
        await self._handle_fallback_exhausted(
            keyword_node, module_node, keyword_result, start_time, test_case_result, capture_handler, last_error
        )
        return None

    async def _handle_keyword_exception(self, keyword_node, module_node, keyword_result, start_time, test_case_result, exc, capture_handler):
        keyword_node.state = State.COMPLETED_FAILED
        reason = f"Keyword '{keyword_node.name}' failed: {exc}"
        status = EventStatus.ERROR if is_dead_session_error(exc) else EventStatus.FAIL
        self._note_failure(reason, status)
        keyword_result.reason = reason
        await self._send_event(
            "keyword",
            keyword_node,
            status,
            reason,
            parent_id=module_node.id,
            start_time=start_time,
            end_time=time.time(),
            elapsed=time.time() - start_time,
            logs=capture_handler.records,
        )
        self._update_status(keyword_result, "FAIL", time.time() - start_time, test_case_result.name)
        self._save_failure_elements(test_case_result.name, keyword_result.resolved_name)

    async def _handle_fallback_exhausted(
        self, keyword_node, module_node, keyword_result, start_time, test_case_result, capture_handler, last_error
    ):
        keyword_node.state = State.COMPLETED_FAILED
        reason = f"Keyword '{keyword_node.name}' failed after fallback attempts"
        if last_error is not None:
            reason += f"; last error: {last_error}"
        self._note_failure(reason)
        keyword_result.reason = reason
        await self._send_event(
            "keyword",
            keyword_node,
            EventStatus.FAIL,
            reason,
            parent_id=module_node.id,
            start_time=start_time,
            end_time=time.time(),
            elapsed=time.time() - start_time,
            logs=capture_handler.records,
        )
        self._update_status(keyword_result, "FAIL", time.time() - start_time, test_case_result.name)
        self._save_failure_elements(test_case_result.name, keyword_result.resolved_name)

    def _save_failure_elements(self, test_case: str, step: str) -> None:
        """Add the screen's compact element list to failed_steps_elements.json, to fix a failed step's locators."""
        get_elements = self.keyword_map.get("get_interactive_elements")
        if get_elements is None:
            return
        output_dir = self._capture_dir()
        if output_dir is None:
            return
        try:
            self._failed_steps_elements.append({"test_case": test_case, "step": step, "elements": get_elements(compact=True)})
            text = json.dumps(self._failed_steps_elements, indent=2, ensure_ascii=False)
            with open(os.path.join(output_dir, "failed_steps_elements.json"), "w", encoding="utf-8") as f:
                f.write(mask_secrets(text))
        except Exception as e:
            internal_logger.warning("Element list for the failed step skipped: %s", e)

    def _capture_dir(self) -> Optional[str]:
        """Where a failure's captures go, or None when captures are off or the driver is closed."""
        output_dir = self.config.execution_output_path
        if not output_dir or not self.config.save_captures or not self._end_of_run_driver_open():
            return None
        return output_dir

    def _end_of_run_driver_open(self) -> bool:
        """Best-effort check that the driver session is still alive.

        Drivers expose their live handle as ``page`` (Playwright) or ``driver``
        (Appium/Selenium); a present-but-None handle means the run's own teardown
        already terminated it, so capture attempts would only raise. Handles must
        be read off the wrapper's ``active_instance`` -- ``InstanceFallback``
        routes attribute access through ``__getattr__``, which hides the real
        value behind a generated callable.
        """
        driver_fallback = getattr(self.session, "driver", None)
        if driver_fallback is None:
            return False
        active_driver = getattr(driver_fallback, "active_instance", None)
        driver = active_driver if active_driver is not None else driver_fallback
        return all(
            getattr(driver, attr) is not None
            for attr in ("page", "driver")
            if hasattr(driver, attr)
        )

    def _capture_end_of_run_artifacts(self) -> None:
        if not self._end_of_run_driver_open():
            internal_logger.debug(
                "End-of-run artifact capture skipped: driver session unavailable."
            )
            return
        try:
            output_dir = self.session.config.execution_output_path
            strategy_manager = self._strategy_manager()
            self._save_end_of_run_screenshot(strategy_manager, output_dir)
            page_source, timestamp = self._save_end_of_run_pagesource(strategy_manager, output_dir)
            self._run_end_of_run_detection(page_source, timestamp, output_dir)
        except Exception as e:
            internal_logger.warning("End-of-run artifact capture failed: %s", e)

    def _strategy_manager(self) -> StrategyManager:
        return StrategyManager(
            self.session.optics.get_element_source(),
            self.session.optics.get_text_detection(),
            self.session.optics.get_image_detection(),
        )

    def _capture_failure_artifacts(self, test_case: str) -> None:
        """Save the screenshot and page source a failed test case ended on, both named after it."""
        output_dir = self._capture_dir()
        if output_dir is None:
            return
        try:
            strategy_manager = self._strategy_manager()
            label = f"failure_{test_case}"
            time_stamp = utils.capture_time_stamp()
            utils.save_screenshot(strategy_manager.capture_screenshot(), label, output_dir, time_stamp)
            page_source, _ = strategy_manager.capture_pagesource()
            utils.save_page_source_file(mask_secrets(page_source), label, output_dir, time_stamp)
        except Exception as e:
            internal_logger.warning("Failure capture for '%s' skipped: %s", test_case, e)

    def _save_end_of_run_screenshot(self, strategy_manager: StrategyManager, output_dir: str) -> None:
        try:
            screenshot = strategy_manager.capture_screenshot()
            utils.save_screenshot(screenshot, "end_of_run", output_dir)
            internal_logger.debug("End-of-run screenshot saved.")
        except Exception as e:
            internal_logger.warning("End-of-run screenshot skipped: %s", e)

    def _save_end_of_run_pagesource(
        self, strategy_manager: StrategyManager, output_dir: str
    ) -> tuple[Optional[str], Optional[str]]:
        try:
            page_source, timestamp = strategy_manager.capture_pagesource()
            if utils.is_html_source(page_source):
                utils.save_page_source_html(page_source, timestamp, output_dir)
            else:
                utils.save_page_source(page_source, timestamp, output_dir)
            internal_logger.debug("End-of-run page source saved.")
            return page_source, timestamp
        except Exception as e:
            internal_logger.warning("End-of-run page source skipped: %s", e)
            return None, None

    def _run_end_of_run_detection(
        self, page_source: Optional[str], timestamp: Optional[str], output_dir: str
    ) -> None:
        try:
            error_defs = getattr(self.session, "error_definitions", None)
            if not (error_defs and error_defs.get_all() and page_source):
                return
            searchable = extract_visible_text(page_source)
            matched = detect_errors_in_text(searchable, error_defs.get_all(), context_label="end_of_run")
            if not matched:
                internal_logger.debug("No user-defined errors detected in end-of-run page source.")
                return
            for m in matched:
                execution_logger.warning(
                    "ON-SCREEN ERROR DETECTED — code: %s | matched_on: %s | match_string: '%s' | severity: %s | %s",
                    m["error_code"], m["matched_on"], m.get("match_string", ""),
                    m.get("severity", ""), m.get("description", ""),
                )
            out_path = os.path.join(output_dir, f"detected_errors_{self.session_id}.json")
            with open(out_path, "w", encoding="utf-8") as f:
                json.dump({"timestamp": timestamp, "detected": matched}, f, indent=2)
            internal_logger.debug("Detected errors written to %s", out_path)
            detection = TestCaseResult(id=str(uuid.uuid4()), name=ON_SCREEN_ERROR_CASE, elapsed="0.00s", status="FAIL")
            self.result_printer.test_state[ON_SCREEN_ERROR_CASE] = detection
            self.result_printer.print_tree_log(detection)
            handler = get_junit_handler_registry().get_handler(self.session_id)
            if handler:
                handler.add_detected_errors(self.session_id, matched)
        except Exception as e:
            internal_logger.warning("Error detection scan failed: %s", e)

    async def _process_module(
        self,
        module_node: ModuleNode,
        test_case_result: TestCaseResult,
        extra: Dict[str, str],
    ) -> bool:
        module_result = self._find_result(test_case_result.name, module_node.name)
        start_time = time.time()
        module_node.state = State.RUNNING
        await self._send_event(
            "module",
            module_node,
            EventStatus.RUNNING,
            parent_id=test_case_result.id,
            start_time=start_time,
        )
        self._update_status(
            module_result, "RUNNING", time.time() - start_time, test_case_result.name
        )

        if not self._step_resolves(module_node.name):
            module_node.state = State.COMPLETED_FAILED
            reason = self._unknown_step_reason(module_node.name)
            self._note_failure(reason)
            module_result.reason = reason
            await self._send_event(
                "module",
                module_node,
                EventStatus.FAIL,
                reason=reason,
                parent_id=test_case_result.id,
                start_time=start_time,
                end_time=time.time(),
                elapsed=time.time() - start_time,
            )
            self._update_status(
                module_result, "FAIL", time.time() - start_time, test_case_result.name
            )
            return False

        current = module_node.keywords_head
        while current:
            extra["keyword"] = current.name
            if not await self._execute_keyword(
                current, module_node, test_case_result, extra
            ):
                module_node.state = State.COMPLETED_FAILED
                await self._send_event(
                    "module",
                    module_node,
                    self._last_failure_status,
                    reason=self._last_failure_reason,
                    parent_id=test_case_result.id,
                    start_time=start_time,
                    end_time=time.time(),
                    elapsed=time.time() - start_time,
                )
                self._update_status(
                    module_result,
                    "FAIL",
                    time.time() - start_time,
                    test_case_result.name,
                )
                return False
            current = current.next

        module_node.state = State.COMPLETED_PASSED
        await self._send_event(
            "module",
            module_node,
            EventStatus.PASS,
            parent_id=test_case_result.id,
            start_time=start_time,
            end_time=time.time(),
            elapsed=time.time() - start_time,
        )
        self._update_status(
            module_result, "PASS", time.time() - start_time, test_case_result.name
        )
        return True

    async def _process_test_case(
        self, test_case: str, dry_run: bool = False
    ) -> TestCaseResult:
        start_time = time.time()
        self._last_failure_reason = None
        use_secrets(self.elements.secrets)
        testcase_id = str(uuid.uuid4())
        extra = self._extra(test_case)
        test_case_result = self._init_test_case(test_case)
        current = self.test_cases
        while current and current.name != test_case:
            current = current.next
        if not current:
            self._update_status(
                test_case_result,
                "FAIL",
                time.time() - start_time,
                test_case_result.name,
            )
            await self._send_event(
                "test_case",
                TestCaseNode(name=test_case, id=testcase_id),
                EventStatus.FAIL,
                start_time=start_time,
                end_time=time.time(),
                elapsed=time.time() - start_time,
            )
            return test_case_result

        current.id = testcase_id
        test_case_result = TestCaseResult(
            id=testcase_id,
            name=test_case_result.name,
            elapsed=test_case_result.elapsed,
            status=test_case_result.status,
            modules=test_case_result.modules,
        )
        self.result_printer.test_state[test_case] = test_case_result
        current.state = State.RUNNING
        await self._send_event(
            "test_case", current, EventStatus.RUNNING, start_time=start_time
        )
        self._update_status(
            test_case_result, "RUNNING", time.time() - start_time, test_case_result.name
        )

        module_current = current.modules_head
        while module_current:
            if dry_run:
                if not await self._dry_run_module(
                    module_current, test_case_result, testcase_id
                ):
                    current.state = State.COMPLETED_FAILED
                    await self._send_event(
                        "test_case",
                        current,
                        EventStatus.FAIL,
                        reason=self._last_failure_reason,
                        start_time=start_time,
                        end_time=time.time(),
                        elapsed=time.time() - start_time,
                    )
                    self._update_status(
                        test_case_result,
                        "FAIL",
                        time.time() - start_time,
                        test_case_result.name,
                    )
                    return test_case_result
            else:
                if not await self._process_module(
                    module_current, test_case_result, extra
                ):
                    current.state = State.COMPLETED_FAILED
                    self._capture_failure_artifacts(current.name)
                    await self._send_event(
                        "test_case",
                        current,
                        self._last_failure_status,
                        reason=self._last_failure_reason,
                        start_time=start_time,
                        end_time=time.time(),
                        elapsed=time.time() - start_time,
                    )
                    self._update_status(
                        test_case_result,
                        "FAIL",
                        time.time() - start_time,
                        test_case_result.name,
                    )
                    return test_case_result
            module_current = module_current.next

        current.state = State.COMPLETED_PASSED
        await self._send_event(
            "test_case",
            current,
            EventStatus.PASS,
            start_time=start_time,
            end_time=time.time(),
            elapsed=time.time() - start_time,
        )
        self._update_status(
            test_case_result, "PASS", time.time() - start_time, test_case_result.name
        )
        return test_case_result

    async def _dry_run_module(
        self,
        module_node: ModuleNode,
        test_case_result: TestCaseResult,
        testcase_id: str,
    ) -> bool:
        module_result = self._find_result(test_case_result.name, module_node.name)
        start_time = time.time()
        module_node.state = State.RUNNING
        await self._send_event(
            "module",
            module_node,
            EventStatus.RUNNING,
            parent_id=testcase_id,
            start_time=start_time,
        )
        self._update_status(module_result, "RUNNING", 0.0, test_case_result.name)

        if not self._step_resolves(module_node.name):
            module_node.state = State.COMPLETED_FAILED
            reason = self._unknown_step_reason(module_node.name)
            self._note_failure(reason)
            module_result.reason = reason
            await self._send_event(
                "module",
                module_node,
                EventStatus.FAIL,
                reason=reason,
                parent_id=testcase_id,
                start_time=start_time,
                end_time=time.time(),
                elapsed=time.time() - start_time,
            )
            self._update_status(module_result, "FAIL", 0.0, test_case_result.name)
            return False

        keyword_current = module_node.keywords_head
        while keyword_current:
            keyword_result = self._find_result(
                test_case_result.name, module_node.name, keyword_current.id
            )
            keyword_current.state = State.RUNNING
            await self._send_event(
                "keyword",
                keyword_current,
                EventStatus.RUNNING,
                parent_id=module_node.id,
                start_time=start_time,
            )
            self._update_status(keyword_result, "RUNNING", 0.0, test_case_result.name)

            try:
                params, store_as = utils.split_store_as(keyword_current.params)
                method = self.keyword_map.get("_".join(keyword_current.name.split()).lower())
                params = utils.substitute_inline(method, params, self.elements)
                raw = utils.raw_param_indices(method)
                resolved_params = [param if i in raw else self.resolve_param(param) for i, param in enumerate(params)]
                # Nothing runs here, so define the names a run would set.
                if store_as is not None:
                    utils.require_store_name(store_as)
                    self.elements.store(store_as, f"<{store_as}>")
                if getattr(method, "_defines_variable", False) and params:
                    defined = utils.whole_var_name(str(params[0])) or str(params[0]).strip()
                    self.elements.remove_element(defined)
                    self.elements.add_element(defined, f"<{defined}>")
                if isinstance(keyword_result, KeywordResult):
                    keyword_result.resolved_name = mask_secrets(
                        f"{keyword_current.name} ({', '.join(resolved_params)})"
                        if resolved_params
                        else keyword_current.name
                    )
                func_name = "_".join(keyword_current.name.split()).lower()
                if func_name not in self.keyword_map:
                    raise ValueError(
                        f"Keyword not found: {keyword_current.name}."
                        f"{self._suggest_keyword(keyword_current.name)}")
            except (ValueError, OpticsError) as e:
                reason = getattr(e, "message", None) or str(e)
                self._note_failure(reason)
                keyword_result.reason = reason
                keyword_current.state = State.COMPLETED_FAILED
                await self._send_event(
                    "keyword",
                    keyword_current,
                    EventStatus.FAIL,
                    reason,
                    parent_id=module_node.id,
                    start_time=start_time,
                    end_time=time.time(),
                    elapsed=time.time() - start_time,
                )
                self._update_status(keyword_result, "FAIL", 0.0, test_case_result.name)
                self._update_status(module_result, "FAIL", 0.0, test_case_result.name)
                return False

            keyword_current.state = State.COMPLETED_PASSED
            await self._send_event(
                "keyword",
                keyword_current,
                EventStatus.PASS,
                parent_id=module_node.id,
                start_time=start_time,
                end_time=time.time(),
                elapsed=time.time() - start_time,
            )
            self._update_status(keyword_result, "PASS", 0.0, test_case_result.name)
            keyword_current = keyword_current.next

        module_node.state = State.COMPLETED_PASSED
        await self._send_event(
            "module", module_node, EventStatus.PASS, parent_id=testcase_id
        )
        self._update_status(module_result, "PASS", 0.0, test_case_result.name)
        return True

    async def execute_test_case(self, test_case: str) -> TestCaseResult:
        return await self._process_test_case(test_case, dry_run=False)

    async def dry_run_test_case(self, test_case: str) -> TestCaseResult:
        return await self._process_test_case(test_case, dry_run=True)

    async def run_all(self) -> None:
        self._start_run()
        current = self.test_cases
        captured = False
        while current:
            # The suite teardown may close the app, so the final screen is read before it.
            if current.suite_teardown:
                self._capture_end_of_run_artifacts()
                captured = True
            await self.execute_test_case(current.name)
            current = current.next
        if not captured:
            self._capture_end_of_run_artifacts()
        self.result_printer.stop_live()

    def _start_run(self) -> None:
        handler = get_junit_handler_registry().get_handler(self.session_id)
        if handler is not None:
            handler.plan_run(self.session_id, run_plan(self.test_cases))
        self.result_printer.start_run(len(self.result_printer.test_state))
        self.result_printer.start_live()

    async def dry_run_all(self) -> None:
        self._start_run()
        current = self.test_cases
        while current:
            await self.dry_run_test_case(current.name)
            current = current.next
        self.result_printer.stop_live()


class PytestRunner(Runner):
    instance = None

    def __init__(
        self,
        session: Session,
        keyword_map: Dict,
        event_manager,
    ):
        self.session = session
        self.test_cases = self.session.test_cases if self.session and hasattr(self.session, "test_cases") else None
        self.modules = self.session.modules if self.session and hasattr(self.session, "modules") else {}
        self.elements = (
            self.session.elements if self.session and isinstance(self.session.elements, ElementData)
            else ElementData()
        )
        self.apis = self.session.apis if self.session and hasattr(self.session, "apis") and self.session.apis is not None else ApiData()
        self.keyword_map = keyword_map
        self.result_printer = NullResultPrinter()
        self.config_handler: ConfigHandler = self.session.config_handler
        self.config: Config = self.session.config
        self.event_manager = event_manager
        PytestRunner.instance = self

    def resolve_param(self, param: str) -> str:
        var_name = utils.whole_var_name(param)
        if var_name is None:
            return param
        value = self.elements.get_first(var_name)
        if value is None:
            pytest.fail(f"Variable '{var_name}' not found")
        return value

    def _execute_keyword(
        self,
        keyword: str,
        params: List[str],
        dry_run: bool = False,
        module_id: str = "unknown",
        testcase_id: str = "unknown",
    ) -> bool:
        keyword_id = str(uuid.uuid4())
        func_name = "_".join(keyword.split()).lower()

        if dry_run:
            return self._execute_keyword_dry_run(keyword, func_name, keyword_id, module_id)

        self._queue_event_running(keyword, keyword_id, module_id)
        method = self.keyword_map.get(func_name)
        if not method:
            self._queue_event_fail(keyword, keyword_id, module_id, f"Keyword not found: {keyword}")
            pytest.fail(f"Keyword not found: {keyword}")

        params, store_as = utils.split_store_as(params)
        param_candidates = self._build_param_candidates_pytest(params, keyword_id, keyword, module_id, utils.raw_param_indices(method))
        if param_candidates is None:
            return False

        return self._try_execute_with_fallback_pytest(
            method, param_candidates, keyword, keyword_id, module_id, store_as=store_as
        )

    def _execute_keyword_dry_run(self, keyword, func_name, keyword_id, module_id):
        if not self.keyword_map.get(func_name):
            queue_event_sync(
                Event(
                    entity_type="keyword",
                    entity_id=keyword_id,
                    name=keyword,
                    status=EventStatus.FAIL,
                    message=f"Keyword not found: {keyword}",
                    parent_id=module_id,
                    extra={"session_id": self.session.session_id},
                ),
                self.event_manager
            )
            pytest.fail(f"Keyword not found: {keyword}")
        queue_event_sync(
            Event(
                entity_type="keyword",
                entity_id=keyword_id,
                name=keyword,
                status=EventStatus.PASS,
                message="Keyword validated",
                parent_id=module_id,
                extra={"session_id": self.session.session_id},
            ),
            self.event_manager
        )
        return True

    def _queue_event_running(self, keyword, keyword_id, module_id):
        queue_event_sync(
            Event(
                entity_type="keyword",
                entity_id=keyword_id,
                name=keyword,
                status=EventStatus.RUNNING,
                parent_id=module_id,
                extra={"session_id": self.session.session_id},
            ),
            self.event_manager
        )

    def _queue_event_fail(self, keyword, keyword_id, module_id, message):
        queue_event_sync(
            Event(
                entity_type="keyword",
                entity_id=keyword_id,
                name=keyword,
                status=EventStatus.FAIL,
                message=message,
                parent_id=module_id,
                extra={"session_id": self.session.session_id},
            ),
            self.event_manager
        )

    def _build_param_candidates_pytest(self, params, keyword_id, keyword, module_id, raw=frozenset()):
        param_candidates = []
        for i, param in enumerate(params):
            var_name = None if i in raw else utils.whole_var_name(param)
            if var_name is not None:
                values = self.elements.get_element(var_name)
                if not values:
                    queue_event_sync(
                        Event(
                            entity_type="keyword",
                            entity_id=keyword_id,
                            name=keyword,
                            status=EventStatus.FAIL,
                            message=f"Element not found: {var_name}",
                            parent_id=module_id,
                            extra={"session_id": self.session.session_id},
                        ),
                        self.event_manager
                    )
                    pytest.fail(f"Element not found: {var_name}")
                    return None
                param_candidates.append(values)
            else:
                param_candidates.append([param])
        return param_candidates

    def _try_execute_with_fallback_pytest(self, method, param_candidates, keyword, keyword_id, module_id, store_as=None):
        MAX_ATTEMPTS = 20
        attempts = 0
        last_exc = None

        for candidate_args in product(*param_candidates):
            attempts += 1
            if attempts > MAX_ATTEMPTS:
                break
            try:
                resolved_positional_params, resolved_kw_params = self._resolve_candidate_params(method, candidate_args)
                _, stored = utils.call_and_store(self.elements, method, resolved_positional_params, resolved_kw_params, store_as)
                self._queue_keyword_pass_event(keyword, keyword_id, module_id, stored)
                return True
            except OpticsError as oe:
                if oe.code.value.startswith("E02") or oe.code == Code.X0201:
                    last_exc = oe
                    continue
                else:
                    self._handle_keyword_fail(keyword, keyword_id, module_id, f"Keyword '{keyword}' failed: {oe}")
                    return False
            except Exception as e:
                self._handle_keyword_fail(keyword, keyword_id, module_id, f"Keyword '{keyword}' failed: {e}")
                return False

        self._handle_keyword_fail(
            keyword,
            keyword_id,
            module_id,
            f"Keyword '{keyword}' failed after {attempts} attempts; last error: {last_exc}"
        )
        return False

    def _queue_keyword_pass_event(self, keyword, keyword_id, module_id, stored=None):
        queue_event_sync(
            Event(
                entity_type="keyword",
                entity_id=keyword_id,
                name=keyword,
                status=EventStatus.PASS,
                parent_id=module_id,
                extra={"session_id": self.session.session_id, **({"stored": json.dumps(stored)} if stored else {})},
            ),
            self.event_manager
        )

    def _handle_keyword_fail(self, keyword, keyword_id, module_id, msg):
        self._queue_event_fail(keyword, keyword_id, module_id, msg)
        pytest.fail(msg)

    def _process_module(
        self, module_name: str, dry_run: bool = False, testcase_id: str = "unknown"
    ) -> bool:
        if not isinstance(self.modules, ModuleData):
            raise TypeError("self.modules must be a ModuleData instance.")

        module_id = str(uuid.uuid4())
        queue_event_sync(
            Event(
                entity_type="module",
                entity_id=module_id,
                name=module_name,
                status=EventStatus.RUNNING,
                parent_id=testcase_id,
                extra={"session_id": self.session.session_id},
            ),
            self.event_manager
        )

        module_steps = self.modules.modules.get(module_name)
        if module_steps is None:
            queue_event_sync(
                Event(
                    entity_type="module",
                    entity_id=module_id,
                    name=module_name,
                    status=EventStatus.FAIL,
                    message=f"Module '{module_name}' not found",
                    parent_id=testcase_id,
                    extra={"session_id": self.session.session_id},
                ),
                self.event_manager
            )
            pytest.fail(f"Module '{module_name}' not found")

        for step in module_steps:
            if isinstance(step, tuple) and len(step) == 2:
                keyword, params = step
            else:
                continue
            if not self._execute_keyword(
                keyword,
                params,
                dry_run=dry_run,
                module_id=module_id,
                testcase_id=testcase_id,
            ):
                queue_event_sync(
                    Event(
                        entity_type="module",
                        entity_id=module_id,
                        name=module_name,
                        status=EventStatus.FAIL,
                        parent_id=testcase_id,
                        extra={"session_id": self.session.session_id},
                    ),
                    self.event_manager
                )
                return False
        queue_event_sync(
            Event(
                entity_type="module",
                entity_id=module_id,
                name=module_name,
                status=EventStatus.PASS,
                parent_id=testcase_id,
                extra={"session_id": self.session.session_id},
            ),
            self.event_manager
        )
        return True

    def execute_test_case_sync(
        self, test_case: str, dry_run: bool = False
    ) -> TestCaseResult:
        start_time = time.time()
        use_secrets(self.elements.secrets)
        testcase_id = str(uuid.uuid4())
        result = TestCaseResult(
            id=testcase_id, name=test_case, elapsed="0.00s", status="NOT_RUN"
        )
        queue_event_sync(
            Event(
                entity_type="test_case",
                entity_id=testcase_id,
                name=test_case,
                status=EventStatus.RUNNING,
                extra={"session_id": self.session.session_id},
            ),
            self.event_manager
        )
        current = self.test_cases
        while current and current.name != test_case:
            current = current.next
        if not current:
            queue_event_sync(
                Event(
                    entity_type="test_case",
                    entity_id=testcase_id,
                    name=test_case,
                    status=EventStatus.FAIL,
                    message=f"Test case '{test_case}' not found",
                    extra={"session_id": self.session.session_id},
                ),
                self.event_manager
            )
            result.status = "FAIL"
            result.elapsed = f"{time.time() - start_time:.2f}s"
            return result

        result.status = "RUNNING"
        module_current = current.modules_head
        while module_current:
            if not self._process_module(
                module_name=module_current.name,
                dry_run=dry_run,
                testcase_id=testcase_id,
            ):
                queue_event_sync(
                    Event(
                        entity_type="test_case",
                        entity_id=testcase_id,
                        name=test_case,
                        status=EventStatus.FAIL,
                        extra={"session_id": self.session.session_id},
                    ),
                    self.event_manager
                )
                result.status = "FAIL"
                break
            module_current = module_current.next
        else:
            queue_event_sync(
                Event(
                    entity_type="test_case",
                    entity_id=testcase_id,
                    name=test_case,
                    status=EventStatus.PASS,
                    extra={"session_id": self.session.session_id},
                ),
                self.event_manager
            )
            result.status = "PASS"
        result.elapsed = f"{time.time() - start_time:.2f}s"
        return result

    async def execute_test_case(self, test_case: str) -> TestCaseResult:
        return self.execute_test_case_sync(test_case, dry_run=False)

    async def dry_run_test_case(self, test_case: str) -> TestCaseResult:
        return self.execute_test_case_sync(test_case, dry_run=True)

    async def run_all(self) -> None:
        test_cases = [node.name for node in self._iter_test_cases()]
        result = self._run_pytest(test_cases, dry_run=False)
        if not result:
            raise RuntimeError("Pytest execution failed")

    async def dry_run_all(self) -> None:
        test_cases = [node.name for node in self._iter_test_cases()]
        result = self._run_pytest(test_cases, dry_run=True)
        if not result:
            raise RuntimeError("Pytest execution failed")

    def _iter_test_cases(self):
        current = self.test_cases
        while current:
            yield current
            current = current.next

    def _run_pytest(self, test_cases: List[str], dry_run: bool = False) -> bool:
        """Run a test suite using pytest, generating test files and handling results.

        Args:
            test_cases: List of test case names to run.
            dry_run: If True, perform a dry run without executing keywords.

        Returns:
            bool: True if all tests passed, False otherwise.
        """
        temp_dir = tempfile.mkdtemp()
        test_file_path = f"{temp_dir}/test_generated_{int(time.time() * 1000)}.py"
        conftest_path = f"{temp_dir}/conftest.py"
        extra = {"test_cases": ", ".join(test_cases)}

        internal_logger.debug(f"Generating test file: {test_file_path}", extra=extra)

        with open(conftest_path, "w") as f:
            f.write("""
import pytest
from optics_framework.common.runner.test_runnner import PytestRunner

@pytest.fixture
def runner():
    return PytestRunner.instance
""")

        test_code = "import pytest\n\n" + "".join(
            f"def test_{i}_{re.sub(r'\W', '_', tc)}(runner):\n"
            f"    result = runner.execute_test_case_sync({tc!r}, dry_run={dry_run})\n"
            f"    assert result.status == 'PASS', 'Test case failed with status: ' + result.status\n"
            for i, tc in enumerate(test_cases)
        )
        internal_logger.debug(f"Generated test code:\n{test_code}", extra=extra)
        with open(test_file_path, "w") as f:
            f.write(test_code)

        for module_name in list(sys.modules.keys()):
            if module_name.startswith("test_generated"):
                del sys.modules[module_name]

        junit_path = f"{self.session.config.execution_output_path}/junit_output.xml"
        result = pytest.main(
            [
                temp_dir,
                "-q",
                "--disable-warnings",
                f"--junitxml={junit_path}",
                "--no-cov",
            ]
        )
        shutil.rmtree(temp_dir)

        if result == 0:
            internal_logger.info("Pytest execution completed successfully")
            queue_event_sync(
                Event(
                    entity_type="execution",
                    entity_id="pytest",
                    name="Pytest",
                    status=EventStatus.PASS,
                    message="Pytest execution completed",
                    extra={"session_id": self.session.session_id},
                ),
                self.event_manager
            )
            return True
        else:
            internal_logger.error("Pytest execution failed")
            queue_event_sync(
                Event(
                    entity_type="execution",
                    entity_id="pytest",
                    name="Pytest",
                    status=EventStatus.FAIL,
                    message="Pytest execution failed",
                    extra={"session_id": self.session.session_id},
                ),
                self.event_manager
            )
            return False

class KeywordRunner(Runner):
    def __init__(self, keyword_map):
        self.keyword_map = keyword_map
