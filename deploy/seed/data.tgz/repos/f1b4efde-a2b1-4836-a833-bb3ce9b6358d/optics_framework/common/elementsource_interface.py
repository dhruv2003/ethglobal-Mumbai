from abc import ABC, abstractmethod
from typing import Any, Optional, List, Tuple
import numpy
from optics_framework.common.session_liveness import raise_if_session_dead

class ScreenPoint(tuple):
    """An ``(x, y)`` point from :meth:`ElementSourceInterface.locate` with whatever the source read about the element there."""

    text: str | None
    covered: bool
    enabled: bool | None
    checked: bool | None

    def __new__(
        cls, x: int, y: int, *, text: str | None = None, covered: bool = False,
        enabled: bool | None = None, checked: bool | None = None,
    ) -> "ScreenPoint":
        point = super().__new__(cls, (x, y))
        point.text = text
        point.covered = covered
        point.enabled = enabled
        point.checked = checked
        return point


class ElementSourceInterface(ABC):
    """
    Abstract base class for element source drivers.

    This interface defines methods for capturing and interacting with screen elements
    (e.g., images, UI components) within an application or environment, implementing
    the :class:`ElementSourceInterface`.

    Implementers should handle specific element types (e.g., image bytes, templates)
    as needed.
    """

    #: True when this source's elements sit inside another source's screen (a web page in an app) and add to it.
    SUPPLEMENTS_SCREEN_ELEMENTS: bool = False

    @abstractmethod
    def capture(self) -> numpy.ndarray:
        """
        Capture the current screen state.

        :return: None
        :rtype: None
        """
        pass

    def capture_screenshot_bytes(self) -> bytes:
        """
        Return the current screen as encoded PNG bytes.

        Combines the numpy and bytes screenshot paths into one call. Backends that can
        return native encoded bytes (e.g. Appium, Playwright) should override this for
        efficiency; the default implementation encodes the result of :meth:`capture`.

        :return: PNG-encoded screenshot bytes.
        :rtype: bytes
        """
        import cv2  # local import — cv2 is a runtime dep, not needed at module load
        frame = self.capture()
        _, buf = cv2.imencode(".png", frame)
        return bytes(buf)

    @abstractmethod
    def locate(self, element: Any, index: int | None = None) -> tuple:
        """
        Locate an element within the current screen state.

        :param element: The element to search for (e.g., template image, UI component).
        :type element: Any
        :return: A tuple (x, y) representing the center of the element, or None if not found.
            Coordinates must be in the driver's window space (``get_window_size``), which
            AOI filtering compares them against.
        :rtype: Optional[Tuple[int, int]]
        """
        pass

    def can_locate(self, element: str) -> bool:
        """Whether this source can look ``element`` up."""
        return True

    @abstractmethod
    def assert_elements(self, elements: Any, timeout: int = 30, rule: str = 'any') -> None:
        """
        Assert the presence of elements on the screen.

        :param elements: The elements to check for presence (e.g., list of templates).
        :type elements: Any
        :param timeout: Time in seconds to wait for elements to appear (default: 30).
        :type timeout: int
        :param rule: Assertion rule ('any' for at least one, 'all' for all; default: 'any').
        :type rule: str
        :return: None
        :rtype: None
        :raises AssertionError: If the assertion fails based on the rule.
        """
        pass

    def check_elements(self, elements: list[str], visible: bool = False) -> list[bool]:
        """One look, no waiting: whether each element is present (visible when ``visible``) right now."""
        assert_method = self.assert_elements_visible if visible else self.assert_elements
        found = []
        for element in elements:
            try:
                # 0 would skip the `while elapsed < timeout` loops most sources poll with
                found.append(assert_method([element], 1, "any") is not False)
            except Exception as e:
                raise_if_session_dead(e)
                found.append(False)
        return found

    def get_element_bboxes(
        self, elements: list
    ) -> List[Optional[Tuple[Tuple[int, int], Tuple[int, int]]]]:
        """
        Return bounding boxes for each element in pixel coordinates.

        :param elements: List of element identifiers (e.g., XPath, text).
        :return: For each element, ((x1,y1), (x2,y2)) or None if not available.
        """
        return [None] * len(elements)

    def get_bbox_for_element(
        self, element: Any
    ) -> Optional[Tuple[Tuple[int, int], Tuple[int, int]]]:
        """
        Return bounding box for an already-located element in screenshot coordinates.

        :param element: An already-located element (WebElement, Playwright handle, etc.).
        :return: ((x1,y1), (x2,y2)) or None if not available.
        """
        return None

    def get_page_source(self) -> Tuple[str, str]:
        """
        Get the page source and timestamp of the current screen.
        Optional: raise NotImplementedError if this element source does not support it.

        :return: Tuple of (page_source, timestamp).
        :rtype: Tuple[str, str]
        """
        raise NotImplementedError(
            f"{self.__class__.__name__} does not support get_page_source"
        )

    def assert_elements_visible(self, elements: Any, timeout: int = 30, rule: str = 'any') -> Any:
        """
        Assert that elements are currently rendered/visible on screen -- distinct from
        :meth:`assert_elements`, which only checks presence in the underlying page
        source/DOM (visible or not).
        Optional: raise NotImplementedError if this element source cannot distinguish
        visibility from presence (e.g. vision-based sources, where anything found is
        inherently on-screen already).

        :param elements: The elements to check for visibility (e.g. list of XPaths/text).
        :param timeout: Time in seconds to wait for elements to become visible.
        :param rule: Assertion rule ('any' for at least one, 'all' for all).
        :raises TimeoutError: If the assertion fails based on the rule within the timeout.
        """
        raise NotImplementedError(
            f"{self.__class__.__name__} does not support assert_elements_visible"
        )

    @abstractmethod
    def get_interactive_elements(self, filter_config: Optional[List[str]] = None, compact: bool = False) -> list:
        """
        Retrieve a list of interactive elements on the current screen.

        :param filter_config: Optional list of filter types (e.g., ["buttons", "inputs"]).
        :type filter_config: Optional[List[str]]
        :param compact: When True, return only actionable elements (folded labels) plus
            standalone visible text. It is forwarded only to implementations that declare
            it; sources kept on the legacy two-argument signature still work and return
            their full list.
        :type compact: bool
        :return: A list of interactive elements (e.g., buttons, links).
        :rtype: list
        """
        pass
